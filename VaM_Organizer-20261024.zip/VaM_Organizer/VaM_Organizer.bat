@echo off
chcp 65001 >nul
setlocal
rem VaM Organizer launcher - uses the bundled runtime\ (release zip), else an installed Python 3.9+ with tkinter
if exist "%~dp0runtime\pythonw.exe" (start "" "%~dp0runtime\pythonw.exe" "%~dp0vamdedup_gui.pyw" & exit /b 0)
for %%V in (3.14 3.13 3.12 3.11 3.10 3.9) do (
  py -%%V -c "import tkinter" >nul 2>nul && (start "" pyw -%%V "%~dp0vamdedup_gui.pyw" & exit /b 0)
)
python -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul && (start "" pythonw "%~dp0vamdedup_gui.pyw" & exit /b 0)
echo Python 3.9 or newer (with tkinter) was not found. Install it from https://www.python.org/downloads/ and run this again.
echo Python 3.9 이상(tkinter 포함)을 찾지 못했습니다. https://www.python.org/downloads/ 에서 설치한 뒤 다시 실행하세요.
pause
