// VaM Organizer launcher: starts vamdedup_gui.pyw next to this exe with the private Python in runtime\
// (release zip), or else with an installed Python 3.9+ that has tkinter (running from source).
// Built with the C# compiler that ships with Windows (.NET Framework 4); carries the CKNMN chicken icon.
// No console window ever appears: probes run hidden, the app itself runs under pythonw.
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("VaM Organizer")]
[assembly: AssemblyProduct("VaM Organizer")]
[assembly: AssemblyCompany("CKNMN")]
[assembly: AssemblyDescription("Cleans up Virt-A-Mate packages (local app)")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

static class Launcher
{
    static readonly string[] Versions = { "3.14", "3.13", "3.12", "3.11", "3.10", "3.9" };

    [STAThread]
    static int Main()
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        string script = Path.Combine(dir, "vamdedup_gui.pyw");
        if (!File.Exists(script))
        {
            Fail("vamdedup_gui.pyw is missing next to this program.\nvamdedup_gui.pyw 파일이 이 프로그램 옆에 없습니다.");
            return 2;
        }
        string quoted = "\"" + script + "\"";

        // 0) the private Python shipped in runtime\ by make_dist.py: nothing to install
        string bundled = Path.Combine(dir, @"runtime\pythonw.exe");
        if (File.Exists(bundled))
        {
            Start(bundled, quoted, dir);
            return 0;
        }
        // 1) the py launcher (python.org installs it): pick the newest version that has tkinter
        string py = Find("py.exe"), pyw = Find("pyw.exe");
        if (py != null && pyw != null)
        {
            foreach (string v in Versions)
            {
                if (Probe(py, "-" + v + " -c \"import tkinter\""))
                {
                    Start(pyw, "-" + v + " " + quoted, dir);
                    return 0;
                }
            }
        }
        // 2) python / pythonw on PATH (not the Microsoft Store alias, which opens the Store)
        string python = Find("python.exe"), pythonw = Find("pythonw.exe");
        if (python != null && pythonw != null &&
            Probe(python, "-c \"import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)\""))
        {
            Start(pythonw, quoted, dir);
            return 0;
        }
        Fail("Python 3.9 or newer (with tkinter) was not found.\nInstall it from https://www.python.org/downloads/ and run this again.\n\n" +
             "Python 3.9 이상(tkinter 포함)을 찾지 못했습니다.\nhttps://www.python.org/downloads/ 에서 설치한 뒤 다시 실행하세요.");
        return 1;
    }

    static string Find(string exe)
    {
        string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        string direct = Path.Combine(win, exe);  // py.exe / pyw.exe live in C:\Windows for all-users installs
        if (File.Exists(direct)) return direct;
        string local = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                                    @"Programs\Python\Launcher\" + exe);
        if (File.Exists(local)) return local;
        foreach (string d in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            if (d.Length == 0 || d.IndexOf("WindowsApps", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            try
            {
                string p = Path.Combine(d.Trim().Trim('"'), exe);
                if (File.Exists(p)) return p;
            }
            catch (ArgumentException) { }
        }
        return null;
    }

    static bool Probe(string exe, string args)
    {
        try
        {
            var si = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true,
                                                       RedirectStandardOutput = true, RedirectStandardError = true };
            using (var p = Process.Start(si))
            {
                if (!p.WaitForExit(20000)) { p.Kill(); return false; }
                return p.ExitCode == 0;
            }
        }
        catch (Exception) { return false; }
    }

    static void Start(string exe, string args, string dir)
    {
        var si = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = dir };
        Process.Start(si);
    }

    static void Fail(string msg)
    {
        MessageBox.Show(msg, "VaM Organizer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
