# VaM Organizer

Cleans up a Virt-A-Mate (VaM) install: removes old package versions and duplicate assets/morphs that are
copied into many `.var` files, re-links every scene to the copy that stays, and repairs references that are
already broken. Nothing is deleted outright — every original is moved to a backup you can restore with one click.

by CKNMN 뱀챈 치킨맨 · cknmn@proton.me · support: <https://buymeacoffee.com/cknmn>

## Requirements

- Windows 10 or 11 (64-bit)
- Nothing to install: the Python it needs ships in the `runtime` folder.
  The app is a regular local window and never goes online itself (creator links and the coffee button open in
  your default browser).

## Start

1. Unzip anywhere (don't run it from inside the zip).
2. Double-click `VaM_Organizer.exe`.
   - If "Windows protected your PC" appears, click **More info → Run anyway** (new unsigned programs can trigger it).
   - If it is still blocked, use `VaM_Organizer.bat`.
3. First run: pick a language (your Windows language is pre-selected), then confirm the folders it found:
   - **VaM folder** — the folder with `VaM.exe` and `AddonPackages`
   - **Work folder** — always `<VaM folder>\dedup` (index, plans, backups). VaM does not load anything from it.
   - **Repair originals** — optional folders with original `.var` backups left by older cleanup tools

## Use

1. **Start analysis** — scans your packages and builds a plan. Nothing is changed. The first scan takes ~10 minutes.
2. **Review** — space freed, morph list before/after, broken references fixed, and a safety check that simulates
   every scene reference before and after (it must say *0 references break*).
3. **Apply** (close VaM first). You can **Pause** at any time, or **Stop & revert**:
   - while new `.var` files are being built, stopping leaves your VaM folder untouched;
   - while originals are being moved, stopping puts everything back automatically.
4. Open a few scenes in VaM. If all is well, use **Delete all backups** to actually free the space.
   Until then, **Revert** restores the exact state from before the apply.

**Issues remain** lists packages your scenes need but you don't have — mostly not on the Hub. They are grouped
by creator, sorted by how many references each one fixes, with the creator's own page (**Open**) or a web
**Search**. Put the `.var` files you get into `AddonPackages` and analyze again.

## Settings

Folders button: change folders, morph match threshold (morphs whose shape differs by less than 5 % are merged),
and an optional (not recommended) path-only repair. Language and day/night mode are in the top bar.

## What it never touches

`meta.json`, scenes (`Saves/`), plugins (`Custom/Scripts/`, any package containing `.cs/.cslist/.dll`),
subscenes, files referenced by relative paths or plugin code, and the canonical copy of anything.

## Uninstall

Delete the unzipped folder and, after you have deleted the backups, `<VaM folder>\dedup`.
