"""VaM 정리기 실행 파일 — Windows 프로그램 창 하나로 동작한다 (브라우저·서버·인터넷 없음). pythonw로 실행."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vd.ui import main  # noqa: E402

if __name__ == "__main__":
    main()
