"""vam-dedup CLI: index -> plan (dry run + simulation) -> apply (staged, journaled) -> verify / rollback."""
import argparse
import json
import sys
import time

from . import ops


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="vamdedup")
    ap.add_argument("--vam", help="VaM 폴더 (생략하면 자동 감지)")
    ap.add_argument("--state", help="작업 폴더 (생략하면 <VaM 폴더>_dedup)")
    ap.add_argument("--archive", action="append", help="folder(s) with original .var backups used for repairs")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("index")
    p = sub.add_parser("plan")
    p.add_argument("--threshold", type=float, default=0.05, help="morph shape difference treated as same")
    p.add_argument("--no-index", action="store_true")
    p.add_argument("--heuristic-repair", action="store_true",
                   help="also repair broken refs by a path that exists in exactly one package (content unverified)")
    p = sub.add_parser("apply")
    p.add_argument("plan")
    p.add_argument("--yes", action="store_true")
    p = sub.add_parser("rollback")
    p.add_argument("backup")
    sub.add_parser("verify")
    args = ap.parse_args(argv)
    if args.cmd == "rollback":
        ops.run_rollback(args.backup, log=log)
        return
    args.vam, args.state, archives = ops.resolve_folders(args.vam, args.state, args.archive, log=log)

    if args.cmd == "index":
        ops.run_index(args.vam, args.state, archives, log=log)
    elif args.cmd == "plan":
        r = ops.run_plan(args.vam, args.state, archives, threshold=args.threshold, heuristic=args.heuristic_repair,
                         reindex=not args.no_index, log=log)
        print(json.dumps(r["details"]["report"], ensure_ascii=False, indent=1, default=str))
        print(f"\nplan:   {r['plan_path']}\nreport: {r['report_path']}")
        if r["details"]["report"]["simulation_regressions"]:
            print("\n!! simulation found regressions - do not apply this plan")
            sys.exit(2)
    elif args.cmd == "apply":
        if not args.yes:
            print("apply moves/rewrites files under", args.vam, "- rerun with --yes to confirm")
            sys.exit(1)
        print("backup + journal:", ops.run_apply(args.plan, args.state, log=log))
    elif args.cmd == "verify":
        print(json.dumps(ops.run_verify(args.vam, args.state, archives, log=log), indent=1))
