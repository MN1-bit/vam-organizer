"""VaM conventions shared by every stage: package UIDs, reference grammar, path classes."""
import posixpath
import re

# <creator>.<name>.<version>  (VaM: "is not named with convention <creator>.<name>.<version>")
UID_RE = re.compile(r"^([^.]+)\.([^.]+)\.(\d+)$")
# Whole-string reference: SELF:/path | C.P.N:/path | C.P.latest:/path | C.P.minN:/path
REF_RE = re.compile(r"^(SELF|[^./\\:]+\.[^./\\:]+\.(?:\d+|latest|min\d+)):/(.+)$", re.S)
# Reference embedded inside a longer string (plugin data, code) - never rewritten, only pinned
EMBED_RE = re.compile(r"(SELF|[^./\\:\"'|,;<>\r\n]+\.[^./\\:\"'|,;<>\r\n]+\.(?:\d+|latest|min\d+)):/([^\"'|,;<>\r\n]+)")
PREFIX_RE = re.compile(r"^([^.]+\.[^.]+)\.(\d+|latest|min(\d+))$")

TEXT_EXT = (".json", ".vap", ".vaj", ".vam", ".vac", ".vmi", ".vapl")
CODE_EXT = (".cs",)
LIST_EXT = (".cslist",)
ASSET_EXT_RE = re.compile(
    r"\.(jpg|jpeg|png|tif|tiff|tga|bmp|vmi|vmb|vam|vaj|vab|vap|json|assetbundle|scene|wav|mp3|ogg|"
    r"cs|cslist|dll|mp4|webm|vac|vapl)$", re.I)
MAX_TEXT_BYTES = 64 * 1024 * 1024


def parse_uid(fname):
    """'A.B.3.var' -> ('A.B.3', 'A.B', 3, 'A') or None."""
    stem = fname[:-4] if fname.lower().endswith(".var") else fname
    m = UID_RE.match(stem)
    if not m:
        return None
    return stem, f"{m.group(1)}.{m.group(2)}", int(m.group(3)), m.group(1)


def split_ref(value):
    m = REF_RE.match(value)
    return (m.group(1), m.group(2)) if m else None


def morph_bank(lp):
    """custom/atom/person/morphs/<bank>/... -> bank"""
    parts = lp.split("/")
    return parts[4] if len(parts) > 5 else ""


def strip_class(lp):
    """Which files may ever be removed from a package as a duplicate.

    Scenes, saves, plugins, subscenes and meta.json are never removed: they are user-facing
    entry points or code whose own paths matter.
    """
    if lp == "meta.json" or lp.startswith(("saves/", "custom/scripts/", "custom/subscene/")):
        return None
    if lp.endswith((".cs", ".cslist", ".dll")):
        return None
    if lp.startswith("custom/atom/person/morphs/") and lp.endswith((".vmi", ".vmb")):
        return "morph"
    if lp.startswith(("custom/clothing/", "custom/hair/")):
        return "item"
    if lp.startswith("custom/"):
        return "file"
    return None


def rel_candidates(src_lp, value):
    """Entry paths a non-prefixed path string inside file src_lp may point at."""
    v = value.replace("\\", "/").strip()
    d = posixpath.dirname(src_lp)
    out = []
    if v.startswith("./"):
        out.append(posixpath.normpath(posixpath.join(d, v[2:])))
    elif "/" not in v:
        out.append(posixpath.join(d, v))
    else:
        out.append(posixpath.normpath(v))
        out.append(posixpath.normpath(posixpath.join(d, v)))
    return [c.lower() for c in out if not c.startswith("..")]
