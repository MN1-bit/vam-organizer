"""Build a cleanup plan from the index and prove it with a full before/after reference simulation.

Policy
- duplicate copies of the same package UID: keep the most complete copy
- versions: keep only the newest; an old version survives as a stripped "residual" only for content that
  scenes pin to it and that exists nowhere else (morphs count as the same when shape differs < threshold)
- duplicates across packages: one canonical copy per content unit; other copies are stripped and every
  reference is rewired to the canonical copy (exact version). Canonical copies are never stripped, so no
  reference can be rewired onto a copy that is itself removed (the chain-stripping bug of earlier tools).
- files referenced in a way that cannot be rewritten (relative paths, plugin code, embedded strings) are
  pinned and never stripped
- references that are already broken are repaired when the content can be found (other version, original
  content from backup archives, morph display name, unique path)
"""
import json
import math
import os
import posixpath
import re
import sqlite3
from collections import Counter, defaultdict

from .model import morph_bank, split_ref, strip_class
from .morphs import VmbStore, shape_diff
from .resolver import Registry
from .zipraw import rewrite_problem

BAD_NAME_RE = re.compile(r"^(.+?)\s*\(\d+\)\.var$", re.I)
MIN_FILE_UNIT_BYTES = 32 * 1024  # smaller standalone files are not worth coupling unrelated packages


def asset_kind(lp):
    if lp.startswith("custom/atom/person/morphs/"):
        return "morph"
    if lp.startswith("custom/atom/person/textures/"):
        return "texture"
    if lp.startswith(("custom/clothing/", "custom/hair/")):
        return "item"
    if lp.startswith("custom/sounds/") or lp.endswith((".wav", ".mp3", ".ogg")):
        return "sound"
    if lp.endswith(".assetbundle"):
        return "assetbundle"
    if lp.startswith("custom/atom/person/"):
        return "preset"
    return "other"


class Unit:
    __slots__ = ("kind", "pid", "root", "members", "key", "pinned", "main", "extra")

    def __init__(self, kind, pid, root, members, key, main):
        self.kind, self.pid, self.root, self.members, self.key, self.main = kind, pid, root, members, key, main
        self.pinned = False
        self.extra = None


class Planner:
    def __init__(self, db_path, vam_root, threshold=0.05, heuristic_repair=False, log=print, ctl=None, skip=()):
        self.ctl = ctl
        if ctl is not None:
            log = ctl.log
        self.db = sqlite3.connect(db_path)
        self.vam_root = vam_root
        self.thr = threshold
        self.heuristic_repair = heuristic_repair
        self.log = log
        self.forced_keep = set()  # (pid, lp) never stripped / always kept in residuals (regression feedback)
        # files this tool must not rewrite (odd zip layout, a failed earlier apply): {(source, relpath): reason}
        self.skip_in = {(s["source"], s["relpath"]): s.get("reason", "") for s in skip}
        self.frozen, self.frozen_why = set(), {}

    # ------------------------------------------------------------------ load
    def load(self):
        db = self.db
        self.P = {}
        for (pid, source, relpath, fname, uid, grp, ver, creator, size, mtime, ok, err, meta,
             nentries) in db.execute("SELECT id,source,relpath,fname,uid,grp,ver,creator,size,mtime,ok,err,meta,nentries FROM pkg"):
            m = None
            if meta:
                try:
                    m = json.loads(meta)
                except ValueError:
                    m = None
            co = (m or {}).get("customOptions") if isinstance(m, dict) else None
            self.P[pid] = dict(source=source, relpath=relpath, fname=fname, uid=uid, grp=grp, ver=ver,
                               creator=creator or "", size=size, mtime=mtime, ok=ok, err=err,
                               meta=m if isinstance(m, dict) else None, nentries=nentries,
                               preload=str((co or {}).get("preloadMorphs", "false")).lower() == "true")
        self.E = defaultdict(dict)
        for pid, path, crc, us, cs in db.execute("SELECT pkg,path,crc,usize,csize FROM entry"):
            self.E[pid][path.lower()] = (path, crc, us, cs)
        self.refs = defaultdict(list)
        for pid, src, value, kind in db.execute("SELECT pkg,src,value,kind FROM ref"):
            self.refs[pid].append((src, value, kind))
        self.mname = {}
        for pid, src, uid, name in db.execute("SELECT pkg,src,uid,name FROM mref"):
            self.mname[(pid, uid)] = name
        self.V = {}
        for pid, path, mid, disp, region, grp, pose, vmin, vmax, fh in db.execute(
                "SELECT pkg,path,mid,display,region,grp,pose,vmin,vmax,fhash FROM vmi"):
            self.V[(pid, path.lower())] = (mid, disp, pose, vmin, vmax, fh)
        dep_pop = Counter()
        for pid, p in self.P.items():
            p["has_scene"] = any(lp.startswith("saves/scene/") and lp.endswith(".json") for lp in self.E.get(pid, ()))
            kinds = Counter(asset_kind(lp) for lp in self.E.get(pid, ()))
            total = sum(kinds.values()) or 1
            p["kind_frac"] = {k: n / total for k, n in kinds.items()}
            if p["source"] == "live" and p["meta"]:
                for d in (p["meta"].get("dependencies") or {}):
                    dep_pop[d.rsplit(".", 1)[0]] += 1
        for p in self.P.values():
            p["dep_pop"] = dep_pop.get(p["grp"], 0) if p["grp"] else 0
        self.log(f"loaded {len(self.P)} index rows")

    def abspath(self, pid):
        p = self.P[pid]
        if p["source"] == "archive":
            return p["relpath"]
        if p["source"] == "local":
            return os.path.join(self.vam_root, p["relpath"])
        return os.path.join(self.vam_root, "AddonPackages", p["relpath"])

    # ------------------------------------------------------------------ registry
    def build_registry(self):
        live = [pid for pid, p in self.P.items() if p["source"] == "live"]
        by_uid = defaultdict(list)
        self.unreadable, self.bad_names, self.dup_removals = [], [], []
        for pid in live:
            p = self.P[pid]
            if not p["ok"]:
                self.unreadable.append(pid)
            elif p["uid"]:
                by_uid[p["uid"]].append(pid)
        for pid in live:
            p = self.P[pid]
            if p["uid"] is None and p["ok"]:
                m = BAD_NAME_RE.match(p["fname"])
                self.bad_names.append((pid, m.group(1) if m else None))
        self.keeper = {}
        for uid, pids in by_uid.items():
            best = max(pids, key=lambda i: (self.P[i]["nentries"], self.P[i]["size"], -len(self.P[i]["relpath"])))
            self.keeper[uid] = best
            for i in pids:
                if i != best:
                    self.dup_removals.append((i, best))
        self.bad_names = [(pid, stem) for pid, stem in self.bad_names if stem and stem in self.keeper]
        self.opaque_groups = set()
        for pid in self.unreadable:
            u = self.P[pid]
            if u["grp"]:
                self.opaque_groups.add(u["grp"])
        gv = {pid: (self.P[pid]["grp"], self.P[pid]["ver"]) for pid in self.keeper.values()}
        self.pre = Registry(self.keeper, gv)
        self.newest = {g: self.pre.newest(g) for g in self.pre.vers}
        self.N = set(self.newest.values())
        self.old = set(self.keeper.values()) - self.N
        self.reg_pids = set(self.keeper.values())
        self.archive = defaultdict(list)  # (grp, lp) -> [(ver, pid)]
        for pid, p in self.P.items():
            if p["source"] == "archive" and p["ok"] and p["grp"]:
                for lp in self.E[pid]:
                    self.archive[(p["grp"], lp)].append((p["ver"], pid))
        self.log(f"registry: {len(self.reg_pids)} packages, {len(self.N)} newest, {len(self.old)} old, "
                 f"{len(self.dup_removals)} duplicate copies, {len(self.bad_names)} bad-name copies, "
                 f"{len(self.unreadable)} unreadable")

    # ------------------------------------------------------------------ pins
    def compute_pins(self):
        pins = set(self.forced_keep)
        basenames = {}
        self.plugin_pkgs = set()
        for pid in self.reg_pids:
            # plugin code may build asset paths dynamically: nothing in a plugin package is ever stripped
            if any(lp.endswith((".cs", ".cslist", ".dll")) for lp in self.E[pid]):
                self.plugin_pkgs.add(pid)
                pins.update((pid, lp) for lp in self.E[pid])
            if pid in self.frozen:  # can't be rewritten: nothing is stripped out of it
                pins.update((pid, lp) for lp in self.E[pid])
        for pid in self.reg_pids:
            for src, v, kind in self.refs[pid]:
                if kind == "rel":
                    pins.add((pid, v))
                elif kind == "code":
                    bi = basenames.get(pid)
                    if bi is None:
                        bi = defaultdict(list)
                        for lp in self.E[pid]:
                            bi[posixpath.basename(lp)].append(lp)
                        basenames[pid] = bi
                    for lp in bi.get(posixpath.basename(v.replace("\\", "/")).lower(), ()):
                        pins.add((pid, lp))
        for pid, p in self.P.items():
            if p["source"] not in ("live", "local"):
                continue
            src_pid = pid if pid in self.reg_pids else None
            for src, v, kind in self.refs[pid]:
                if kind != "embed":
                    continue
                sr = split_ref(v)
                if not sr:
                    continue
                tp = self.pre.resolve(sr[0], src_pid)
                if tp is not None and sr[1].lower() in self.E[tp]:
                    pins.add((tp, sr[1].lower()))
        self.pins = pins
        self.log(f"pinned files: {len(pins)}")

    # ------------------------------------------------------------------ units
    def build_units(self, pids):
        units = []
        unit_of = {}
        for pid in pids:
            E = self.E[pid]
            assigned = set()
            item_dirs = sorted({posixpath.dirname(lp) for lp in E
                                if lp.endswith(".vam") and lp.startswith(("custom/clothing/", "custom/hair/"))},
                               key=len, reverse=True)
            for d in item_dirs:
                files = [lp for lp in E if lp.startswith(d + "/") and lp not in assigned]
                assigned.update(files)
                sig = {lp[len(d) + 1:]: (E[lp][1], E[lp][2]) for lp in files}
                vams = tuple(sorted(sig[r] for r in sig if r.endswith(".vam")))
                u = Unit("item", pid, d, {lp[len(d) + 1:]: lp for lp in files}, vams, None)
                u.extra = sig
                units.append(u)
            for lp in E:
                if lp in assigned or not (lp.startswith("custom/atom/person/morphs/") and lp.endswith(".vmi")):
                    continue
                vmb = lp[:-4] + ".vmb"
                mem = {".vmi": lp}
                if vmb in E:
                    mem[".vmb"] = vmb
                meta = self.V.get((pid, lp))
                if meta is None:
                    continue
                mid, disp, pose, vmin, vmax, fh = meta
                key = (morph_bank(lp), disp, mid, pose, vmin, vmax, fh, ".vmb" in mem)
                u = Unit("morph", pid, lp, mem, key, lp)
                u.extra = (E[vmb][1], E[vmb][2]) if vmb in E else None
                units.append(u)
                assigned.update(mem.values())
            stems = defaultdict(dict)
            for lp in E:
                if lp in assigned or strip_class(lp) not in ("file", "item", "morph"):
                    continue
                stem, ext = posixpath.splitext(lp)
                stems[stem][ext] = lp
            for stem, exts in stems.items():
                if ".vap" in exts or ".json" in exts:
                    groups = [exts]
                else:
                    groups = [{ext: lp} for ext, lp in exts.items()]
                for g in groups:
                    key = tuple(sorted((ext, E[lp][1], E[lp][2]) for ext, lp in g.items()))
                    main = g.get(".vap") or g.get(".json") or next(iter(g.values()))
                    units.append(Unit("file", pid, stem, dict(g), key, main))
        for u in units:
            for lp in u.members.values():
                unit_of[(u.pid, lp)] = u
            u.pinned = any((u.pid, lp) in self.pins for lp in u.members.values())
        return units, unit_of

    # ------------------------------------------------------------------ canonical choice
    def score(self, u, incoming):
        p = self.P[u.pid]
        s = 0.0
        if u.pid in self.plugin_pkgs:
            s -= 200  # a plugin's embedded copy is kept, but the owning content package stays canonical
        main = u.main or u.root
        if p["creator"] and p["creator"].lower() in main.split("/"):
            s += 100  # origin creator's own folder
        if u.kind == "morph" and p["preload"]:
            s += 50   # morph pack meant to be global
        s += 60 * p["kind_frac"].get(asset_kind(main), 0)  # dedicated pack of this kind of asset
        s += 15 * math.log1p(p["dep_pop"])  # library other packages already depend on
        if not p["has_scene"]:
            s += 30
        s += 10 * math.log1p(incoming.get((u.pid, main), 0))
        return (s, -p["nentries"], p["uid"])

    def canonicalize(self):
        self.units, self.unit_of = self.build_units(self.N)
        incoming = Counter()
        for pid, p in self.P.items():
            if p["source"] not in ("live", "local"):
                continue
            src_pid = pid if pid in self.reg_pids else None
            for src, v, kind in self.refs[pid]:
                if kind != "full":
                    continue
                sr = split_ref(v)
                tp = self.pre.resolve(sr[0], src_pid)
                if tp is not None and tp != src_pid:
                    incoming[(tp, sr[1].lower())] += 1
        self.incoming = incoming
        self.strip_map = {}  # (pid, lp) -> (cpid, clp)
        self.morph_clusters = defaultdict(list)  # (bank, display) -> [canonical Unit]
        self.content_canon = {}  # file/item content key -> canonical Unit
        if getattr(self, "vmbs", None):
            self.vmbs.close()
        store = VmbStore(self.abspath)
        self.vmbs = store
        by_key = defaultdict(list)
        for u in self.units:
            by_key[(u.kind, u.key)].append(u)
        stats = Counter()
        for (kind, key), us in by_key.items():
            if kind == "morph":
                continue
            us.sort(key=lambda x: self.score(x, incoming), reverse=True)
            if kind == "file":
                canon = us[0]
                self.content_canon[(kind, key)] = canon
                if sum(k[2] for k in key) < MIN_FILE_UNIT_BYTES:
                    continue
                for u in us[1:]:
                    if u.pinned or any((u.pid, lp) in self.forced_keep for lp in u.members.values()):
                        continue
                    for ext, lp in u.members.items():
                        self.strip_map[(u.pid, lp)] = (canon.pid, canon.members[ext])
                    stats["file_units_stripped"] += 1
            else:
                def subset(a, b):
                    return all(b.extra.get(r) == c for r, c in a.extra.items())
                sup = {id(c): sum(subset(o, c) for o in us) for c in us}
                us.sort(key=lambda c: (sup[id(c)], self.score(c, incoming)), reverse=True)
                canon = us[0]
                self.content_canon[(kind, key)] = canon
                for u in us[1:]:
                    if u.pinned or not subset(u, canon):
                        continue
                    for rel, lp in u.members.items():
                        self.strip_map[(u.pid, lp)] = (canon.pid, canon.members[rel])
                    stats["item_units_stripped"] += 1
        # morphs: cluster by semantic key, then shape threshold against the canonical
        morph_groups = defaultdict(list)
        for u in self.units:
            if u.kind == "morph":
                morph_groups[u.key].append(u)
        for key, us in morph_groups.items():
            us.sort(key=lambda x: self.score(x, incoming), reverse=True)
            remaining = us
            while remaining:
                canon, rest, members = remaining[0], [], []
                for u in remaining[1:]:
                    if self.morph_same(canon, u):
                        members.append(u)
                    else:
                        rest.append(u)
                self.morph_clusters[(key[0], key[1])].append(canon)
                for u in members:
                    if u.pinned or (u.pid, u.main) in self.forced_keep:
                        continue
                    for ext, lp in u.members.items():
                        self.strip_map[(u.pid, lp)] = (canon.pid, canon.members[ext])
                    stats["morph_units_stripped"] += 1
                remaining = rest
            store.cache.clear()
        self.canon_stats = stats
        self.log(f"canonicalize: {dict(stats)}")

    def morph_same(self, a, b):
        if a.key != b.key:
            return False
        if a.extra is None or b.extra is None:
            return a.extra == b.extra
        if a.extra == b.extra:
            return True
        try:
            da = self.vmbs.get(a.pid, self.E[a.pid][a.members[".vmb"]][0], a.extra)
            db_ = self.vmbs.get(b.pid, self.E[b.pid][b.members[".vmb"]][0], b.extra)
        except Exception:
            return False
        return shape_diff(da, db_) < self.thr

    # ------------------------------------------------------------------ survivor lookup
    def find_canonical_for(self, pid, lp, unit_of):
        """Where does content (pid, lp) live after cleanup, among survivors? -> (cpid, clp) or None."""
        u = unit_of.get((pid, lp))
        if u is None:
            return None
        if u.kind == "morph":
            for canon in self.morph_clusters.get((u.key[0], u.key[1]), ()):
                if self.morph_same(canon, u):
                    ext = ".vmb" if lp.endswith(".vmb") else ".vmi"
                    return self.follow(canon.pid, canon.members[ext])
            return None
        canon = self.content_canon.get((u.kind, u.key))
        if canon is None:
            # a unique newest/survivor unit is its own canonical
            if u.pid in self.N:
                return self.follow(pid, lp)
            return None
        if u.kind == "item":
            if not all(canon.extra.get(r) == c for r, c in u.extra.items()):
                return None
            rel = next(r for r, m in u.members.items() if m == lp)
            return self.follow(canon.pid, canon.members[rel])
        ext = next(e for e, m in u.members.items() if m == lp)
        return self.follow(canon.pid, canon.members[ext])

    def follow(self, pid, lp):
        return self.strip_map.get((pid, lp), (pid, lp))

    # ------------------------------------------------------------------ old versions / residuals
    def equivalent_in_newest(self, opid, lp):
        n = self.newest[self.P[opid]["grp"]]
        e_old, e_new = self.E[opid].get(lp), self.E[n].get(lp)
        if e_new is None:
            return None
        if e_old and (e_old[1], e_old[2]) == (e_new[1], e_new[2]):
            return n
        if lp.endswith((".vmi", ".vmb")):
            base = lp[:-4] + ".vmi"
            uo, un = self.old_unit_of.get((opid, base)), self.unit_of.get((n, base))
            if uo and un and self.morph_same(un, uo):
                return n
            return None
        return n  # non-morph asset at the same path in a newer version: author update, accepted

    def plan_versions(self):
        self.old_units, self.old_unit_of = self.build_units(self.old)
        self.residual = defaultdict(set)
        sources = [pid for pid, p in self.P.items() if p["source"] == "local" or pid in self.N]
        work = []
        for pid in sources:
            src_pid = pid if pid in self.reg_pids else None
            for src, v, kind in self.refs[pid]:
                if kind != "full":
                    continue
                sr = split_ref(v)
                tp = self.pre.resolve(sr[0], src_pid)
                lp = sr[1].lower()
                if tp in self.old and lp in self.E[tp]:
                    work.append((tp, lp))
        work = [(tp, lp, False) for tp, lp in work]
        seen = set()
        while work:
            tp, lp, force = work.pop()
            if (tp, lp, force) in seen:
                continue
            seen.add((tp, lp, force))
            if not force and (tp, lp) not in self.forced_keep:
                if self.equivalent_in_newest(tp, lp) is not None:
                    continue
                if self.find_canonical_for(tp, lp, self.old_unit_of) is not None:
                    continue
            u = self.old_unit_of.get((tp, lp))
            # a frozen old version can only be kept whole (keeping part of it would mean rewriting it)
            add = set(self.E[tp]) if tp in self.frozen else set(u.members.values()) if u else {lp}
            for m in add:
                if m not in self.residual[tp]:
                    self.residual[tp].add(m)
                    # closure: what the kept file itself references
                    for src, v, kind in self.refs[tp]:
                        if src.lower() != m:
                            continue
                        if kind == "rel":  # relative paths cannot be rewired: keep the target next to it
                            work.append((tp, v, True))
                        elif kind == "full":
                            sr = split_ref(v)
                            t2 = self.pre.resolve(sr[0], tp)
                            if t2 in self.old and sr[1].lower() in self.E[t2]:
                                work.append((t2, sr[1].lower(), False))
        for tp in list(self.residual):
            if "meta.json" in self.E[tp]:
                self.residual[tp].add("meta.json")
        self.log(f"residual old versions: {len(self.residual)} packages, "
                 f"{sum(len(v) for v in self.residual.values())} files kept")

    # ------------------------------------------------------------------ post state
    def build_post(self):
        alive = self.N | set(self.residual)
        gv = {pid: (self.P[pid]["grp"], self.P[pid]["ver"]) for pid in alive}
        self.post = Registry({self.P[pid]["uid"]: pid for pid in alive}, gv)
        self.post_files = {}
        self._ci = None
        self._path_holders = None
        strip_by_pid = defaultdict(set)
        for (p, lp) in self.strip_map:
            strip_by_pid[p].add(lp)
        for pid in self.N:
            self.post_files[pid] = set(self.E[pid]) - strip_by_pid.get(pid, set())
        for pid, keep in self.residual.items():
            self.post_files[pid] = set(keep)
        self.injects = defaultdict(dict)  # pid -> {path: (archive_pid, archive_path)}

    def post_location(self, tp, lp):
        """Where pre-state content (tp, lp) is reachable after cleanup. None = lost."""
        if tp in self.N:
            return self.follow(tp, lp)
        if tp in self.residual and lp in self.residual[tp]:
            return (tp, lp)
        if tp in self.old:
            n = self.equivalent_in_newest(tp, lp)
            if n is not None and (tp, lp) not in self.forced_keep:
                return self.follow(n, lp)
            return self.find_canonical_for(tp, lp, self.old_unit_of)
        return None

    def exact_path(self, pid, lp):
        e = self.E[pid].get(lp)
        if e:
            return e[0]
        inj = self.injects.get(pid, {}).get(lp)
        return inj[2] if inj else lp

    def make_ref(self, src_pid, loc):
        pid, lp = loc
        path = self.exact_path(pid, lp)
        if pid == src_pid:
            return f"SELF:/{path}"
        return f"{self.P[pid]['uid']}:/{path}"

    # ------------------------------------------------------------------ repair
    def repair(self, prefix, lp, src_pid, value, row_pid):
        """Pre-state broken ref -> (loc, how) or (None, 'unrepaired')."""
        if prefix == "SELF":
            grp = self.P[src_pid]["grp"] if src_pid else None
        else:
            m = re.match(r"^([^.]+\.[^.]+)\.", prefix)
            grp = m.group(1) if m else None
        # a. another live version of the same package has the file
        if grp and grp in self.pre.vers:
            for ver in reversed(self.pre.vers[grp]):
                pid = self.pre.groups[grp][ver]
                if lp in self.E[pid]:
                    loc = self.post_location(pid, lp)
                    if loc:
                        return loc, "other-version"
        # b. original content from backup archives
        if grp:
            cands = sorted(self.archive.get((grp, lp), ()), reverse=True)
            for ver, apid in cands:
                loc = self.locate_archive_content(apid, lp)
                if loc:
                    self.archive_used.add(apid)
                    return loc, "archive-content"
            target = self.post.resolve(prefix, src_pid) if prefix != "SELF" else src_pid
            if cands and target in self.N and target not in self.frozen:
                ver, apid = cands[0]
                self.archive_used.add(apid)
                members = [lp]
                if lp.endswith(".vmi") and lp[:-4] + ".vmb" in self.E[apid]:
                    members.append(lp[:-4] + ".vmb")
                for m in members:
                    if m not in self.post_files[target]:
                        self.injects[target][m] = (apid, self.E[apid][m][0], self.E[apid][m][0])
                        self.post_files[target].add(m)
                return (target, lp), "inject-from-backup"
        # c. morph by display name: VaM itself falls back to GetMorphByDisplayName, so the ref is left as is
        #    (rewriting would only couple the scene to whichever package holds that name)
        if lp.endswith(".vmi"):
            name = self.mname.get((row_pid, value))
            if name and self.morph_clusters.get((morph_bank(lp), name.strip())):
                return None, "vam-name-fallback"
        # d. the exact path exists in exactly one survivor (content unverified: opt-in)
        if not self.heuristic_repair:
            return None, "unrepaired"
        if self._path_holders is None:
            ph = defaultdict(list)
            for pid in self.N:
                for f in self.post_files[pid]:
                    ph[f].append(pid)
            self._path_holders = ph
        holders = self._path_holders.get(lp, ())
        if len(holders) == 1:
            return (holders[0], lp), "unique-path"
        return None, "unrepaired"

    def locate_archive_content(self, apid, lp):
        e = self.E[apid].get(lp)
        if not e:
            return None
        if lp.endswith(".vmi"):
            meta = self.V.get((apid, lp))
            vmb = lp[:-4] + ".vmb"
            if meta is None:
                return None
            mid, disp, pose, vmin, vmax, fh = meta
            key = (morph_bank(lp), disp, mid, pose, vmin, vmax, fh, vmb in self.E[apid])
            u = Unit("morph", apid, lp, {".vmi": lp, **({".vmb": vmb} if vmb in self.E[apid] else {})}, key, lp)
            u.extra = (self.E[apid][vmb][1], self.E[apid][vmb][2]) if vmb in self.E[apid] else None
            for canon in self.morph_clusters.get((key[0], key[1]), ()):
                if self.morph_same(canon, u):
                    return self.follow(canon.pid, canon.main)
            return None
        hit = self.content_index().get((e[1], e[2]))
        return self.follow(*hit) if hit else None

    def content_index(self):
        ci = self._ci
        if ci is None:
            ci = {}
            for pid in sorted(self.N):
                for lp in sorted(self.post_files[pid]):  # sets of str iterate by hash seed: keep plans reproducible
                    e = self.E[pid].get(lp)
                    if e and strip_class(lp):
                        ci.setdefault((e[1], e[2]), (pid, lp))
            self._ci = ci
        return ci

    # ------------------------------------------------------------------ rewire + simulate
    def rewire(self):
        self.rewrites = defaultdict(lambda: defaultdict(dict))  # pid -> src -> {old: new}
        self.outcomes = Counter()
        self.regressions, self.unrepaired, self.lost = [], [], []
        self.repair_how = Counter()
        self.samples = defaultdict(list)
        self.archive_used = set()
        sources = [pid for pid, p in self.P.items()
                   if (p["source"] == "local" and p["ok"]) or pid in self.N or pid in self.residual]
        for pid in sources:
            p = self.P[pid]
            src_pid = pid if pid in self.reg_pids else None
            keep = self.residual.get(pid)
            for src, v, kind in self.refs[pid]:
                if kind != "full":
                    continue
                if keep is not None and src.lower() not in keep:
                    continue
                if pid in self.N and (pid, src.lower()) in self.strip_map:
                    continue  # the referencing file itself is stripped (its canonical copy is checked instead)
                prefix, path = split_ref(v)
                if prefix == "SELF" and src_pid is None:
                    continue
                if self.opaque(prefix):
                    self.outcomes["opaque"] += 1
                    continue
                lp = path.lower()
                tp = self.pre.resolve(prefix, src_pid)
                pre_ok = tp is not None and lp in self.E[tp]
                how = "rewired"
                if pre_ok:
                    loc = self.post_location(tp, lp)
                    if loc is None:
                        self.lost.append((tp, lp, p["uid"] or p["relpath"], src, v))
                        self.outcomes["ok->lost"] += 1
                        continue
                elif pid in self.frozen:
                    self.outcomes["frozen-source"] += 1  # already broken and can't be edited: left as it is
                    continue
                else:
                    loc, how = self.repair(prefix, lp, src_pid, v, pid)
                    if loc is None:
                        if how == "vam-name-fallback":
                            self.outcomes["broken->vam-name-fallback"] += 1
                            continue
                        self.outcomes["broken->broken"] += 1
                        self.unrepaired.append((p["uid"] or p["relpath"], src, v))
                        continue
                    self.repair_how[how] += 1
                post_tp = self.post.resolve(prefix, src_pid)
                if post_tp == loc[0] and loc[1] == lp and lp in self.post_files[post_tp]:
                    self.outcomes["ok" if pre_ok else "repaired-in-place"] += 1
                    continue
                if pid in self.frozen:
                    # can't edit this file: leave the ref; simulate() flags it if its target would go, and the
                    # regression loop then keeps that target in place
                    self.outcomes["frozen-source"] += 1
                    continue
                new = self.make_ref(src_pid, loc)
                self.rewrites[pid][src][v] = new
                self.outcomes["rewired" if pre_ok else "repaired"] += 1
                if len(self.samples[how]) < 60:
                    self.samples[how].append((p["uid"] or p["relpath"], src, v, new))

    def simulate(self):
        """Independent check: apply rewrites to every ref and resolve in the post state."""
        bad = []
        stats = Counter()
        for pid in [pid for pid, p in self.P.items()
                    if (p["source"] == "local" and p["ok"]) or pid in self.N or pid in self.residual]:
            src_pid = pid if pid in self.reg_pids else None
            keep = self.residual.get(pid)
            for src, v, kind in self.refs[pid]:
                if kind != "full":
                    continue
                if keep is not None and src.lower() not in keep:
                    continue
                if pid in self.N and (pid, src.lower()) in self.strip_map:
                    continue
                prefix, path = split_ref(v)
                if (prefix == "SELF" and src_pid is None) or self.opaque(prefix):
                    continue
                tp = self.pre.resolve(prefix, src_pid)
                pre_ok = tp is not None and path.lower() in self.E[tp]
                nv = self.rewrites.get(pid, {}).get(src, {}).get(v, v)
                np_, npath = split_ref(nv)
                t2 = self.post.resolve(np_, src_pid)
                post_ok = t2 is not None and npath.lower() in self.post_files.get(t2, ())
                stats[(pre_ok, post_ok)] += 1
                if pre_ok and not post_ok:
                    bad.append((pid, src, v, nv, tp, path.lower()))
        self.sim = stats
        self.sim_bad = bad
        return bad

    # ------------------------------------------------------------------ driver
    def _chk(self, step=None, total=6):
        if self.ctl is not None:
            if step is not None:
                self.ctl.progress(step, total)
            self.ctl.check()

    def run(self, max_iter=4):
        if self.ctl is not None:
            self.ctl.set_phase("plan", 6)
        self.load()
        self._chk(1)
        self.build_registry()
        for pid, p in self.P.items():
            why = self.skip_in.get((p["source"], p["relpath"]))
            if why is not None:
                self.frozen.add(pid)
                self.frozen_why[pid] = why or "skipped"
        while True:
            for it in range(max_iter):
                self.compute_pins()
                self._chk(2)
                self.canonicalize()
                self._chk(3)
                self.plan_versions()
                self.build_post()
                self._chk(4)
                self.rewire()
                self._chk(5)
                bad = self.simulate()
                self._chk(6)
                self.log(f"iteration {it + 1}: outcomes {dict(self.outcomes)}; simulation regressions {len(bad)}")
                if not bad and not self.lost:
                    break
                for (pid, src, v, nv, tp, lp) in bad:
                    self.forced_keep.add((tp, lp))
                for (tp, lp, *_rest) in self.lost:
                    self.forced_keep.add((tp, lp))
            # every var the plan edits must be one rewrite_zip reads exactly as the index did; any other is
            # left untouched (frozen) and the plan is worked out again around it
            odd = {}
            for pid in sorted(self.edited_live() - self.frozen):
                why = rewrite_problem(self.abspath(pid), [e[0] for e in self.E[pid].values()])
                if why:
                    odd[pid] = why
            if not odd:
                break
            for pid, why in odd.items():
                self.log(f"  skip (can't rewrite safely): {self.P[pid]['relpath']}  [{why}]")
            self.frozen.update(odd)
            self.frozen_why.update(odd)
        self.vmbs.close()
        self.db.close()
        return self

    def edited_live(self):
        """Live packages the current plan would rewrite (strip, rewire, inject, or cut down to a residual)."""
        out = {pid for (pid, _lp) in self.strip_map} | set(self.injects)
        out |= {pid for pid in self.rewrites if self.P[pid]["source"] == "live"}
        out |= {pid for pid, keep in self.residual.items() if set(self.E[pid]) - keep}
        return out

    def opaque(self, prefix):
        """Refs into packages we cannot read are left untouched (VaM may still read them)."""
        if prefix == "SELF":
            return False
        g = prefix.rsplit(".", 1)[0]
        return g in self.opaque_groups and g not in self.pre.vers

    # ------------------------------------------------------------------ plan output
    def to_plan(self):
        removes = []

        def rm(pid, **kw):
            p = self.P[pid]
            removes.append(dict(relpath=p["relpath"], uid=p["uid"], size=p["size"], mtime=p["mtime"], **kw))

        for pid in sorted(self.old - set(self.residual)):
            rm(pid, reason="old-version", newest=self.P[self.newest[self.P[pid]["grp"]]]["uid"])
        for pid, keeper in self.dup_removals:
            rm(pid, reason="duplicate-uid", keeper=self.P[keeper]["relpath"])
        for pid, stem in self.bad_names:
            rm(pid, reason="bad-name-copy", keeper=self.P[self.keeper[stem]]["relpath"])
        prefs = []
        up = os.path.join(self.vam_root, "AddonPackagesUserPrefs")
        for pid in sorted(self.old - set(self.residual)):
            p = self.P[pid]
            n = self.P[self.newest[p["grp"]]]
            a, b = os.path.join(up, p["uid"] + ".prefs"), os.path.join(up, n["uid"] + ".prefs")
            if os.path.exists(a) and not os.path.exists(b):
                prefs.append(dict(op="copy", src=os.path.relpath(a, self.vam_root), dst=os.path.relpath(b, self.vam_root)))
        # a canonical item that a duplicate-hider (VARManager) had hidden must become visible again,
        # otherwise the item disappears from the UI once its visible copies are stripped
        fp = os.path.join(self.vam_root, "AddonPackagesFilePrefs")
        seen = set()
        for (pid, lp), (cp, clp) in self.strip_map.items():
            if not clp.endswith((".vam", ".vap")) or (cp, clp) in seen:
                continue
            seen.add((cp, clp))
            h = os.path.join(fp, self.P[cp]["uid"], self.E[cp][clp][0] + ".hide")
            if os.path.exists(h) and not os.path.exists(os.path.join(fp, self.P[pid]["uid"], self.E[pid][lp][0] + ".hide")):
                prefs.append(dict(op="unhide", src=os.path.relpath(h, self.vam_root), dst=""))
        strip_by_pid = defaultdict(list)
        for (pid, lp), (cp, clp) in self.strip_map.items():
            strip_by_pid[pid].append(self.E[pid][lp][0])
        modify = {}
        touched = set(strip_by_pid) | {pid for pid in self.rewrites if self.P[pid]["source"] == "live"} | \
            set(self.residual) | set(self.injects)
        for pid in touched:
            p = self.P[pid]
            mod = dict(uid=p["uid"], size=p["size"], mtime=p["mtime"], strip=[], rewrite={}, inject={},
                       add_deps=[], residual=pid in self.residual)
            if pid in self.residual:
                keep = self.residual[pid]
                mod["strip"] = sorted(self.E[pid][lp][0] for lp in self.E[pid] if lp not in keep)
            else:
                mod["strip"] = sorted(strip_by_pid.get(pid, []))
            stripped_lower = {s.lower() for s in mod["strip"]}
            for src, mp in self.rewrites.get(pid, {}).items():
                if src.lower() in stripped_lower:
                    continue
                mod["rewrite"][src] = mp
            for lp, (apid, apath, dpath) in self.injects.get(pid, {}).items():
                mod["inject"][dpath] = dict(archive=self.P[apid]["relpath"], path=apath)
            deps = set()
            for src, mp in mod["rewrite"].items():
                for nv in mp.values():
                    pre_ = split_ref(nv)[0]
                    if pre_ != "SELF":
                        deps.add(pre_)
            have = set((p["meta"] or {}).get("dependencies") or {})
            mod["add_deps"] = sorted(d for d in deps if d not in have)
            if mod["strip"] or mod["rewrite"] or mod["inject"]:
                if pid in self.frozen:  # the simulation assumed it stays untouched: never ship such a plan
                    raise RuntimeError(f"internal: frozen package planned for change: {p['relpath']}")
                modify[p["relpath"]] = mod
        local = {}
        for pid, mp in self.rewrites.items():
            p = self.P[pid]
            if p["source"] == "local":
                local[p["relpath"]] = dict(size=p["size"], mtime=p["mtime"], rewrite=dict(mp))
        return dict(version=1, vam_root=self.vam_root, threshold=self.thr, heuristic=self.heuristic_repair,
                    remove=removes, modify=modify, local=local, prefs=prefs)

    def report(self, plan):
        GB = 1024 ** 3
        rm_size = sum(self.P[self.find_live(r["relpath"])]["size"] for r in plan["remove"])
        strip_bytes = 0
        cat = Counter()
        for (pid, lp), _ in self.strip_map.items():
            if pid in self.residual:
                continue
            strip_bytes += self.E[pid][lp][3]
            k = "morph" if lp.endswith((".vmi", ".vmb")) else ("clothing/hair" if lp.startswith(("custom/clothing/", "custom/hair/")) else
                                                              "texture" if lp.startswith("custom/atom/person/textures/") else
                                                              "assetbundle" if lp.endswith(".assetbundle") else "other")
            cat[k] += self.E[pid][lp][3]
        res_bytes = sum(self.E[pid][lp][3] for pid in self.residual for lp in self.E[pid] if lp not in self.residual[pid])
        mod_live = plan["modify"]
        morph_entries_before = sum(1 for pid in self.reg_pids for lp in self.E[pid]
                                   if lp.endswith(".vmi") and lp.startswith("custom/atom/person/morphs/"))
        morph_entries_after = sum(1 for pid in self.post_files for lp in self.post_files[pid]
                                  if lp.endswith(".vmi") and lp.startswith("custom/atom/person/morphs/"))
        r = dict(
            live_var_files=sum(1 for p in self.P.values() if p["source"] == "live"),
            packages_registered=len(self.reg_pids),
            remove_packages=Counter(x["reason"] for x in plan["remove"]),
            remove_gb=round(rm_size / GB, 2),
            residual_packages=len(self.residual),
            residual_reclaimed_gb=round(res_bytes / GB, 2),
            strip_gb=round(strip_bytes / GB, 2),
            strip_gb_by_kind={k: round(v / GB, 2) for k, v in cat.most_common()},
            modified_packages=len(mod_live),
            modified_packages_gb=round(sum(m["size"] for m in mod_live.values()) / GB, 2),
            local_files_modified=len(plan["local"]),
            refs_rewired=sum(len(mp) for m in mod_live.values() for mp in m["rewrite"].values()) +
            sum(len(mp) for m in plan["local"].values() for mp in m["rewrite"].values()),
            injects=sum(len(m["inject"]) for m in mod_live.values()),
            morph_entries_before=morph_entries_before,
            morph_entries_after=morph_entries_after,
            outcomes=dict(self.outcomes),
            repairs=dict(self.repair_how),
            simulation={f"{'ok' if a else 'broken'}->{'ok' if b else 'broken'}": n for (a, b), n in self.sim.items()},
            simulation_regressions=len(self.sim_bad),
            lost_refs=len(self.lost),
            unreadable=[self.P[p]["relpath"] for p in self.unreadable],
            skipped=[dict(source=self.P[p]["source"], relpath=self.P[p]["relpath"], reason=self.frozen_why.get(p, ""))
                     for p in sorted(self.frozen)],
            pinned_files=len(self.pins),
        )
        return r

    def find_live(self, relpath):
        if not hasattr(self, "_live_by_rel"):
            self._live_by_rel = {p["relpath"]: pid for pid, p in self.P.items() if p["source"] == "live"}
        return self._live_by_rel[relpath]
