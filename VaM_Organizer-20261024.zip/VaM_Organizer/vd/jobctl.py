"""Cooperative pause / stop for long jobs. Workers call ctl.check() at safe points."""
import collections
import threading
import time


class Cancelled(Exception):
    pass


class Control:
    def __init__(self):
        self._run = threading.Event()
        self._run.set()
        self._stop = False
        self.phase = ""
        self.n = 0
        self.total = 0
        self.lines = collections.deque(maxlen=600)
        self.seq = 0  # number of log lines ever written
        self.stoppable = True
        self.lock = threading.Lock()

    # ---- controller side
    def pause(self):
        self._run.clear()

    def resume(self):
        self._run.set()

    def stop(self):
        self._stop = True
        self._run.set()

    @property
    def paused(self):
        return not self._run.is_set()

    @property
    def stop_requested(self):
        return self._stop

    # ---- worker side
    def check(self):
        """Block while paused; raise Cancelled if a stop was requested."""
        while not self._run.wait(0.25):
            pass
        if self._stop:
            raise Cancelled()

    def set_phase(self, phase, total=0, stoppable=True):
        self.phase, self.n, self.total, self.stoppable = phase, 0, total, stoppable

    def progress(self, n, total):
        self.n, self.total = n, total
        self.check()

    def log(self, msg):
        with self.lock:
            self.lines.append((self.seq, f"{time.strftime('%H:%M:%S')} {msg}"))
            self.seq += 1

    def tail(self, since=0):
        with self.lock:
            return [line for seq, line in self.lines if seq >= since], self.seq
