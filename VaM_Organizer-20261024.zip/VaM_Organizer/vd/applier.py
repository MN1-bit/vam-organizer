"""Apply a plan: stage every new file first, verify, then commit with a move journal (rollback-able).

Nothing under the VaM folder changes until every staged package has been built and verified.
Originals are moved (same drive, instant) into <state>/backup/<ts>/, never deleted.
"""
import json
import os
import shutil
import time
import zipfile

from .jobctl import Cancelled  # noqa: F401  (re-exported for callers)
from .textrefs import decode_bytes, rewrite_bytes
from .zipraw import read_central, rewrite_zip, verify_zip


class ApplyError(Exception):
    def __init__(self, msg, skip=()):
        super().__init__(msg)
        self.skip = list(skip)  # [{source, relpath, reason}] files that could not be staged (nothing was changed)


def xp(path):
    """Extended-length path (\\\\?\\...): the backup and staging trees sit deeper than AddonPackages, so a file
    near MAX_PATH there would fail to move on PCs where Windows long-path support is off (its default)."""
    if os.name != "nt" or not path:
        return path
    p = os.path.abspath(path)
    if p.startswith("\\\\?\\"):
        return p
    if p.startswith("\\\\"):
        return "\\\\?\\UNC\\" + p[2:]
    return "\\\\?\\" + p


def vam_running():
    # in-process process list walk; spawning tasklist flashed a console window on every check
    from .detect import is_running
    return is_running("VaM.exe")


def _fingerprint_ok(path, size, mtime):
    try:
        st = os.stat(xp(path))
    except FileNotFoundError:
        return False
    return st.st_size == size and abs(st.st_mtime - mtime) < 1e-3


def _meta_with_deps(raw, add_deps):
    text, bom = decode_bytes(raw)
    meta = json.loads(text)
    deps = meta.get("dependencies")
    if not isinstance(deps, dict):
        deps = meta["dependencies"] = {}
    for d in add_deps:
        deps.setdefault(d, {"licenseType": "FC", "dependencies": {}})
    out = json.dumps(meta, ensure_ascii=False, indent=3)
    return (b"\xef\xbb\xbf" if bom else b"") + out.encode("utf-8")


class Applier:
    def __init__(self, plan_path, state_dir, log=print, progress=None, ctl=None):
        self.ctl = ctl
        if ctl is not None:
            log, progress = ctl.log, ctl.progress
        self.progress = progress or (lambda n, total: None)
        with open(plan_path, encoding="utf-8") as fh:
            self.plan = json.load(fh)
        self.vam = self.plan["vam_root"]
        self.addon = os.path.join(self.vam, "AddonPackages")
        self.ts = time.strftime("%Y%m%d-%H%M%S")
        self.backup = os.path.join(state_dir, "backup", self.ts)
        self.staging = os.path.join(state_dir, "staging", self.ts)
        self.log = log
        self.journal = None

    # ---------------------------------------------------------------- preflight
    def preflight(self):
        if vam_running():
            raise ApplyError("VaM.exe is running - close it first")
        stale = []
        for r in self.plan["remove"]:
            if not _fingerprint_ok(os.path.join(self.addon, r["relpath"]), r["size"], r["mtime"]):
                stale.append(r["relpath"])
        for rel, m in self.plan["modify"].items():
            if not _fingerprint_ok(os.path.join(self.addon, rel), m["size"], m["mtime"]):
                stale.append(rel)
        for rel, m in self.plan["local"].items():
            if not _fingerprint_ok(os.path.join(self.vam, rel), m["size"], m["mtime"]):
                stale.append(rel)
        if stale:
            raise ApplyError(f"{len(stale)} files changed since planning (re-run index+plan): {stale[:5]}")
        gone = sorted({inj["archive"] for m in self.plan["modify"].values() for inj in m["inject"].values()
                       if not os.path.exists(xp(inj["archive"]))})
        if gone:
            raise ApplyError(f"계획이 쓰는 원본 백업 var {len(gone)}개 없음 · 재분석 필요: {gone[:3]}")
        # every package a rewired reference will point at must still exist (e.g. not deleted after planning)
        live_uids = set()
        for dp, dn, fn in os.walk(xp(self.addon)):
            live_uids.update(f[:-4] for f in fn if f.lower().endswith(".var"))
        # duplicate-copy removals keep one copy of the uid; only old-version removals make a uid disappear
        removed = {r["uid"] for r in self.plan["remove"] if r.get("uid") and r["reason"] == "old-version"}
        targets = set()
        for m in list(self.plan["modify"].values()) + list(self.plan["local"].values()):
            for mp in m["rewrite"].values():
                for nv in mp.values():
                    pre = nv.split(":/", 1)[0]
                    if pre != "SELF":
                        targets.add(pre)
        missing = sorted(t for t in targets if t not in live_uids or t in removed)
        if missing:
            raise ApplyError(f"재연결 대상 패키지 {len(missing)}개 없음 · 재분석 필요: {missing[:5]}")
        need = sum(m["size"] for m in self.plan["modify"].values())
        free = shutil.disk_usage(os.path.dirname(self.staging.rstrip("\\/")) if os.path.exists(
            os.path.dirname(self.staging.rstrip("\\/"))) else self.vam).free
        if need * 1.1 > free:
            raise ApplyError(f"not enough free space for staging: need {need / 2**30:.1f} GB")

    # ---------------------------------------------------------------- stage
    def _phase(self, name, total=0, stoppable=True):
        if self.ctl is not None:
            self.ctl.set_phase(name, total, stoppable)

    def stage(self):
        os.makedirs(self.staging, exist_ok=True)
        problems = []
        total = len(self.plan["modify"])
        self._phase("stage", total)
        t0 = time.time()
        for n, (rel, m) in enumerate(sorted(self.plan["modify"].items()), 1):
            src = xp(os.path.join(self.addon, rel))
            dst = xp(os.path.join(self.staging, "AddonPackages", rel))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            try:
                self._stage_var(src, dst, m)
            except Cancelled:
                raise
            except Exception as e:
                problems.append(("live", rel, f"{type(e).__name__}: {e}"))
            self.progress(n, total)
            if n % 100 == 0:
                self.log(f"  staged {n}/{total}  {time.time() - t0:.0f}s")
        for rel, m in self.plan["local"].items():
            src = xp(os.path.join(self.vam, rel))
            dst = xp(os.path.join(self.staging, rel))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(src, "rb") as fh:
                data = fh.read()
            mapping = {}
            for mp in m["rewrite"].values():
                mapping.update(mp)
            new, k = rewrite_bytes(data, mapping)
            if k == 0:
                problems.append(("local", rel, "no reference replaced"))
            with open(dst, "wb") as fh:
                fh.write(new)
        if problems:
            raise ApplyError(f"staging failed for {len(problems)} files: {[p[1:] for p in problems[:10]]}",
                             skip=[dict(source=s, relpath=r, reason=why) for s, r, why in problems])
        self.log(f"staged {total} packages and {len(self.plan['local'])} local files")

    def _stage_var(self, src, dst, m):
        with open(src, "rb") as fh:
            entries, _ = read_central(fh)
        names = [e.name for e in entries]
        by_lower = {n.lower(): n for n in names}
        drop = {by_lower[s.lower()] for s in m["strip"]}
        replace = {}
        with zipfile.ZipFile(src) as z:
            for file_src, mapping in m["rewrite"].items():
                name = by_lower[file_src.lower()]
                if name in drop:
                    continue
                new, k = rewrite_bytes(z.read(name), mapping)
                if k == 0:
                    raise ApplyError(f"{name}: none of {len(mapping)} references found")
                replace[name] = new
            if m["add_deps"] and "meta.json" in by_lower and by_lower["meta.json"] not in drop:
                name = by_lower["meta.json"]
                try:
                    replace[name] = _meta_with_deps(replace.get(name) or z.read(name), m["add_deps"])
                except ValueError:
                    self.log(f"  note: {os.path.basename(src)} meta.json not parseable; dependencies not added")
        add = {}
        for path, inj in m["inject"].items():
            with zipfile.ZipFile(xp(inj["archive"])) as az:
                add[path] = az.read(inj["path"])
        rewrite_zip(src, dst, drop=drop, replace=replace, add=add)
        expected = [n for n in names if n not in drop] + list(add)
        verify_zip(dst, expected, check_names=list(replace) + list(add))

    # ---------------------------------------------------------------- commit
    def _move(self, a, b):
        os.makedirs(os.path.dirname(xp(b)), exist_ok=True)
        os.replace(xp(a), xp(b))  # the journal keeps the plain paths
        self.journal.write(json.dumps({"op": "move", "src": a, "dst": b}, ensure_ascii=False) + "\n")
        self.journal.flush()

    def commit(self):
        os.makedirs(self.backup, exist_ok=True)
        if getattr(self, "_plan_path_hint", None):
            shutil.copy2(self._plan_path_hint, os.path.join(self.backup, "plan.json"))
        total = len(self.plan["remove"]) + len(self.plan["modify"]) + len(self.plan["local"])
        self._phase("commit", total)
        done = 0
        with open(os.path.join(self.backup, "journal.jsonl"), "a", encoding="utf-8") as self.journal:
            for r in self.plan["remove"]:
                self._move(os.path.join(self.addon, r["relpath"]), os.path.join(self.backup, "AddonPackages", r["relpath"]))
                done += 1
                self.progress(done, total)  # a stop here is reverted by run() from the journal
            for rel in self.plan["modify"]:
                live = os.path.join(self.addon, rel)
                self._move(live, os.path.join(self.backup, "AddonPackages", rel))
                self._move(os.path.join(self.staging, "AddonPackages", rel), live)
                done += 1
                self.progress(done, total)
            for rel in self.plan["local"]:
                live = os.path.join(self.vam, rel)
                self._move(live, os.path.join(self.backup, rel))
                self._move(os.path.join(self.staging, rel), live)
                done += 1
                self.progress(done, total)
            for op in self.plan.get("prefs", []):
                a, b = os.path.join(self.vam, op["src"]), os.path.join(self.vam, op["dst"])
                if op["op"] == "copy" and os.path.exists(xp(a)) and not os.path.exists(xp(b)):
                    shutil.copy2(xp(a), xp(b))
                    self.journal.write(json.dumps({"op": "created", "path": b}) + "\n")
                elif op["op"] == "unhide" and os.path.exists(xp(a)):
                    self._move(a, os.path.join(self.backup, "unhidden", op["src"]))
        self.log(f"committed; backup + journal in {self.backup}")

    def run(self, plan_path=None):
        self._plan_path_hint = plan_path
        self._phase("preflight", stoppable=True)
        self.preflight()
        try:
            self.stage()
        except BaseException:
            # nothing under the VaM folder has changed yet: dropping the staged files is a full revert
            shutil.rmtree(xp(self.staging), ignore_errors=True)
            raise
        try:
            self.commit()
        except BaseException:
            # stopped (or failed) while moving files: put every original back from the journal
            self._phase("revert", stoppable=False)
            self.log("되돌리는 중 (저널 역순)")
            rollback(self.backup, log=self.log, check_running=False)
            shutil.rmtree(xp(self.staging), ignore_errors=True)
            raise
        shutil.rmtree(xp(self.staging), ignore_errors=True)
        return self.backup


def rollback(backup_dir, log=print, check_running=True):
    """Undo a commit by replaying its move journal backwards. Safe to re-run: undone moves are skipped."""
    if check_running and vam_running():
        raise ApplyError("VaM.exe is running - close it first")
    path = os.path.join(backup_dir, "journal.jsonl")
    with open(path, encoding="utf-8") as fh:
        ops = [json.loads(line) for line in fh if line.strip()]
    for op in reversed(ops):
        if op["op"] == "move":
            if os.path.exists(xp(op["dst"])):
                os.makedirs(os.path.dirname(xp(op["src"])), exist_ok=True)
                os.replace(xp(op["dst"]), xp(op["src"]))
        elif op["op"] == "created" and os.path.exists(xp(op["path"])):
            os.remove(xp(op["path"]))
    os.replace(path, path + ".rolledback")
    log(f"rolled back {len(ops)} operations from {backup_dir}")
