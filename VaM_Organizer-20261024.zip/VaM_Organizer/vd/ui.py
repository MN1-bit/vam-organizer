"""VaM 정리기 — a native Windows window (Tk). One local program: no browser, no server, no network."""
import base64
import collections
import ctypes
import ctypes.wintypes
import json
import os
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import filedialog
from tkinter import font as tkfont

from . import appstate, detect, gfx, ops
from .applier import vam_running

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")
with open(os.path.join(HERE, "i18n.json"), encoding="utf-8") as _fh:
    I18N = json.load(_fh)
LANGS = appstate.LANGS
FONT_FAMILY = {"ko": "Malgun Gothic", "ja": "Yu Gothic UI", "zh": "Microsoft YaHei UI", "en": "Segoe UI", "es": "Segoe UI"}
APP_ID = "CKNMN.VaMOrganizer"
COFFEE_URL = "https://buymeacoffee.com/cknmn"
THEMES = {
    "light": dict(bg="#f5f5fa", card="#ffffff", line="#e4e3ee", line2="#ecebf3", text="#1b1a24", sub="#4a4858",
                  mute="#615f70", accent="#6250d6", accent_ink="#ffffff", accent_strong="#4b3bc4", accent_soft="#f3f1ff",
                  track="#ebe9f6", before="#c9c7d8", good_bg="#e7f6ec", good_ink="#006300", good_mark="#0ca30c",
                  bad_bg="#fff5f5", bad_line="#f0c4c4", bad_ink="#a82222", bad_solid="#a82222", warn_bg="#fff4e0",
                  warn_ink="#7a4b00", chip="#f7f7fb", input="#ffffff", hover="#efedf9",
                  series=("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"), mark=("#111111", "#ffffff")),
    "dark": dict(bg="#121118", card="#1c1b24", line="#2e2c3a", line2="#272533", text="#f0eff6", sub="#b8b5c9",
                 mute="#9a97ad", accent="#8f80ff", accent_ink="#0f0c24", accent_strong="#b3a8ff", accent_soft="#2a2545",
                 track="#2c2940", before="#4a4760", good_bg="#15301c", good_ink="#6fdc7f", good_mark="#0ca30c",
                 bad_bg="#2a1414", bad_line="#5c2626", bad_ink="#ff9a9a", bad_solid="#d03b3b", warn_bg="#33270f",
                 warn_ink="#f5c46b", chip="#24222f", input="#15141c", hover="#26233a",
                 series=("#3987e5", "#d95926", "#199e70", "#c98500", "#d55181"), mark=("#f0eff6", "#121118")),
}


def b64(data):
    return base64.b64encode(data)


# Chinese/Japanese line breaking. Tk wraps only at spaces, so a Japanese sentence with one Latin word ("VaM") broke
# right after that word instead of where the line was full. Hangul is not included: Korean breaks at spaces.
_CJK = "　-ヿ㐀-䶿一-鿿豈-﫿＀-￯"
_CJK_RE = re.compile(f"[{_CJK}]")
_UNIT_RE = re.compile(f"\\s+|[{_CJK}]|[^\\s{_CJK}]+")
_NO_START = set("、。，．・：；？！ー）」』】〕〉》〙〗〟’”ゝゞヽヾぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮヵヶ々…‥,.!?:;)]}%")
_NO_END = set("（「『【〔〈《〘〖〝‘“([{")


def wrap_cjk(text, measure, width):
    """Insert line breaks so CJK text fills each line (kinsoku: no closing mark starts a line, no opening one ends
    it). Text without CJK characters is returned unchanged for Tk's own space-based wrapping."""
    if not width or not text or not _CJK_RE.search(text):
        return text
    out = []
    for para in text.split("\n"):
        units = []
        for u in _UNIT_RE.findall(para):
            if units and not units[-1].isspace() and not u.isspace() and (u[0] in _NO_START or units[-1][-1] in _NO_END):
                units[-1] += u
            else:
                units.append(u)
        lines, cur = [], ""
        for u in units:
            if u.isspace():
                if cur and measure(cur + u) <= width:
                    cur += u
                elif cur:
                    lines.append(cur.rstrip())
                    cur = ""
            elif not cur or measure(cur + u) <= width:
                cur += u
            else:
                lines.append(cur.rstrip())
                cur = u
        lines.append(cur.rstrip())
        out.append("\n".join(lines))
    return "\n".join(out)


def work_area(root):
    """Primary monitor minus the taskbar, in pixels: (x, y, w, h)."""
    r = ctypes.wintypes.RECT()
    try:
        if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0):  # SPI_GETWORKAREA
            return r.left, r.top, r.right - r.left, r.bottom - r.top
    except (AttributeError, OSError):
        pass
    return 0, 0, root.winfo_screenwidth(), root.winfo_screenheight()


def chrome_size():
    """Frame width/height that geometry() leaves out (borders, title bar), as Windows draws them on this PC."""
    try:
        m = ctypes.windll.user32.GetSystemMetrics
        pad = m(92)  # SM_CXPADDEDBORDER
        return 2 * (m(32) + pad), m(4) + 2 * (m(33) + pad)  # SM_CXSIZEFRAME; SM_CYCAPTION + SM_CYSIZEFRAME
    except (AttributeError, OSError):
        return 16, 40


# ------------------------------------------------------------------------------------------------ drawing kit
class Kit:
    """Fonts, cached anti-aliased images and shape helpers shared by every canvas."""

    def __init__(self, root, k):
        self.root, self.k = root, k
        self.ow = max(1, round(k))
        self._img = {}
        self.T = THEMES["light"]
        self.lang = "ko"

    def px(self, v):
        return int(round(v * self.k))

    def font(self, role, lang=None):
        fam = FONT_FAMILY[lang or self.lang]
        return {"h1": (fam, 22, "bold"), "h2": (fam, 15, "bold"), "h3": (fam, 13, "bold"), "body": (fam, 11),
                "bold": (fam, 11, "bold"), "small": (fam, 9), "smallb": (fam, 9, "bold"), "hero": (fam, 34, "bold"),
                "btn": (fam, 11, "bold"), "btns": (fam, 10, "bold"), "big": (fam, 24, "bold"),
                "mono": ("Consolas", 9)}[role]

    def corners(self, r, fill, outline):
        key = ("c", r, fill, outline)
        if key not in self._img:
            pngs = gfx.corner_pngs(r, fill, outline, self.ow)
            self._img[key] = {n: tk.PhotoImage(master=self.root, data=b64(d)) for n, d in pngs.items()}
        return self._img[key]

    def wrap(self, text, font, width):
        key = ("font", font)
        if key not in self._img:
            self._img[key] = tkfont.Font(root=self.root, font=font)
        return wrap_cjk(text, self._img[key].measure, width)

    def mark(self, size):
        tile, glyph = self.T["mark"]  # inverted on the dark theme so the tile does not vanish into the page
        key = ("m", size, tile)
        if key not in self._img:
            self._img[key] = tk.PhotoImage(master=self.root, data=b64(gfx.mark_png(size, tile=tile, glyph=glyph)))
        return self._img[key]

    def rrect(self, cv, x, y, w, h, r, fill, outline=None, tags=()):
        x, y, w, h = int(x), int(y), int(w), int(h)
        r = int(max(1, min(r, h // 2, w // 2)))
        imgs = self.corners(r, fill, outline)
        cv.create_rectangle(x + r, y, x + w - r, y + h, fill=fill, width=0, tags=tags)
        cv.create_rectangle(x, y + r, x + w, y + h - r, fill=fill, width=0, tags=tags)
        if outline:
            o = self.ow
            for x0, y0, x1, y1 in ((x + r, y, x + w - r, y + o), (x + r, y + h - o, x + w - r, y + h),
                                   (x, y + r, x + o, y + h - r), (x + w - o, y + r, x + w, y + h - r)):
                cv.create_rectangle(x0, y0, x1, y1, fill=outline, width=0, tags=tags)
        cv.create_image(x, y, image=imgs["tl"], anchor="nw", tags=tags)
        cv.create_image(x + w, y, image=imgs["tr"], anchor="ne", tags=tags)
        cv.create_image(x, y + h, image=imgs["bl"], anchor="sw", tags=tags)
        cv.create_image(x + w, y + h, image=imgs["br"], anchor="se", tags=tags)

    def icon(self, cv, name, x, y, s, color, tags=(), under=None):
        """Simple stroke icons in an s x s box at (x, y). `under` = fill colour behind the icon (for cut-outs)."""
        k = s / 24.0
        w = max(1.5, 2.2 * k)

        def P(*pts):
            return [v * k + (x if i % 2 == 0 else y) for i, v in enumerate(pts)]

        line = dict(fill=color, width=w, capstyle="round", joinstyle="round", tags=tags)
        if name == "play":
            cv.create_polygon(*P(8, 5, 19, 12, 8, 19), fill=color, outline=color, tags=tags)
        elif name == "pause":
            cv.create_rectangle(*P(6, 5, 10, 19), fill=color, width=0, tags=tags)
            cv.create_rectangle(*P(14, 5, 18, 19), fill=color, width=0, tags=tags)
        elif name == "stop":
            cv.create_rectangle(*P(6, 6, 18, 18), fill=color, width=0, tags=tags)
        elif name == "revert":
            cv.create_line(*P(9, 14, 4, 9, 9, 4), **line)
            cv.create_line(*P(4, 9, 14, 9), **line)
            cv.create_arc(*P(8, 9, 20, 21), start=-90, extent=180, style="arc", outline=color, width=w, tags=tags)
            cv.create_line(*P(14, 21, 11, 21), **line)
        elif name == "trash":
            cv.create_line(*P(3, 6, 21, 6), **line)
            cv.create_line(*P(8, 6, 8, 4, 16, 4, 16, 6), **line)
            cv.create_line(*P(6, 6, 7, 20, 17, 20, 18, 6), **line)
        elif name == "scan":
            cv.create_oval(*P(4, 4, 18, 18), outline=color, width=w, tags=tags)
            cv.create_line(*P(16, 16, 20.5, 20.5), **line)
        elif name == "folder":
            cv.create_line(*P(3, 7, 3, 18, 21, 18, 21, 8, 11, 8, 9, 6, 3, 6, 3, 7), **line)
        elif name == "copy":
            cv.create_rectangle(*P(9, 9, 20, 20), outline=color, width=w, tags=tags)
            cv.create_line(*P(5, 15, 5, 4, 16, 4), **line)
        elif name == "check":
            cv.create_line(*P(5, 12, 10, 17, 19, 6), **line)
        elif name == "shield":
            cv.create_line(*P(12, 3, 20, 6, 20, 12, 12, 21, 4, 12, 4, 6, 12, 3), **line)
            cv.create_line(*P(9, 12, 11, 14, 15, 10), **line)
        elif name == "warn":
            cv.create_line(*P(12, 3, 22, 20, 2, 20, 12, 3), **line)
            cv.create_line(*P(12, 10, 12, 14), **line)
            cv.create_oval(*P(11.2, 16.6, 12.8, 18.2), fill=color, outline=color, tags=tags)
        elif name == "sun":
            cv.create_oval(*P(8, 8, 16, 16), outline=color, width=w, tags=tags)
            for a, b, c, d in ((12, 2, 12, 4), (12, 20, 12, 22), (2, 12, 4, 12), (20, 12, 22, 12),
                               (5, 5, 6.4, 6.4), (17.6, 17.6, 19, 19), (5, 19, 6.4, 17.6), (17.6, 6.4, 19, 5)):
                cv.create_line(*P(a, b, c, d), **line)
        elif name == "moon":  # crescent: a disc with an offset disc of the background colour cut out of it
            cv.create_oval(*P(4, 4, 20, 20), fill=color, outline=color, tags=tags)
            cut = under or self.T["card"]
            cv.create_oval(*P(9.5, 1.5, 23.5, 15.5), fill=cut, outline=cut, tags=tags)
        elif name == "chev_r":
            cv.create_line(*P(9, 6, 15, 12, 9, 18), **line)
        elif name == "chev_d":
            cv.create_line(*P(6, 9, 12, 15, 18, 9), **line)
        elif name == "coffee":
            cv.create_line(*P(8.5, 2.5, 8.5, 5.5), **line)  # steam
            cv.create_line(*P(12.5, 2.5, 12.5, 5.5), **line)
            cv.create_line(*P(4, 9, 17, 9, 15.5, 19, 5.5, 19, 4, 9), **line)  # cup
            cv.create_arc(*P(14, 10.5, 21, 16.5), start=-90, extent=180, style="arc", outline=color, width=w,
                          tags=tags)  # handle
        elif name == "globe":
            cv.create_oval(*P(3, 3, 21, 21), outline=color, width=w, tags=tags)
            cv.create_oval(*P(8, 3, 16, 21), outline=color, width=w, tags=tags)
            cv.create_line(*P(3, 12, 21, 12), **line)


class Pill(tk.Canvas):
    """Rounded button drawn with anti-aliased caps; keyboard and mouse accessible."""
    KINDS = ("default", "primary", "danger", "solid", "ghost", "selected")

    def __init__(self, master, kit, text, command, kind="default", icon=None, small=False, disabled=False,
                 bg=None, lang=None):
        self.kit, self.text, self.command, self.kind, self.ic = kit, text, command, kind, icon
        self.disabled = disabled
        self.lang = lang
        f = kit.font("btns" if small else "btn", lang)
        self.fnt = f
        k = kit.k
        self.h = kit.px(40 if small else 46)
        self.pad = kit.px(14 if small else 20)
        self.isz = kit.px(18)
        tw = tkfont.Font(root=master, font=f).measure(text) if text else 0
        self.w = tw + 2 * self.pad + (self.isz + kit.px(8) if icon and text else self.isz if icon else 0)
        if icon and not text:
            self.w = self.h
        self.bgc = bg or kit.T["card"]
        super().__init__(master, width=self.w, height=self.h, bg=self.bgc, highlightthickness=0, bd=0,
                         takefocus=0 if disabled else 1, cursor="arrow" if disabled else "hand2")
        self.hover = self.focus = False
        self.draw()
        if not disabled:
            self.bind("<Enter>", lambda e: self._set(hover=True))
            self.bind("<Leave>", lambda e: self._set(hover=False))
            self.bind("<FocusIn>", lambda e: self._set(focus=True))
            self.bind("<FocusOut>", lambda e: self._set(focus=False))
            self.bind("<Button-1>", lambda e: self.after(1, self.command))
            self.bind("<Return>", lambda e: self.command())
            self.bind("<space>", lambda e: self.command())

    def _set(self, hover=None, focus=None):
        if hover is not None:
            self.hover = hover
        if focus is not None:
            self.focus = focus
        self.draw()

    def colors(self):
        T = self.kit.T
        c = {"default": (T["card"], T["line"], T["text"]), "primary": (T["accent"], T["accent"], T["accent_ink"]),
             "danger": (T["bad_bg"], T["bad_line"], T["bad_ink"]), "solid": (T["bad_solid"], T["bad_solid"], "#ffffff"),
             "ghost": (self.bgc, None, T["sub"]), "selected": (T["accent_soft"], T["accent"], T["text"])}[self.kind]
        fill, line, ink = c
        if self.hover and not self.disabled:
            if self.kind == "primary":
                fill = line = T["accent_strong"]
            elif self.kind in ("default", "ghost"):
                fill, line = T["hover"], line and T["accent"]
        if self.disabled:
            ink = T["mute"] if self.kind not in ("primary", "solid") else ink
            if self.kind == "primary":
                fill = line = T["before"]
        if self.focus:
            line = T["accent"] if self.kind != "primary" else T["accent_strong"]
        return fill, line, ink

    def draw(self):
        self.delete("all")
        fill, line, ink = self.colors()
        self.kit.rrect(self, 0, 0, self.w, self.h, self.h // 2, fill, line)
        x = self.pad if self.text else (self.w - self.isz) // 2
        if self.ic:
            self.kit.icon(self, self.ic, x, (self.h - self.isz) // 2, self.isz, ink, under=fill)
            x += self.isz + self.kit.px(8)
        if self.text:
            self.create_text(x, self.h // 2, text=self.text, font=self.fnt, fill=ink, anchor="w")


class SlimScroll(tk.Canvas):
    """Thin rounded scrollbar in the theme's colours (the native Windows scrollbar cannot be recoloured)."""

    def __init__(self, master, kit, command, bg):
        self.kit, self.command = kit, command
        super().__init__(master, width=kit.px(12), bg=bg, highlightthickness=0, bd=0)
        self.first, self.last = 0.0, 1.0
        self.hover = False
        self.drag = None
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Enter>", lambda e: self._hover(True))
        self.bind("<Leave>", lambda e: self._hover(False))
        self.bind("<ButtonPress-1>", self._press)
        self.bind("<B1-Motion>", self._motion)
        self.bind("<ButtonRelease-1>", lambda e: self._release())

    def set(self, first, last):  # called through yscrollcommand
        self.first, self.last = float(first), float(last)
        self.draw()

    def _hover(self, on):
        self.hover = on
        self.draw()

    def _release(self):
        self.drag = None
        self.draw()

    def _track(self):
        pad = self.kit.px(3)
        return pad, max(1, self.winfo_height() - 2 * pad)

    def _thumb(self):
        pad, span = self._track()
        y0 = pad + span * self.first
        y1 = max(y0 + self.kit.px(28), pad + span * self.last)
        return y0, min(y1, pad + span)

    def draw(self):
        self.delete("all")
        if self.last - self.first >= 0.999:
            return  # nothing to scroll: no bar
        T = self.kit.T
        tw = self.kit.px(8 if (self.hover or self.drag) else 6)
        y0, y1 = self._thumb()
        color = T["mute"] if (self.hover or self.drag) else T["before"]
        self.kit.rrect(self, (self.winfo_width() - tw) // 2, y0, tw, y1 - y0, tw // 2, color)

    def _press(self, e):
        y0, y1 = self._thumb()
        if y0 <= e.y <= y1:
            self.drag = (e.y, self.first)
        else:
            self.command("scroll", -1 if e.y < y0 else 1, "pages")

    def _motion(self, e):
        if self.drag:
            _, span = self._track()
            self.command("moveto", self.drag[1] + (e.y - self.drag[0]) / span)


def style_titlebar(win, T, dark):
    """Colour the Windows title bar to match the theme (dark mode flag; exact caption colour on Windows 11)."""
    try:
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        dwm = ctypes.windll.dwmapi
        flag = ctypes.c_int(1 if dark else 0)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (19 on early Windows 10 builds)
            if dwm.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(flag), 4) == 0:
                break

        def colorref(h):
            r, g, b = gfx.hex_rgb(h)
            return ctypes.c_int(r | (g << 8) | (b << 16))

        dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(colorref(T["bg"])), 4)    # DWMWA_CAPTION_COLOR
        dwm.DwmSetWindowAttribute(hwnd, 36, ctypes.byref(colorref(T["text"])), 4)  # DWMWA_TEXT_COLOR
        ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0027)  # NOSIZE|NOMOVE|NOZORDER|FRAMECHANGED
    except (AttributeError, OSError, tk.TclError):
        pass


# ------------------------------------------------------------------------------------------------ the window
class App:
    def __init__(self, root):
        self.root = root
        self.k = max(1.0, root.winfo_fpixels("1i") / 96.0)
        self.kit = Kit(root, self.k)
        self.s = appstate.load_settings()
        self.lang = self.s["lang"]
        self.kit.lang = self.lang
        self.set_theme(self.s["theme"], save=False)
        self.q = queue.Queue()
        self.job = None
        self.job_seq = 0
        self.log = collections.deque(maxlen=900)
        self.notice = None
        self.last_verify = None
        self.open_breakdown = False
        self.open_log = False
        self.widgets = []
        self.run_refs = None
        self.dialog = None
        self.closing = False
        self.spin = 0
        self.data = appstate.snapshot(self.s)

        root.title(self.t("app.title"))
        # fit the work area (a 1366x768 laptop must not lose the bottom of the window) and centre in it
        ax, ay, aw, ah = work_area(root)
        cw, ch = chrome_size()
        w, h = min(self.kit.px(1100), aw - cw), min(self.kit.px(920), ah - ch)
        root.geometry(f"{w}x{h}+{ax + max(0, (aw - w - cw) // 2)}+{ay + max(0, (ah - h - ch) // 2)}")
        root.minsize(min(self.kit.px(860), w), min(self.kit.px(600), h))
        self.cv = tk.Canvas(root, highlightthickness=0, bd=0, yscrollincrement=self.kit.px(30))
        self.sb = SlimScroll(root, self.kit, self.cv.yview, bg=self.T["bg"])
        self.cv.configure(yscrollcommand=self.sb.set)
        self._titlebar_theme = None
        self.cv.pack(side="left", fill="both", expand=True)
        self.sb.pack(side="right", fill="y")
        self.toast_lbl = tk.Label(root, font=self.kit.font("bold"), padx=self.kit.px(18), pady=self.kit.px(10))
        self._resize_after = None
        self.cv.bind("<Configure>", self._on_resize)
        root.bind_all("<MouseWheel>", self._wheel)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        threading.Thread(target=self._watch_vam, daemon=True).start()
        self.render()
        # the frame window exists only once Tk has mapped it: colour the title bar again after that
        self.root.after(120, lambda: style_titlebar(self.root, self.T, self.s["theme"] == "dark"))
        self.root.after(200, self.tick)
        if not self.s.get("setup_done"):
            self.root.after(300, lambda: self.folder_dialog(welcome=True))

    # ---------------------------------------------------------------- basics
    def t(self, key, **v):
        s = I18N.get(self.lang, {}).get(key)
        if s is None:
            s = I18N["ko"].get(key, key)
        for n, val in v.items():
            s = s.replace("{" + n + "}", str(val))
        return s

    def num(self, n):
        s = f"{int(round(n or 0)):,}"
        return s.replace(",", ".") if self.lang == "es" else s

    def gb(self, x):
        s = f"{(x or 0):.1f}"
        return (s.replace(".", ",") if self.lang == "es" else s) + " GB"

    def bytes_gb(self, b):
        return self.gb((b or 0) / 1073741824)

    @staticmethod
    def when(ts):
        try:
            return f"{ts[0:4]}-{ts[4:6]}-{ts[6:8]} {ts[9:11]}:{ts[11:13]}"
        except (TypeError, IndexError):
            return ts or ""

    def set_theme(self, name, save=True):
        self.s["theme"] = name
        self.kit.T = self.T = THEMES[name]
        if save:
            appstate.save_settings(self.s)

    def save(self):
        appstate.save_settings(self.s)

    def refresh(self):
        self.data = appstate.snapshot(self.s)

    def post(self, fn):
        """Run fn on the Tk thread (workers must not touch widgets)."""
        self.q.put(fn)

    def toast(self, msg):
        T = self.T
        self.toast_lbl.configure(text=msg, bg=T["text"], fg=T["bg"])
        self.toast_lbl.place(relx=0.5, rely=1.0, y=-self.kit.px(24), anchor="s")
        self.toast_lbl.lift()
        self.root.after(3200, self.toast_lbl.place_forget)

    def _on_resize(self, _e):
        if self._resize_after:
            self.root.after_cancel(self._resize_after)
        self._resize_after = self.root.after(120, self.render)

    def _wheel(self, e):
        w = e.widget
        if isinstance(w, tk.Text) or str(w).startswith(str(self.dialog) if self.dialog else "!none"):
            return
        self.cv.yview_scroll(int(-e.delta / 120), "units")

    def _watch_vam(self):
        last = self.data["vam_running"]
        while True:
            time.sleep(4)
            now = vam_running()  # in-process check, no console window
            if now != last:
                last = now
                self.post(self._vam_changed)

    def _vam_changed(self):
        self.refresh()
        if not self.running():
            self.render()

    # ---------------------------------------------------------------- state helpers
    def running(self):
        return self.job is not None and not self.job.done

    def applied_backup(self):
        b = next((x for x in self.data["backups"] if x["status"] == "applied"), None)
        if b and (not self.data["plan"] or b["name"] > self.data["plan"]["ts"]):
            return b
        return None

    def main_state(self):
        if self.running():
            return "running"
        if not self.data["vam_ok"]:
            return "setup"
        if self.applied_backup():
            return "applied"
        if not self.data["plan"]:
            return "noplan"
        return "plan"

    def numbers(self):
        r = self.data["plan"]["report"]
        sim, oc, kinds = r.get("simulation", {}), r.get("outcomes", {}), r.get("strip_gb_by_kind", {})
        removes = sum((r.get("remove_packages") or {}).values())
        return dict(
            r=r, removes=removes,
            freed=(r.get("remove_gb") or 0) + (r.get("strip_gb") or 0) + (r.get("residual_reclaimed_gb") or 0),
            morph_b=r.get("morph_entries_before", 0), morph_a=r.get("morph_entries_after", 0),
            broken_b=sim.get("broken->ok", 0) + sim.get("broken->broken", 0), broken_a=sim.get("broken->broken", 0),
            fixed=sim.get("broken->ok", 0), vars_b=r.get("live_var_files", 0),
            vars_a=max(0, r.get("live_var_files", 0) - removes), remaining=oc.get("broken->broken", 0),
            kinds=[("texture", kinds.get("texture", 0)), ("packages", r.get("remove_gb", 0)),
                   ("assetbundle", kinds.get("assetbundle", 0)), ("other", kinds.get("other", 0)),
                   ("items", kinds.get("clothing/hair", 0) + kinds.get("morph", 0) + (r.get("residual_reclaimed_gb") or 0))],
            expected_backup=(r.get("remove_gb") or 0) + (r.get("modified_packages_gb") or 0))

    # ---------------------------------------------------------------- render
    def render(self):
        self._resize_after = None
        cv, T, kit = self.cv, self.T, self.kit
        for w in self.widgets:
            w.destroy()
        self.widgets, self.run_refs = [], None
        cv.delete("all")
        cv.configure(bg=T["bg"])
        self.root.configure(bg=T["bg"])
        self.sb.configure(bg=T["bg"])
        self.sb.draw()
        if self._titlebar_theme != self.s["theme"]:
            self._titlebar_theme = self.s["theme"]
            style_titlebar(self.root, T, self.s["theme"] == "dark")
        self.root.title(self.t("app.title"))
        cw = max(cv.winfo_width(), kit.px(860))
        W = min(cw - kit.px(56), kit.px(1040))
        X = (cw - W) // 2
        gap = kit.px(20)
        y = kit.px(26)
        y = self.draw_header(X, y, W) + gap
        y = self.draw_steps(X, y, W) + gap
        if self.notice:
            y = self.draw_notice(X, y, W, *self.notice) + gap
        y = self.draw_main(X, y, W) + gap
        y = self.draw_lower(X, y, W) + gap
        y = self.draw_log(X, y, W) + gap
        fh = kit.px(56)
        y = max(y + kit.px(8), cv.winfo_height() - fh - kit.px(22))
        y = self.draw_footer(X, y, W) + kit.px(22)
        cv.configure(scrollregion=(0, 0, cw, y))

    def text(self, x, y, s, font, color, width=None, anchor="nw", tags=()):
        s = self.kit.wrap(s, font, width)
        it = self.cv.create_text(x, y, text=s, font=font, fill=color, width=width, anchor=anchor, tags=tags)
        x0, y0, x1, y1 = self.cv.bbox(it)
        return it, y1 - y0, x1 - x0

    def pill(self, x, y, text, cmd, anchor="nw", **kw):
        p = Pill(self.cv, self.kit, text, cmd, lang=self.lang, **kw)
        self.cv.create_window(x, y, window=p, anchor=anchor)
        self.widgets.append(p)
        return p

    def row_of_pills(self, x, y, w, specs, bg):
        """specs: [(text, cmd, kwargs)] laid out left to right, wrapping. Returns bottom y."""
        cx, cy, line_h = x, y, 0
        gap = self.kit.px(10)
        for text, cmd, kw in specs:
            p = Pill(self.cv, self.kit, text, cmd, bg=bg, lang=self.lang, **kw)
            if cx > x and cx + p.w > x + w:
                cx, cy = x, cy + line_h + gap
                line_h = 0
            self.cv.create_window(cx, cy, window=p, anchor="nw")
            self.widgets.append(p)
            cx += p.w + gap
            line_h = max(line_h, p.h)
        return cy + line_h

    def card_bg(self, x, y, w, h, tag, fill=None, outline=None):
        self.kit.rrect(self.cv, x, y, w, h, self.kit.px(24), fill or self.T["card"], outline or self.T["line"], tags=(tag,))
        self.cv.tag_lower(tag)

    def draw_header(self, X, y, W):
        kit, T = self.kit, self.T
        right = X + W
        ps = [Pill(self.cv, kit, self.t("top.folders"), self.folder_dialog, icon="folder", small=True, bg=T["bg"],
                   lang=self.lang),
              Pill(self.cv, kit, "", self.toggle_theme, icon="moon" if self.s["theme"] == "light" else "sun",
                   small=True, bg=T["bg"], lang=self.lang),
              Pill(self.cv, kit, I18N[self.lang]["native"], self.lang_menu, icon="globe", small=True, bg=T["bg"],
                   lang=self.lang)]
        cx = right
        for p in ps:
            cx -= p.w
            self.cv.create_window(cx, y, window=p, anchor="nw")
            self.widgets.append(p)
            cx -= kit.px(8)
        self.lang_btn = ps[2]
        _, h1, _ = self.text(X, y, self.t("app.title"), kit.font("h1"), T["text"])
        _, h2, _ = self.text(X, y + h1 + kit.px(4), self.t("app.tagline"), kit.font("body"), T["sub"],
                             width=min(W * 0.62, cx - X - kit.px(20)))
        return y + max(h1 + kit.px(4) + h2, ps[0].h)

    def draw_steps(self, X, y, W):
        kit, T, cv = self.kit, self.T, self.cv
        st = self.main_state()
        kind = self.job.kind if self.running() else None
        has_plan, applied = bool(self.data["plan"]), bool(self.applied_backup())
        any_applied = any(b["status"] == "applied" for b in self.data["backups"])
        steps = [["folders", "done" if self.data["vam_ok"] else "cur"],
                 ["analyze", "cur" if kind == "plan" else "done" if (has_plan or applied) else "cur" if self.data["vam_ok"] else "todo"],
                 ["review", "done" if applied else "cur" if (has_plan and st == "plan") else "todo"],
                 ["apply", "cur" if kind == "apply" else "done" if applied else "todo"],
                 ["cleanup", "cur" if kind == "delete" else ("cur" if any_applied else "done") if applied else "todo"]]
        seen = False
        for s in steps:
            if s[1] == "cur":
                if seen:
                    s[1] = "todo"
                seen = True
        gap = kit.px(10)
        bw = (W - 4 * gap) // 5
        h = kit.px(54)
        for i, (key, state) in enumerate(steps):
            x = X + i * (bw + gap)
            fill = T["accent"] if state == "cur" else T["card"]
            kit.rrect(cv, x, y, bw, h, kit.px(14), fill, None if state == "cur" else T["line"])
            d = kit.px(30)
            dx, dy = x + kit.px(12), y + (h - d) // 2
            if state == "done":
                kit.rrect(cv, dx, dy, d, d, d // 2, T["good_bg"])
                kit.icon(cv, "check", dx + kit.px(7), dy + kit.px(7), kit.px(16), T["good_ink"])
            elif state == "cur":
                kit.rrect(cv, dx, dy, d, d, d // 2, T["card"])
                cv.create_text(dx + d // 2, dy + d // 2, text=str(i + 1), font=kit.font("smallb"), fill=T["accent_strong"])
            else:
                kit.rrect(cv, dx, dy, d, d, d // 2, T["before"])
                kit.rrect(cv, dx + kit.ow * 2, dy + kit.ow * 2, d - kit.ow * 4, d - kit.ow * 4, d // 2 - kit.ow * 2, T["card"])
                cv.create_text(dx + d // 2, dy + d // 2, text=str(i + 1), font=kit.font("smallb"), fill=T["sub"])
            ink = T["accent_ink"] if state == "cur" else T["sub"] if state == "todo" else T["text"]
            cv.create_text(dx + d + kit.px(10), y + h // 2, text=kit.wrap(self.t("step." + key), kit.font("bold"),
                                                                         bw - d - kit.px(30)),
                           font=kit.font("bold"), fill=ink, anchor="w", width=bw - d - kit.px(30))
        return y + h

    def draw_notice(self, X, y, W, kind, msg):
        kit, T = self.kit, self.T
        fill, ink = {"good": (T["good_bg"], T["good_ink"]), "bad": (T["bad_bg"], T["bad_ink"]),
                     "warn": (T["warn_bg"], T["warn_ink"])}[kind]
        tag = "notice"
        p = Pill(self.cv, kit, self.t("btn.ok"), self.dismiss_notice, small=True, bg=fill, lang=self.lang)
        _, th, _ = self.text(X + kit.px(48), y + kit.px(16), msg, kit.font("bold"), ink, width=W - kit.px(80) - p.w)
        h = max(th, p.h) + kit.px(32)
        kit.icon(self.cv, "warn" if kind != "good" else "check", X + kit.px(16), y + kit.px(16), kit.px(20), ink)
        self.cv.create_window(X + W - kit.px(14), y + (h - p.h) // 2, window=p, anchor="ne")
        self.widgets.append(p)
        kit.rrect(self.cv, X, y, W, h, kit.px(16), fill, tags=(tag,))
        self.cv.tag_lower(tag)
        return y + h

    def dismiss_notice(self):
        self.notice = None
        self.render()

    # ---------------------------------------------------------------- main card
    def draw_main(self, X, y, W):
        st = self.main_state()
        kit, T = self.kit, self.T
        pad = kit.px(26)
        x, w = X + pad, W - 2 * pad
        cy = y + pad
        if st == "running":
            cy = self.draw_running(x, cy, w)
        elif st == "setup":
            cy = self.title_body(x, cy, w, "setup.title", "setup.body")
            cy = self.row_of_pills(x, cy + kit.px(16), w, [(self.t("setup.btn"), self.folder_dialog,
                                                            dict(kind="primary", icon="scan"))], T["card"])
        elif st == "noplan":
            cy = self.title_body(x, cy, w, "noplan.title", "noplan.body")
            cy = self.row_of_pills(x, cy + kit.px(16), w, [(self.t("btn.analyze"), self.run_plan,
                                                            dict(kind="primary", icon="scan"))], T["card"])
        elif st == "applied":
            cy = self.draw_applied(x, cy, w)
        else:
            cy = self.draw_plan(x, cy, w)
        h = cy + pad - y
        self.card_bg(X, y, W, h, "cardbg")
        return y + h

    def title_body(self, x, y, w, tk_, bk):
        kit, T = self.kit, self.T
        _, h1, _ = self.text(x, y, self.t(tk_), kit.font("h2"), T["text"], width=w)
        _, h2, _ = self.text(x, y + h1 + kit.px(10), self.t(bk), kit.font("body"), T["sub"], width=w)
        return y + h1 + kit.px(10) + h2

    def badge(self, x, y, text, kind, anchor="nw", icon="shield"):
        kit, T = self.kit, self.T
        fill, ink = (T["good_bg"], T["good_ink"]) if kind == "good" else (T["bad_bg"], T["bad_ink"])
        tmp = self.cv.create_text(0, 0, text=text, font=kit.font("smallb"))
        x0, _, x1, _ = self.cv.bbox(tmp)
        self.cv.delete(tmp)
        bw, bh = (x1 - x0) + kit.px(52), kit.px(38)
        if anchor == "ne":
            x -= bw
        kit.rrect(self.cv, x, y, bw, bh, bh // 2, fill)
        kit.icon(self.cv, icon, x + kit.px(14), y + (bh - kit.px(18)) // 2, kit.px(18), ink)
        self.cv.create_text(x + kit.px(40), y + bh // 2, text=text, font=kit.font("smallb"), fill=ink, anchor="w")
        return bw, bh

    def draw_plan(self, x, y, w):
        kit, T, cv = self.kit, self.T, self.cv
        N = self.numbers()
        r = N["r"]
        regress = r.get("simulation_regressions", 0)
        _, th, tw = self.text(x, y, self.t("plan.title"), kit.font("h2"), T["text"])
        btxt = self.t("plan.unsafe", n=self.num(regress)) if regress else self.t("plan.safe")
        bw, bh = self.badge(x + w, y - kit.px(4), btxt, "bad" if regress else "good", anchor="ne",
                            icon="warn" if regress else "shield")
        y += max(th, bh) + kit.px(16)
        # hero
        hero_h = kit.px(104)
        kit.rrect(cv, x, y, w, hero_h, kit.px(18), T["accent_soft"])
        _, hh, hw = self.text(x + kit.px(22), y + hero_h // 2, self.gb(N["freed"]), kit.font("hero"), T["accent_strong"],
                              anchor="w")
        lx = x + kit.px(22) + hw + kit.px(20)
        self.text(lx, y + hero_h // 2 - kit.px(2), self.t("plan.freed"), kit.font("bold"), T["text"], anchor="sw")
        self.text(lx, y + hero_h // 2 + kit.px(2), self.t("plan.freedNote"), kit.font("small"), T["sub"], anchor="nw",
                  width=x + w - lx - kit.px(16))
        y += hero_h + kit.px(20)
        # now -> after
        morph_pct = round(100 * (N["morph_b"] - N["morph_a"]) / N["morph_b"]) if N["morph_b"] else 0
        for label, b, a, note in ((self.t("cmp.morphs"), N["morph_b"], N["morph_a"], self.t("cmp.morphsNote", p=morph_pct)),
                                  (self.t("cmp.broken"), N["broken_b"], N["broken_a"], self.t("cmp.brokenNote", n=self.num(N["fixed"]))),
                                  (self.t("cmp.vars"), N["vars_b"], N["vars_a"], self.t("cmp.varsNote", n=self.num(N["removes"])))):
            y = self.cmp_row(x, y, w, label, b, a, note) + kit.px(16)
        # legend
        cv.create_line(x, y, x + w, y, fill=T["line2"], width=kit.ow)
        y += kit.px(12)
        lx = x
        for label, color in ((self.t("cmp.now"), T["before"]), (self.t("cmp.after"), T["accent"])):
            kit.rrect(cv, lx, y + kit.px(6), kit.px(18), kit.px(8), kit.px(4), color)
            _, _, tw = self.text(lx + kit.px(24), y, label, kit.font("small"), T["sub"])
            lx += kit.px(24) + tw + kit.px(18)
        _, lh, _ = self.text(lx, y, self.t("plan.extra", a=self.num(r.get("refs_rewired")), b=self.num(r.get("injects"))),
                             kit.font("small"), T["sub"], width=x + w - lx)
        y += lh + kit.px(14)
        skipped = r.get("skipped") or []
        if skipped:
            _, sh, _ = self.text(x, y, self.t("plan.skipped", n=self.num(len(skipped))), kit.font("small"), T["sub"],
                                 width=w)
            y += sh + kit.px(14)
        # breakdown (collapsible)
        y = self.row_of_pills(x - kit.px(14), y, w, [(self.t("plan.breakdown"), self.toggle_breakdown,
                                                      dict(kind="ghost", icon="chev_d" if self.open_breakdown else "chev_r",
                                                           small=True))], T["card"]) + kit.px(8)
        if self.open_breakdown:
            total = sum(v for _, v in N["kinds"]) or 1
            bx, bh = x, kit.px(14)
            segs = [(k, v, T["series"][i]) for i, (k, v) in enumerate(N["kinds"]) if v > 0]
            for i, (kk, v, col) in enumerate(segs):
                sw = max(kit.px(3), int(w * v / total) - kit.px(2))
                cv.create_rectangle(bx, y, bx + sw, y + bh, fill=col, width=0)
                bx += sw + kit.px(2)
            y += bh + kit.px(12)
            colw = (w - kit.px(24)) // 2
            for i, (kk, v) in enumerate(N["kinds"]):
                cx = x + (i % 2) * (colw + kit.px(24))
                ry = y + (i // 2) * kit.px(28)
                kit.rrect(cv, cx, ry + kit.px(5), kit.px(12), kit.px(12), kit.px(3), T["series"][i])
                self.text(cx + kit.px(20), ry, self.t("kind." + kk), kit.font("body"), T["text"])
                self.text(cx + colw, ry, self.gb(v), kit.font("bold"), T["text"], anchor="ne")
            y += ((len(N["kinds"]) + 1) // 2) * kit.px(28) + kit.px(6)
        # warnings
        plan = self.data["plan"]
        warn = None
        if not plan["plan_exists"]:
            warn = self.t("plan.stale")
        elif self.data["vam_running"]:
            warn = self.t("plan.vamRunning")
        if warn:
            y = self.flat_notice(x, y, w, "warn", warn) + kit.px(16)
        can_apply = not regress and not self.data["vam_running"] and plan["plan_exists"]
        by = self.row_of_pills(x, y, w, [(self.t("btn.apply"), self.ask_apply, dict(kind="primary", icon="play", disabled=not can_apply)),
                                         (self.t("btn.reanalyze"), self.run_plan, dict(icon="scan"))], T["card"])
        self.text(x + w, by - kit.px(14), self.t("plan.when", d=self.when(plan["ts"])), kit.font("small"), T["sub"], anchor="se")
        return by

    def flat_notice(self, x, y, w, kind, msg, icon="warn", tail=None):
        """A coloured strip drawn in place (inside a card). tail = (text, cmd): a small link right after the text
        (on its own line when the text already fills the strip)."""
        kit, T, cv = self.kit, self.T, self.cv
        fill, ink = {"good": (T["good_bg"], T["good_ink"]), "warn": (T["warn_bg"], T["warn_ink"]),
                     "info": (T["accent_soft"], T["text"]), "bad": (T["bad_bg"], T["bad_ink"])}[kind]
        isz, gap = kit.px(14), kit.px(14)
        tw = tkfont.Font(root=cv, font=kit.font("small")).measure(tail[0]) + isz + kit.px(6) if tail else 0
        mw = w - kit.px(64)
        bold = tkfont.Font(root=cv, font=kit.font("bold"))
        msg = kit.wrap(msg, kit.font("bold"), mw)
        inline = bool(tail) and "\n" not in msg and bold.measure(msg) + gap + tw <= mw
        tmp = cv.create_text(0, 0, text=msg, font=kit.font("bold"), width=mw, anchor="nw")
        x0, y0, x1, y1 = cv.bbox(tmp)
        cv.delete(tmp)
        line_h = bold.metrics("linespace")
        h = (y1 - y0) + kit.px(28) + (line_h + kit.px(6) if tail and not inline else 0)
        kit.rrect(cv, x, y, w, h, kit.px(16), fill)
        kit.icon(cv, icon, x + kit.px(14), y + (h - kit.px(20)) // 2, kit.px(20), ink)
        self.text(x + kit.px(46), y + kit.px(14), msg, kit.font("bold"), ink, width=mw)
        if tail:
            tag = f"tail{id(tail)}"
            if inline:
                lx, cy = x + kit.px(46) + (x1 - x0) + gap, y + kit.px(14) + line_h // 2
            else:
                lx, cy = x + kit.px(46), y + kit.px(14) + (y1 - y0) + kit.px(6) + line_h // 2
            # hit box under the link (strip-coloured: an empty fill would not catch the mouse between strokes)
            cv.create_rectangle(lx - kit.px(4), cy - line_h // 2, lx + tw + kit.px(4), cy + line_h // 2, fill=fill,
                                outline="", tags=(tag,))
            kit.icon(cv, "coffee", lx, cy - isz // 2, isz, T["sub"], tags=(tag,))
            t = cv.create_text(lx + isz + kit.px(6), cy, text=tail[0], font=kit.font("small"), fill=T["sub"],
                               anchor="w", tags=(tag,))
            cv.tag_bind(tag, "<Enter>", lambda e: (cv.configure(cursor="hand2"), cv.itemconfigure(t, fill=T["accent"])))
            cv.tag_bind(tag, "<Leave>", lambda e: (cv.configure(cursor=""), cv.itemconfigure(t, fill=T["sub"])))
            cv.tag_bind(tag, "<Button-1>", lambda e: tail[1]())
        return y + h

    def cmp_row(self, x, y, w, label, before, after, note):
        kit, T = self.kit, self.T
        lw = kit.px(150)
        self.text(x, y + kit.px(14), label, kit.font("bold"), T["text"], width=lw - kit.px(10))
        track = (w - lw) * 0.58
        mx = max(before, after, 1)
        bh = kit.px(12)
        for i, (val, color, txt, fnt, ink) in enumerate(
                ((before, T["before"], f"{self.t('cmp.now')} {self.num(before)}", kit.font("body"), T["sub"]),
                 (after, T["accent"], f"{self.t('cmp.after')} {self.num(after)} · {note}", kit.font("bold"), T["text"]))):
            ry = y + i * kit.px(30)
            bw = max(bh, int(track * val / mx))
            kit.rrect(self.cv, x + lw, ry + kit.px(5), bw, bh, bh // 2, color)
            self.text(x + lw + bw + kit.px(12), ry, txt, fnt, ink, width=w - lw - bw - kit.px(12))
        return y + kit.px(56)

    def draw_running(self, x, y, w):
        kit, T, cv = self.kit, self.T, self.cv
        j = self.job
        size = kit.px(140)
        th = kit.px(14)
        ring_track = cv.create_oval(x + th // 2, y + th // 2, x + size - th // 2, y + size - th // 2,
                                    outline=T["track"], width=th)
        arc = cv.create_arc(x + th // 2, y + th // 2, x + size - th // 2, y + size - th // 2, start=90, extent=0,
                            style="arc", outline=T["accent"], width=th)
        pct = cv.create_text(x + size // 2, y + size // 2 - kit.px(8), text="", font=kit.font("big"), fill=T["text"])
        cnt = cv.create_text(x + size // 2, y + size // 2 + kit.px(22), text="", font=kit.font("small"), fill=T["sub"])
        bx = x + size + kit.px(28)
        bw = w - size - kit.px(28)
        _, h1, _ = self.text(bx, y + kit.px(6), self.t("run." + j.kind), kit.font("h2"), T["text"], width=bw)
        phase = cv.create_text(bx, y + kit.px(6) + h1 + kit.px(10), text="", font=kit.font("bold"), fill=T["text"],
                               anchor="nw", width=bw)
        note = cv.create_text(bx, y + kit.px(6) + h1 + kit.px(40), text="", font=kit.font("body"), fill=T["sub"],
                              anchor="nw", width=bw)
        by = y + kit.px(6) + h1 + kit.px(90)
        pause = Pill(cv, kit, self.t("btn.pause"), self.pause_resume, icon="pause", bg=T["card"], lang=self.lang)
        stop = Pill(cv, kit, self.t("btn.stopRevert" if j.kind == "apply" else "btn.stop"), self.stop_job,
                    kind="danger", icon="revert" if j.kind == "apply" else "stop", bg=T["card"], lang=self.lang)
        pw = cv.create_window(bx, by, window=pause, anchor="nw")
        sw = cv.create_window(bx + pause.w + kit.px(10), by, window=stop, anchor="nw")
        self.widgets += [pause, stop]
        self.run_refs = dict(arc=arc, pct=pct, cnt=cnt, phase=phase, note=note, pause=pause, stop=stop, sw=sw, pw=pw,
                             paused=None, stopping=None, stoppable=None, bw=bw)
        self.update_running()
        return max(y + size, by + pause.h)

    def update_running(self):
        j, R = self.job, self.run_refs
        if not j or not R:
            return
        c = j.ctl
        cv, T = self.cv, self.T
        if c.total > 0:
            p = min(100, int(100 * c.n / c.total))
            cv.itemconfigure(R["arc"], start=90, extent=-3.6 * p if p < 100 else -359.9)
            cv.itemconfigure(R["pct"], text=f"{p}%")
            cv.itemconfigure(R["cnt"], text=f"{self.num(c.n)} / {self.num(c.total)}")
        else:
            self.spin = (self.spin - 12) % 360
            cv.itemconfigure(R["arc"], start=self.spin, extent=-90)
            cv.itemconfigure(R["pct"], text="")
            cv.itemconfigure(R["cnt"], text="")
        phase = self.t("phase." + c.phase) if c.phase else ""
        if c.paused:
            phase += " — " + self.t("run.paused")
        if c.stop_requested:
            phase = self.t("run.stopping")
        cv.itemconfigure(R["phase"], text=self.kit.wrap(phase, self.kit.font("bold"), R["bw"]))
        note = ("note.commit" if c.phase in ("commit", "revert") else "note.stage") if j.kind == "apply" else \
            "note.rollback" if j.kind == "rollback" else "note.delete" if j.kind == "delete" else "note.read"
        cv.itemconfigure(R["note"], text=self.kit.wrap(self.t(note), self.kit.font("body"), R["bw"]))
        state = (c.paused, c.stop_requested, c.stoppable)
        if state != (R["paused"], R["stopping"], R["stoppable"]):
            R["paused"], R["stopping"], R["stoppable"] = state
            pb = R["pause"]
            pb.text = self.t("btn.resume" if c.paused else "btn.pause")
            pb.ic = "play" if c.paused else "pause"
            pb.disabled = c.stop_requested
            pb.draw()
            cv.itemconfigure(R["sw"], state="normal" if c.stoppable and not c.stop_requested else "hidden")

    def draw_applied(self, x, y, w):
        kit, T = self.kit, self.T
        b = self.applied_backup()
        _, bh = self.badge(x, y, self.when(b["name"]), "good", icon="check")
        y = self.title_body(x, y + bh + kit.px(14), w, "applied.title", "applied.body") + kit.px(14)
        if self.last_verify:
            v = self.last_verify
            # a quiet coffee link at the end of the good-news line; opens the default browser only
            y = self.flat_notice(x, y, w, "info", self.t("verify.result", a=self.num(v.get("asset_ok")), b=self.num(v.get("asset_broken")),
                                                          c=self.num(v.get("morph_ok")), d=self.num(v.get("morph_broken"))),
                                 icon="shield", tail=(self.t("coffee"), lambda: os.startfile(COFFEE_URL))) + kit.px(14)
        return self.row_of_pills(x, y, w, [(self.t("btn.verify"), self.run_verify, dict(kind="primary", icon="shield")),
                                           (self.t("btn.reanalyze"), self.run_plan, dict(icon="scan"))], T["card"])

    # ---------------------------------------------------------------- lower cards
    def draw_lower(self, X, y, W):
        kit = self.kit
        gap = kit.px(18)
        side = W >= kit.px(880)
        cw = (W - gap) // 2 if side else W
        pad = kit.px(26)
        h1 = self.draw_missing(X + pad, y + pad, cw - 2 * pad) + pad - y
        x2, y2 = (X + cw + gap, y) if side else (X, y + h1 + gap)
        h2 = self.draw_backups(x2 + pad, y2 + pad, cw - 2 * pad) + pad - y2
        if side:
            h1 = h2 = max(h1, h2)
        self.card_bg(X, y, cw, h1, "bg_missing")
        self.card_bg(x2, y2, cw, h2, "bg_backups")
        return (y + h1) if side else (y2 + h2)

    def draw_missing(self, x, y, w):
        kit, T, cv = self.kit, self.T, self.cv
        plan = self.data["plan"]
        if not plan:
            return self.title_text(x, y, w, self.t("missing.title", n="–"), self.t("missing.noplan"))
        N = self.numbers()
        if not N["remaining"]:
            return self.title_text(x, y, w, self.t("missing.title", n=0), self.t("missing.none"))
        y = self.title_text(x, y, w, self.t("missing.title", n=self.num(N["remaining"])), self.t("missing.body")) + kit.px(12)
        cr = self.data.get("creators") or []
        tot = sum(c["refs"] for c in cr) or 1
        top10 = round(100 * sum(c["refs"] for c in cr[:10]) / tot)
        _, sh, _ = self.text(x, y, self.t("cr.summary", c=self.num(len(cr)), l=self.num(sum(1 for c in cr if c["links"])), p=top10),
                             kit.font("smallb"), T["accent_strong"], width=w)
        y += sh + kit.px(12)
        for c in cr[:5]:
            y = self.creator_row(x, y, w, c) + kit.px(8)
        return self.row_of_pills(x, y + kit.px(6), w, [
            (self.t("cr.all", n=self.num(len(cr))), self.creators_dialog, dict(kind="primary", icon="chev_r", small=True)),
            (self.t("cr.copy"), self.copy_creators, dict(icon="copy", small=True))], T["card"])

    def creator_row(self, x, y, w, c):
        """One creator: name, what it unlocks, Open (own page) or Search."""
        kit, T, cv = self.kit, self.T, self.cv
        tag = f"cr{y}"
        p = Pill(cv, kit, self.t("cr.open") if c["links"] else self.t("cr.search"),
                 lambda c=c: self.open_creator(c), icon="globe" if c["links"] else "scan", small=True,
                 kind="default", bg=T["chip"], lang=self.lang)
        tw = w - kit.px(28) - p.w - kit.px(12)
        _, h1, _ = self.text(x + kit.px(14), y + kit.px(10), c["creator"], kit.font("bold"), T["text"], width=tw, tags=(tag,))
        _, h2, _ = self.text(x + kit.px(14), y + kit.px(12) + h1,
                             self.cr_row(c),
                             kit.font("small"), T["sub"], width=tw, tags=(tag,))
        h = max(h1 + h2 + kit.px(22), p.h + kit.px(16))
        cv.create_window(x + w - kit.px(10), y + (h - p.h) // 2, window=p, anchor="ne")
        self.widgets.append(p)
        kit.rrect(cv, x, y, w, h, kit.px(14), T["chip"], tags=(tag + "bg",))
        cv.tag_lower(tag + "bg", tag)
        return y + h

    def title_text(self, x, y, w, title, body):
        kit, T = self.kit, self.T
        _, h1, _ = self.text(x, y, title, kit.font("h3"), T["text"], width=w)
        _, h2, _ = self.text(x, y + h1 + kit.px(10), body, kit.font("body"), T["sub"], width=w)
        return y + h1 + kit.px(10) + h2

    def draw_backups(self, x, y, w):
        kit, T, cv = self.kit, self.T, self.cv
        y = self.title_text(x, y, w, self.t("backup.title"), self.t("backup.body")) + kit.px(14)
        bl, ai = self.data["backups"], self.data["archive_info"]
        if not bl:
            msg = self.t("backup.none")
            if self.data["plan"] and not self.applied_backup():
                msg += " · " + self.t("backup.expected", s=self.gb(self.numbers()["expected_backup"]))
            _, h, _ = self.text(x, y, msg, kit.font("small"), T["sub"], width=w)
            y += h + kit.px(12)
        newest_applied = next((b for b in bl if b["status"] == "applied"), None)
        rows = []
        for b in bl:
            btns = []
            if b is newest_applied:
                btns.append((self.t("btn.revert"), lambda n=b["name"]: self.ask_revert(n), dict(icon="revert", small=True)))
            btns.append((self.t("btn.delete"), lambda n=b["name"]: self.ask_delete([n]), dict(kind="danger", icon="trash", small=True)))
            rows.append((self.when(b["name"]), f"{self.t('st.' + b['status'])} · {self.bytes_gb(b['size'])} · "
                         f"{self.t('backup.files', n=self.num(b['files']))}", btns))
        for i, a in enumerate(ai):
            note = self.t("backup.archiveNote", n=self.num(a["vars"]), s=self.bytes_gb(a["size"])) if a["exists"] \
                else self.t("backup.archiveMissing")
            btns = [(self.t("btn.delete"), lambda p=a["path"]: self.ask_delete_archive(p),
                     dict(kind="danger", icon="trash", small=True))] if a["exists"] else []
            rows.append((self.t("backup.archive"), a["path"] + "\n" + note, btns))
        for title, sub, btns in rows:
            tag = f"row{y}"
            ps = [Pill(cv, kit, t_, c_, bg=T["chip"], lang=self.lang, **kw) for t_, c_, kw in btns]
            bw = sum(p.w for p in ps) + kit.px(8) * max(0, len(ps) - 1)
            tw = w - kit.px(28) - bw - (kit.px(12) if ps else 0)
            _, h1, _ = self.text(x + kit.px(14), y + kit.px(12), title, kit.font("bold"), T["text"], width=tw, tags=(tag,))
            _, h2, _ = self.text(x + kit.px(14), y + kit.px(14) + h1, sub, kit.font("small"), T["sub"], width=tw, tags=(tag,))
            h = max(h1 + h2 + kit.px(28), (ps[0].h + kit.px(20)) if ps else 0)
            bx = x + w - kit.px(12)
            for p in reversed(ps):
                bx -= p.w
                cv.create_window(bx, y + (h - p.h) // 2, window=p, anchor="nw")
                self.widgets.append(p)
                bx -= kit.px(8)
            kit.rrect(cv, x, y, w, h, kit.px(14), T["chip"], tags=(tag + "bg",))
            cv.tag_lower(tag + "bg", tag)
            y += h + kit.px(8)
        specs = []
        if bl:
            specs.append((self.t("btn.deleteAll"), lambda: self.ask_delete([b["name"] for b in bl], all_=True),
                          dict(kind="solid", icon="trash", small=True)))
        if self.data["state"]:
            specs.append((self.t("btn.open"), self.open_backup_folder, dict(icon="folder", small=True)))
        return self.row_of_pills(x, y + kit.px(4), w, specs, T["card"]) if specs else y

    def draw_log(self, X, y, W):
        kit, T = self.kit, self.T
        pad = kit.px(14)
        p = Pill(self.cv, kit, self.t("log.title"), self.toggle_log, kind="ghost",
                 icon="chev_d" if self.open_log else "chev_r", small=True, bg=T["card"], lang=self.lang)
        self.cv.create_window(X + pad, y + pad, window=p, anchor="nw")
        self.widgets.append(p)
        h = p.h + 2 * pad
        if self.open_log:
            fr = tk.Frame(self.cv, bg=T["card"])
            txt = tk.Text(fr, height=12, wrap="char", font=kit.font("mono"), bg=T["card"], fg=T["sub"], bd=0,
                          highlightthickness=0, insertbackground=T["text"])
            sb = SlimScroll(fr, kit, txt.yview, bg=T["card"])
            txt.configure(yscrollcommand=sb.set)
            txt.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            txt.insert("end", "\n".join(self.log))
            txt.see("end")
            txt.configure(state="disabled")
            self.log_text = txt
            lh = kit.px(240)
            self.cv.create_window(X + pad, y + h - pad // 2, window=fr, anchor="nw", width=W - 2 * pad, height=lh)
            self.widgets.append(fr)
            h += lh + pad // 2
        else:
            self.log_text = None
        self.card_bg(X, y, W, h, "bg_log")
        return y + h

    def draw_footer(self, X, y, W):
        kit, T, cv = self.kit, self.T, self.cv
        s = kit.px(48)
        cv.create_image(X, y, image=kit.mark(s), anchor="nw")
        lines = [("CKNMN", ("Segoe UI", 12, "bold"), T["text"]), ("뱀챈 치킨맨", ("Malgun Gothic", 9), T["sub"]),
                 ("cknmn@proton.me", ("Segoe UI", 9), T["mute"])]
        fonts = [tkfont.Font(root=cv, font=f) for _, f, _ in lines]
        hs = [f.metrics("linespace") for f in fonts]
        ty = y + (s - sum(hs)) // 2  # the three lines sit centred on the mark
        for (text, f, fill), h in zip(lines, hs):
            cv.create_text(X + s + kit.px(12), ty, text=text, font=f, fill=fill, anchor="nw")
            ty += h
        tw = max(f.measure(text) for f, (text, _, _) in zip(fonts, lines))
        # opens the user's default browser; the app itself never goes online
        p = Pill(cv, kit, self.t("coffee"), lambda: os.startfile(COFFEE_URL), icon="coffee", small=True,
                 bg=T["bg"])
        cv.create_window(X + s + kit.px(12) + tw + kit.px(28), y + s // 2, window=p, anchor="w")
        self.widgets.append(p)
        plan = self.data["plan"]
        if plan:
            thr = plan["threshold"]
            meta = self.t("meta.plan", p=plan["ts"], t=round(thr * 100, 1) if thr else self.s["threshold_pct"])
            cv.create_text(X + W, y + s, text=meta, font=kit.font("small"), fill=T["mute"], anchor="se")
        return y + s

    # ---------------------------------------------------------------- toggles / small actions
    def toggle_breakdown(self):
        self.open_breakdown = not self.open_breakdown
        self.render()

    def toggle_log(self):
        self.open_log = not self.open_log
        self.render()

    def toggle_theme(self):
        self.set_theme("dark" if self.s["theme"] == "light" else "light")
        self.render()

    def lang_menu(self):
        m = tk.Menu(self.root, tearoff=0, font=self.kit.font("body"))
        for code in LANGS:
            m.add_command(label=I18N[code]["native"], font=self.kit.font("body", code),
                          command=lambda c=code: self.set_lang(c))
        b = self.lang_btn
        m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height() + self.kit.px(4))

    def set_lang(self, code):
        self.lang = self.kit.lang = self.s["lang"] = code
        self.save()
        self.render()

    def cr_row(self, c):
        n, r = len(c["packages"]), c["refs"]
        return self.t("cr.row", p=self.num(n), r=self.num(r), ps="" if n == 1 else "s", rs="" if r == 1 else "s")

    @staticmethod
    def creator_url(c):
        if c["links"]:
            return c["links"][0]
        from urllib.parse import quote_plus
        return "https://www.google.com/search?q=" + quote_plus(f'"{c["creator"]}" VaM patreon')

    def open_creator(self, c):
        os.startfile(self.creator_url(c))  # the user's default browser; nothing is fetched by this app

    def copy_creators(self):
        cr = self.data.get("creators") or []
        lines = []
        for c in cr:
            lines.append(f"{c['creator']}\t{c['refs']}\t{self.creator_url(c)}")
            lines += [f"\t{g}\t{n}" for g, n in c["packages"]]
        self.root.clipboard_clear()
        self.root.clipboard_append("\n".join(lines))
        self.toast(self.t("msg.copied", n=self.num(len(cr))))

    def creators_dialog(self):
        if self.dialog is not None:
            return
        T, kit = self.T, self.kit
        cr = self.data.get("creators") or []
        d = self._dialog(self.t("cr.title"))
        d.resizable(True, True)
        self._label(d, self.t("cr.title"), "h2").pack(anchor="w")
        self._label(d, self.t("cr.hint"), "small", T["sub"], wrap=kit.px(640)).pack(anchor="w", pady=(kit.px(6), kit.px(12)))
        outer = tk.Frame(d, bg=T["card"])
        outer.pack(fill="both", expand=True)
        lc = tk.Canvas(outer, bg=T["card"], highlightthickness=0, width=kit.px(680), height=kit.px(520),
                       yscrollincrement=kit.px(30))
        sb = SlimScroll(outer, kit, lc.yview, bg=T["card"])
        lc.configure(yscrollcommand=sb.set)
        lc.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        inner = tk.Frame(lc, bg=T["card"])
        lc.create_window(0, 0, window=inner, anchor="nw")
        for i, c in enumerate(cr, 1):
            row = tk.Frame(inner, bg=T["chip"], padx=kit.px(12), pady=kit.px(8))
            row.pack(fill="x", pady=(0, kit.px(6)))
            left = tk.Frame(row, bg=T["chip"])
            left.pack(side="left", fill="x", expand=True)
            self._label(left, f"{i}. {c['creator']}", "bold", bg=T["chip"]).pack(anchor="w")
            names = [g.split(".", 1)[1] if "." in g else g for g, _ in c["packages"]]
            shown = ", ".join(names[:4]) + (" " + self.t("cr.more", n=len(names) - 4) if len(names) > 4 else "")
            self._label(left, self.cr_row(c) + "  ·  " + shown,
                        "small", T["sub"], bg=T["chip"], wrap=kit.px(470)).pack(anchor="w")
            Pill(row, kit, self.t("cr.open") if c["links"] else self.t("cr.search"), lambda c=c: self.open_creator(c),
                 icon="globe" if c["links"] else "scan", small=True, bg=T["chip"], lang=self.lang).pack(side="right")
        inner.update_idletasks()
        lc.configure(scrollregion=(0, 0, inner.winfo_reqwidth(), inner.winfo_reqheight()))
        lc.bind("<Configure>", lambda e: lc.itemconfigure(1, width=e.width))
        lc.bind_all("<MouseWheel>", lambda e: lc.yview_scroll(int(-e.delta / 120), "units") if self.dialog is d else self._wheel(e))
        row = tk.Frame(d, bg=T["card"])
        row.pack(anchor="e", pady=(kit.px(14), 0))

        def close():
            d.destroy()
            self.dialog = None
            self.root.bind_all("<MouseWheel>", self._wheel)

        Pill(row, kit, self.t("cr.copy"), self.copy_creators, icon="copy", small=True, bg=T["card"], lang=self.lang).pack(side="left")
        Pill(row, kit, self.t("btn.close"), close, kind="primary", small=True, bg=T["card"], lang=self.lang).pack(side="left", padx=(kit.px(10), 0))
        d.protocol("WM_DELETE_WINDOW", close)
        d.bind("<Escape>", lambda e: close())
        self._show_modal(d)

    def open_backup_folder(self):
        st = self.data["state"]
        for p in (os.path.join(st, "backup"), st):
            if os.path.isdir(p):
                os.startfile(p)
                return

    # ---------------------------------------------------------------- jobs
    def start(self, kind, fn, meta=None):
        if self.running():
            self.toast(self.t("err.busy"))
            return
        self.notice = None
        self.log.clear()
        self.job_seq = 0
        self.job = appstate.Job(kind, fn, meta)
        self.render()

    def folders(self):
        return self.data["vam"], self.data["state"], self.data["archives"]

    def run_plan(self):
        vam, state, arch = self.folders()
        thr, heur = float(self.s.get("threshold_pct") or 5) / 100, bool(self.s.get("heuristic"))
        self.start("plan", lambda ctl: ops.run_plan(vam, state, arch, threshold=thr, heuristic=heur, ctl=ctl) and None)

    def run_verify(self):
        vam, state, arch = self.folders()
        self.start("verify", lambda ctl: ops.run_verify(vam, state, arch, ctl=ctl))

    def ask_apply(self):
        if vam_running():
            self.toast(self.t("err.vamrunning"))
            return
        N = self.numbers()
        r = N["r"]
        body = self.t("c.apply.b", r=self.num(N["removes"]), m=self.num(r.get("modified_packages")),
                      g=self.gb(r.get("modified_packages_gb")), l=self.num(r.get("local_files_modified")))
        if self.confirm(self.t("c.apply.t"), body, self.t("btn.apply")):
            plan_path, state = self.data["plan"]["plan_path"], self.data["state"]
            self.start("apply", lambda ctl: ops.run_apply(plan_path, state, ctl=ctl))

    def ask_revert(self, name):
        if vam_running():
            self.toast(self.t("err.vamrunning"))
            return
        if self.confirm(self.t("c.revert.t"), self.t("c.revert.b", d=self.when(name)), self.t("btn.revert")):
            path = os.path.join(self.data["state"], "backup", name)
            self.start("rollback", lambda ctl: ops.run_rollback(path, ctl=ctl))

    def ask_delete(self, names, all_=False):
        chosen = [b for b in self.data["backups"] if b["name"] in names]
        size = sum(b["size"] for b in chosen)
        warns = [self.t("c.del.applied")] if any(b["status"] == "applied" for b in chosen) else []
        arch = [a["path"] for a in self.data["archive_info"] if a["exists"]] if all_ else []
        res = self.confirm(self.t("c.del.t"), self.t("c.del.b", s=self.bytes_gb(size)), self.t("btn.deleteForever"),
                           warns=warns, danger=True, check=self.t("c.del.withArchives") if arch else None)
        if not res:
            return
        state = self.data["state"]
        targets = [os.path.join(state, "backup", n) for n in names]
        staging = os.path.join(state, "staging")
        if all_ and os.path.isdir(staging):
            targets.append(staging)
        drop = arch if (res == "checked") else []
        self._delete(targets + drop, drop)

    def ask_delete_archive(self, path):
        a = next(x for x in self.data["archive_info"] if x["path"] == path)
        warns = [self.t("c.del.early")] if self.data["plan"] and not self.applied_backup() else []
        if self.confirm(self.t("c.del.t"), self.t("c.del.b", s=f"{path} ({self.bytes_gb(a['size'])})"),
                        self.t("btn.deleteForever"), warns=warns, danger=True):
            self._delete([path], [path])

    def _delete(self, targets, archives):
        def fn(ctl):
            freed = ops.delete_paths(targets, ctl=ctl)
            return {"freed": freed}
        if archives:
            self.s["archives"] = [a for a in self.s["archives"] if a not in archives]
            self.save()
        self.start("delete", fn)

    def pause_resume(self):
        if self.running():
            c = self.job.ctl
            c.resume() if c.paused else c.pause()
            self.update_running()

    def stop_job(self):
        if self.running() and self.job.ctl.stoppable:
            self.job.ctl.stop()
            self.update_running()

    def tick(self):
        try:
            while True:
                self.q.get_nowait()()
        except queue.Empty:
            pass
        j = self.job
        if j is not None:
            lines, seq = j.ctl.tail(self.job_seq)
            if lines:
                self.job_seq = seq
                self.log.extend(lines)
                if self.log_text is not None and self.log_text.winfo_exists():
                    self.log_text.configure(state="normal")
                    self.log_text.insert("end", ("\n" if self.log_text.index("end-1c") != "1.0" else "") + "\n".join(lines))
                    self.log_text.see("end")
                    self.log_text.configure(state="disabled")
            if j.done and not getattr(j, "_handled", False):
                j._handled = True
                self.job_finished(j)
            elif not j.done:
                self.update_running()
        self.root.after(150 if self.running() else 400, self.tick)

    def job_finished(self, j):
        if self.closing:
            self.root.destroy()
            return
        if j.kind == "verify" and j.ok:
            self.last_verify = j.result
        if j.cancelled:
            safe = j.kind == "apply" and j.cancel_phase in ("preflight", "stage")
            reverted = j.kind == "apply" and not safe
            self.notice = ("warn", self.t("msg.cancelSafe" if safe else "msg.cancelReverted" if reverted else "msg.cancelled"))
        elif not j.ok:
            self.notice = ("bad", self.t("msg.error", e=j.error or ""))
        elif j.kind == "delete":
            self.toast(self.t("msg.freed", s=self.bytes_gb((j.result or {}).get("freed"))))
        elif j.kind == "rollback":
            self.toast(self.t("msg.reverted"))
        self.refresh()
        self.render()

    def on_close(self):
        if self.running():
            # "취소/닫기" read as "cancel the job / close this popup": name what each button does to the app
            if not self.confirm(self.t("close.t"), self.t("close.b"), self.t("close.stop"), danger=True,
                                cancel=self.t("close.keep")):
                return
            self.closing = True
            if self.job.ctl.stoppable:
                self.job.ctl.stop()
            self.notice = ("warn", self.t("close.wait"))
            self.render()
            return  # job_finished() closes the window once the worker has stopped (and reverted)
        self.root.destroy()

    # ---------------------------------------------------------------- dialogs
    def _dialog(self, title):
        T, kit = self.T, self.kit
        d = tk.Toplevel(self.root, bg=T["card"])
        d.title(title)
        d.transient(self.root)
        d.resizable(False, False)
        d.configure(padx=kit.px(26), pady=kit.px(22))
        self.dialog = d
        return d

    def _show_modal(self, d):
        d.update_idletasks()
        r = self.root
        x = r.winfo_rootx() + (r.winfo_width() - d.winfo_reqwidth()) // 2
        y = r.winfo_rooty() + max(self.kit.px(40), (r.winfo_height() - d.winfo_reqheight()) // 3)
        d.geometry(f"+{x}+{y}")
        style_titlebar(d, self.T, self.s["theme"] == "dark")
        d.grab_set()
        d.focus_set()

    def _label(self, parent, text, role="body", color=None, wrap=None, bg=None, **kw):
        T = self.T
        return tk.Label(parent, text=self.kit.wrap(text, self.kit.font(role), wrap), font=self.kit.font(role),
                        fg=color or T["text"], bg=bg or T["card"], justify="left", anchor="w", wraplength=wrap or 0, **kw)

    def confirm(self, title, body, ok, warns=(), danger=False, check=None, cancel=None):
        """Modal yes/no. Returns False, True, or 'checked' when the optional checkbox was ticked."""
        T, kit = self.T, self.kit
        d = self._dialog(title)
        wrap = kit.px(540)
        self._label(d, title, "h2").pack(anchor="w")
        self._label(d, body, wrap=wrap).pack(anchor="w", pady=(kit.px(12), 0))
        for w_ in warns:
            self._label(d, w_, "bold", T["warn_ink"], wrap=wrap, bg=T["warn_bg"], padx=kit.px(14),
                        pady=kit.px(10)).pack(anchor="w", fill="x", pady=(kit.px(12), 0))
        var = tk.BooleanVar(value=False)
        if check:
            tk.Checkbutton(d, text=check, variable=var, font=kit.font("body"), bg=T["card"], fg=T["text"],
                           activebackground=T["card"], activeforeground=T["text"], selectcolor=T["input"],
                           anchor="w").pack(anchor="w", pady=(kit.px(12), 0))
        res = {"v": False}
        row = tk.Frame(d, bg=T["card"])
        row.pack(anchor="e", pady=(kit.px(18), 0))

        def done(v):
            res["v"] = ("checked" if var.get() else True) if v else False
            d.destroy()

        Pill(row, kit, cancel or self.t("btn.cancel"), lambda: done(False), bg=T["card"], lang=self.lang).pack(side="left")
        yes = Pill(row, kit, ok, lambda: done(True), kind="solid" if danger else "primary", bg=T["card"], lang=self.lang)
        yes.pack(side="left", padx=(kit.px(10), 0))
        d.bind("<Escape>", lambda e: done(False))
        d.protocol("WM_DELETE_WINDOW", lambda: done(False))
        self._show_modal(d)
        self.root.wait_window(d)
        self.dialog = None
        return res["v"]

    def folder_dialog(self, welcome=False):
        if self.dialog is not None:
            return
        T, kit = self.T, self.kit
        d = self._dialog(self.t("w.title") if welcome else self.t("f.title"))
        st = dict(step="lang" if welcome else "folders", vam=self.s.get("vam") or "", cands=[], detecting=False,
                  arch=[dict(path=p, checked=True, suggested=True, vars=None, size=None) for p in self.s.get("archives", [])],
                  thr=tk.StringVar(value=f"{self.s.get('threshold_pct', 5):g}"), heur=tk.BooleanVar(value=bool(self.s.get("heuristic"))),
                  valid=detect.is_vam_dir(self.s.get("vam") or ""))
        body = tk.Frame(d, bg=T["card"])
        body.pack(fill="both", expand=True)
        wrap = kit.px(600)

        def merge(found):
            have = {a["path"].lower(): a for a in st["arch"]}
            for a in found:
                cur = have.get(a["path"].lower())
                if cur:
                    cur.update(vars=a["vars"], size=a["size"], suggested=a["suggested"])
                else:
                    st["arch"].append(dict(path=a["path"], checked=bool(a["suggested"]), suggested=a["suggested"],
                                           vars=a["vars"], size=a["size"]))

        def set_vam(v):
            st["vam"] = v.strip()
            st["valid"] = detect.is_vam_dir(st["vam"])
            if st["valid"]:
                merge(detect.find_archives(st["vam"], detect.default_state(st["vam"])))
            draw()

        def detect_now():
            st["detecting"] = True
            draw()

            def work():
                r = detect.detect_all(scan=True)

                def done():
                    st["detecting"] = False
                    st["cands"] = r["vam_candidates"]
                    if not st["vam"] and r["vam"]:
                        st["vam"] = r["vam"]
                    st["valid"] = detect.is_vam_dir(st["vam"])
                    if st["valid"]:
                        merge(detect.find_archives(st["vam"], detect.default_state(st["vam"])))
                    if d.winfo_exists():
                        draw()
                self.post(done)
            threading.Thread(target=work, daemon=True).start()

        def browse(add=False):
            p = filedialog.askdirectory(parent=d, initialdir=st["vam"] or None)
            if not p:
                return
            p = os.path.normpath(p)
            if add:
                if not any(a["path"].lower() == p.lower() for a in st["arch"]):
                    st["arch"].append(dict(path=p, checked=True, suggested=True, vars=None, size=None))
                draw()
            else:
                set_vam(p)

        def save():
            self.s["vam"] = os.path.normpath(st["vam"])
            self.s["archives"] = [a["path"] for a in st["arch"] if a["checked"]]
            if welcome:
                self.s["setup_done"] = True
            else:
                try:
                    self.s["threshold_pct"] = max(0.5, min(50.0, float(st["thr"].get())))
                except ValueError:
                    pass
                self.s["heuristic"] = bool(st["heur"].get())
            self.save()
            d.destroy()
            self.dialog = None
            self.refresh()
            self.render()
            self.toast(self.t("msg.saved"))

        def section(title, hint=None):
            self._label(body, title, "bold").pack(anchor="w", pady=(kit.px(14), 0))
            if hint:
                self._label(body, hint, "small", T["sub"], wrap=wrap).pack(anchor="w")

        def check_row(parent, text, sub, var, radio_value=None, cmd=None):
            fr = tk.Frame(parent, bg=T["chip"], padx=kit.px(12), pady=kit.px(8))
            fr.pack(fill="x", pady=(kit.px(6), 0))
            common = dict(bg=T["chip"], fg=T["text"], activebackground=T["chip"], activeforeground=T["text"],
                          selectcolor=T["input"], font=kit.font("body"),
                          text=kit.wrap(text, kit.font("body"), wrap - kit.px(40)), anchor="w", justify="left",
                          wraplength=wrap - kit.px(40), command=cmd)
            w_ = tk.Radiobutton(fr, variable=var, value=radio_value, **common) if radio_value is not None else \
                tk.Checkbutton(fr, variable=var, **common)
            w_.pack(anchor="w")
            if sub:
                self._label(fr, sub, "small", T["sub"], bg=T["chip"], wrap=wrap - kit.px(40)).pack(anchor="w", padx=(kit.px(26), 0))

        def draw():
            for w_ in body.winfo_children():
                w_.destroy()
            if st["step"] == "lang":
                self._label(body, self.t("w.title"), "h2").pack(anchor="w")
                self._label(body, self.t("w.lang"), "body", T["sub"]).pack(anchor="w", pady=(kit.px(6), kit.px(14)))
                grid = tk.Frame(body, bg=T["card"])
                grid.pack(anchor="w")
                for i, code in enumerate(LANGS):
                    def pick(c=code):
                        self.lang = self.kit.lang = self.s["lang"] = c
                        self.save()
                        d.title(self.t("w.title"))
                        self.render()
                        draw()
                    p = Pill(grid, kit, I18N[code]["native"], pick, kind="selected" if code == self.lang else "default",
                             bg=T["card"], lang=code)
                    p.grid(row=i // 3, column=i % 3, padx=(0, kit.px(10)), pady=(0, kit.px(10)), sticky="w")
                row = tk.Frame(body, bg=T["card"])
                row.pack(anchor="e", pady=(kit.px(8), 0))

                def nxt():
                    st["step"] = "folders"
                    draw()
                    if not st["cands"]:
                        detect_now()
                Pill(row, kit, self.t("w.next"), nxt, kind="primary", bg=T["card"], lang=self.lang).pack()
                return
            d.title(self.t("w.title") if welcome else self.t("f.title"))
            self._label(body, self.t("w.title") if welcome else self.t("f.title"), "h2").pack(anchor="w")
            if welcome:
                self._label(body, self.t("w.detecting") if st["detecting"] else self.t("w.folders"), "body", T["sub"],
                            wrap=wrap).pack(anchor="w", pady=(kit.px(6), 0))
            section(self.t("f.vam"), self.t("f.vamHint"))
            row = tk.Frame(body, bg=T["card"])
            row.pack(fill="x", pady=(kit.px(6), 0))
            ent = tk.Entry(row, font=kit.font("body"), bg=T["input"], fg=T["text"], insertbackground=T["text"],
                           relief="flat", highlightthickness=kit.ow, highlightbackground=T["line"],
                           highlightcolor=T["accent"])
            ent.insert(0, st["vam"])
            ent.pack(side="left", fill="x", expand=True, ipady=kit.px(8))
            ent.bind("<Return>", lambda e: set_vam(ent.get()))
            ent.bind("<FocusOut>", lambda e: set_vam(ent.get()) if ent.get().strip() != st["vam"] else None)
            Pill(row, kit, self.t("f.browse"), browse, icon="folder", small=True, bg=T["card"], lang=self.lang).pack(side="left", padx=(kit.px(8), 0))
            Pill(row, kit, self.t("w.detecting") if st["detecting"] else self.t("f.detect"), detect_now, icon="scan",
                 small=True, disabled=st["detecting"], bg=T["card"], lang=self.lang).pack(side="left", padx=(kit.px(8), 0))
            if st["cands"]:
                rv = tk.StringVar(value=next((c[0] for c in st["cands"] if c[0].lower() == st["vam"].lower()), ""))
                for path, reason in st["cands"]:
                    check_row(body, path, self.t("f.found", r=self.t("r." + reason)), rv, radio_value=path,
                              cmd=lambda p=path: set_vam(p))
            if st["vam"] and not st["valid"] and not st["detecting"]:
                self._label(body, self.t("f.invalid"), "bold", T["warn_ink"], bg=T["warn_bg"], padx=kit.px(12),
                            pady=kit.px(8), wrap=wrap).pack(anchor="w", fill="x", pady=(kit.px(8), 0))
            section(self.t("f.state"), self.t("f.stateHint"))
            st_ent = tk.Entry(body, font=kit.font("body"), relief="flat", readonlybackground=T["chip"], fg=T["sub"],
                              highlightthickness=0)
            st_ent.insert(0, detect.default_state(st["vam"]) if st["vam"] else "")
            st_ent.configure(state="readonly")
            st_ent.pack(fill="x", pady=(kit.px(6), 0), ipady=kit.px(8))
            section(self.t("f.archives"), self.t("f.archivesHint"))
            for a in st["arch"]:
                var = tk.BooleanVar(value=a["checked"])
                sub = None
                if a["vars"] is not None:
                    sub = f"var {self.num(a['vars'])} · {self.bytes_gb(a['size'])}" + ("" if a["suggested"] else " · " + self.t("f.notBackup"))
                check_row(body, a["path"], sub, var, cmd=lambda a=a, v=var: a.update(checked=v.get()))
            if not st["arch"]:
                self._label(body, self.t("f.none"), "small", T["sub"]).pack(anchor="w", pady=(kit.px(6), 0))
            Pill(body, kit, self.t("f.add"), lambda: browse(add=True), icon="folder", small=True, bg=T["card"],
                 lang=self.lang).pack(anchor="w", pady=(kit.px(8), 0))
            if not welcome:
                section(self.t("f.threshold"))
                tk.Spinbox(body, from_=0.5, to=50, increment=0.5, textvariable=st["thr"], width=6, font=kit.font("body"),
                           bg=T["input"], fg=T["text"], buttonbackground=T["chip"], relief="flat",
                           highlightthickness=kit.ow, highlightbackground=T["line"]).pack(anchor="w", pady=(kit.px(6), 0), ipady=kit.px(4))
                check_row(body, self.t("f.heuristic"), None, st["heur"])
            row = tk.Frame(body, bg=T["card"])
            row.pack(anchor="e", pady=(kit.px(18), 0))
            if not welcome:
                Pill(row, kit, self.t("btn.cancel"), close, bg=T["card"], lang=self.lang).pack(side="left", padx=(0, kit.px(10)))
            Pill(row, kit, self.t("w.start") if welcome else self.t("f.save"), save, kind="primary",
                 disabled=not st["valid"] or st["detecting"], bg=T["card"], lang=self.lang).pack(side="left")

        def close():
            if welcome:
                return  # the first-run dialog must finish
            d.destroy()
            self.dialog = None

        d.protocol("WM_DELETE_WINDOW", close)
        d.bind("<Escape>", lambda e: close())
        draw()
        self._show_modal(d)
        if st["step"] == "folders" and not st["vam"]:
            detect_now()


# ------------------------------------------------------------------------------------------------ entry
def _single_instance():
    """Named mutex: a second launch brings the open window forward instead of running two cleaners at once."""
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateMutexW.restype = ctypes.c_void_p
    h = k32.CreateMutexW(None, False, "Local\\" + APP_ID)
    if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
        u32 = ctypes.windll.user32
        for code in LANGS:
            hwnd = u32.FindWindowW(None, I18N[code]["app.title"])
            if hwnd:
                u32.ShowWindow(hwnd, 9)  # SW_RESTORE
                u32.SetForegroundWindow(hwnd)
                break
        return None
    return h


def main():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)  # own taskbar group + icon, not python's
    except (AttributeError, OSError):
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except (AttributeError, OSError):
        pass
    if _single_instance() is None:
        return
    root = tk.Tk()
    ico = os.path.join(ASSETS, "cknmn.ico")
    try:
        if not os.path.exists(ico):
            os.makedirs(ASSETS, exist_ok=True)
            with open(ico, "wb") as fh:
                fh.write(gfx.ico(gfx.icon_set()))
        root.iconbitmap(default=ico)
    except (tk.TclError, OSError):
        pass
    root._icons = [tk.PhotoImage(master=root, data=b64(gfx.mark_png(s))) for s in (64, 32)]
    root.iconphoto(True, *root._icons)
    App(root)
    root.mainloop()
