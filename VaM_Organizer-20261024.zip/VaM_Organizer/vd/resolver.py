"""VaM package reference resolution (mirrors MVR.FileManagement.FileManager, Assembly-CSharp.dll).

- exact `C.P.N`   -> that version; if missing, VarPackageGroup.GetClosestMatchingPackageVersion
                     (modelled as: lowest version >= N, else newest)
- `C.P.latest`    -> newest
- `C.P.minN`      -> newest if newest >= N
- `SELF`          -> the package containing the referencing file
Resolution is per package; a missing *file* inside the resolved package is not retried elsewhere.
"""
from collections import defaultdict

from .model import PREFIX_RE


class Registry:
    def __init__(self, uid_to_pid, pid_to_grpver):
        self.groups = defaultdict(dict)
        for uid, pid in uid_to_pid.items():
            g, v = pid_to_grpver[pid]
            self.groups[g][v] = pid
        self.vers = {g: sorted(vs) for g, vs in self.groups.items()}
        self.pids = set(uid_to_pid.values())

    def resolve(self, prefix, src_pid):
        if prefix == "SELF":
            return src_pid if src_pid in self.pids else None
        m = PREFIX_RE.match(prefix)
        if not m:
            return None
        g, v, mn = m.group(1), m.group(2), m.group(3)
        vs = self.vers.get(g)
        if not vs:
            return None
        if v == "latest":
            return self.groups[g][vs[-1]]
        if mn is not None:
            return self.groups[g][vs[-1]] if vs[-1] >= int(mn) else None
        v = int(v)
        if v in self.groups[g]:
            return self.groups[g][v]
        hi = [x for x in vs if x >= v]
        return self.groups[g][hi[0] if hi else vs[-1]]

    def newest(self, g):
        vs = self.vers.get(g)
        return self.groups[g][vs[-1]] if vs else None
