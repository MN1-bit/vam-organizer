"""Tiny anti-aliased rasterizer (stdlib only): the CKNMN chicken-head mark, app icons, rounded-corner pieces.

Tk's canvas draws shapes without anti-aliasing on Windows, so smooth curves are rendered here into
RGBA PNGs (supersampled) and shown as images.
"""
import math
import struct
import zlib


# ----------------------------------------------------------------------------------------- PNG / ICO
def png(w, h, rows):
    """rows: list of bytes, each w*4 RGBA."""
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def ico(pngs):
    """pngs: [(size, png_bytes)] -> .ico bytes (PNG-compressed entries, Vista+)."""
    head = struct.pack("<HHH", 0, 1, len(pngs))
    off = 6 + 16 * len(pngs)
    entries, blobs = b"", b""
    for size, data in pngs:
        s = 0 if size >= 256 else size
        entries += struct.pack("<BBBBHHII", s, s, 0, 0, 1, 32, len(data), off + len(blobs))
        blobs += data
    return head + entries + blobs


def hex_rgb(c):
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def raster(w, h, shade, ss=4):
    """shade(x, y) -> (r, g, b, a) in 0..1 floats for a point in pixel space; supersampled ss x ss."""
    rows = []
    n = ss * ss
    offs = [(i + 0.5) / ss for i in range(ss)]
    for py in range(h):
        row = bytearray()
        for px in range(w):
            ar = ag = ab = aa = 0.0
            for oy in offs:
                for ox in offs:
                    r, g, b, a = shade(px + ox, py + oy)
                    ar += r * a
                    ag += g * a
                    ab += b * a
                    aa += a
            if aa <= 0:
                row += b"\x00\x00\x00\x00"
            else:
                row += bytes((round(255 * ar / aa), round(255 * ag / aa), round(255 * ab / aa), round(255 * aa / n)))
        rows.append(bytes(row))
    return png(w, h, rows)


# ----------------------------------------------------------------------------------------- the mark
def _in_rrect(x, y, x0, y0, x1, y1, r):
    if x < x0 or x > x1 or y < y0 or y > y1:
        return False
    cx = min(max(x, x0 + r), x1 - r)
    cy = min(max(y, y0 + r), y1 - r)
    return (x - cx) ** 2 + (y - cy) ** 2 <= r * r


def _in_tri(x, y, a, b, c):
    def s(p, q, r):
        return (p[0] - r[0]) * (q[1] - r[1]) - (q[0] - r[0]) * (p[1] - r[1])
    d1, d2, d3 = s((x, y), a, b), s((x, y), b, c), s((x, y), c, a)
    neg = d1 < 0 or d2 < 0 or d3 < 0
    pos = d1 > 0 or d2 > 0 or d3 > 0
    return not (neg and pos)


def _in_poly(x, y, pts):
    inside = False
    j = len(pts) - 1
    for i in range(len(pts)):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def chicken(u, v):
    """Monotone symbolic chicken head facing right, in a 100x100 unit box. True where the glyph is."""
    if (u - 53.5) ** 2 + (v - 50) ** 2 <= 4.2 ** 2:  # eye: negative space
        return False
    if (u - 46) ** 2 + (v - 56) ** 2 <= 21.5 ** 2:  # head
        return True
    for cx, cy, r in ((33.5, 33, 8.2), (45.5, 26, 10.0), (57.5, 31.5, 8.2)):  # comb: three distinct crests
        if (u - cx) ** 2 + (v - cy) ** 2 <= r * r:
            return True
    if _in_tri(u, v, (62, 45), (86, 54), (62, 63)):  # beak
        return True
    if ((u - 60.5) / 5.6) ** 2 + ((v - 75) / 8.8) ** 2 <= 1:  # wattle: a drop hanging under the beak
        return True
    return _in_poly(u, v, ((30, 63), (58, 63), (64, 101), (24, 101)))  # neck


def mark_png(size, tile="#111111", glyph="#ffffff", radius=22, ss=None):
    """The CKNMN tile: rounded square + white chicken head (the app / taskbar icon)."""
    t, g = [c / 255 for c in hex_rgb(tile)], [c / 255 for c in hex_rgb(glyph)]
    s = 100.0 / size
    ss = ss or (4 if size <= 64 else 3 if size <= 128 else 2)

    def shade(x, y):
        u, v = x * s, y * s
        if not _in_rrect(u, v, 0, 0, 100, 100, radius):
            return 0, 0, 0, 0
        return (*g, 1.0) if chicken(u, v) else (*t, 1.0)

    return raster(size, size, shade, ss)


def icon_set(sizes=(16, 20, 24, 32, 40, 48, 64, 128, 256)):
    return [(s, mark_png(s)) for s in sizes]


# ----------------------------------------------------------------------------------------- UI pieces
def corner_pngs(r, fill, outline=None, ow=1):
    """Anti-aliased quarter circles for a rounded rectangle: {'tl','tr','bl','br': png}."""
    f = [c / 255 for c in hex_rgb(fill)]
    o = [c / 255 for c in hex_rgb(outline)] if outline else f
    inner = r - ow if outline else r

    def shade(x, y):  # top-left quadrant, circle centre at (r, r)
        d = math.hypot(x - r, y - r) if (x < r and y < r) else 0.0
        if d > r:
            return 0, 0, 0, 0
        return (*f, 1.0) if d <= inner else (*o, 1.0)

    tl = raster(r, r, shade, 4)
    # mirror the decoded rows for the other three corners
    rows = _png_rows(tl, r)
    flip_h = [b"".join(row[i * 4:i * 4 + 4] for i in range(r - 1, -1, -1)) for row in rows]
    return {"tl": tl, "tr": png(r, r, flip_h), "bl": png(r, r, rows[::-1]), "br": png(r, r, flip_h[::-1])}


def _png_rows(data, w):
    """Decode rows of a PNG written by png() (filter 0 only)."""
    pos, idat = 8, b""
    while pos < len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        tag = data[pos + 4:pos + 8]
        if tag == b"IDAT":
            idat += data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
    raw = zlib.decompress(idat)
    stride = 1 + w * 4
    return [raw[i * stride + 1:(i + 1) * stride] for i in range(len(raw) // stride)]


def ring_png(size, thickness, pct, track, arc):
    """Anti-aliased progress ring (pct 0..100), arc starting at 12 o'clock, clockwise."""
    tr, ac = [c / 255 for c in hex_rgb(track)], [c / 255 for c in hex_rgb(arc)]
    c = size / 2
    r1, r0 = c, c - thickness
    end = 2 * math.pi * max(0.0, min(100.0, pct)) / 100

    def shade(x, y):
        d = math.hypot(x - c, y - c)
        if d > r1 or d < r0:
            return 0, 0, 0, 0
        ang = math.atan2(x - c, c - y) % (2 * math.pi)
        return (*ac, 1.0) if ang <= end else (*tr, 1.0)

    return raster(size, size, shade, 2)
