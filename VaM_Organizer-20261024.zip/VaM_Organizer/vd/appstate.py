"""Settings, one-at-a-time background jobs and the data snapshot the window shows."""
import glob
import json
import os
import sqlite3
import threading
import time
import traceback

from . import detect, ops
from .applier import vam_running
from .jobctl import Cancelled, Control

TOOL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS = os.path.join(TOOL_DIR, "settings.json")
LANGS = ("ko", "en", "zh", "ja", "es")


def os_language():
    """Windows display language -> one of LANGS (Korean when it is none of them)."""
    try:
        import ctypes
        lid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
    except (AttributeError, OSError):
        return "ko"
    return {0x12: "ko", 0x09: "en", 0x04: "zh", 0x11: "ja", 0x0A: "es"}.get(lid & 0x3FF, "ko")


def load_settings():
    try:
        with open(SETTINGS, encoding="utf-8") as fh:
            s = json.load(fh)
    except (OSError, ValueError):
        s = {}
    if "archives" not in s:  # older settings kept one ';'-joined string
        s["archives"] = [a.strip() for a in (s.get("archive") or "").split(";") if a.strip()]
    s.pop("archive", None)
    s.pop("state", None)  # the work folder is always <VaM>\dedup
    s.setdefault("threshold_pct", 5)
    s.setdefault("heuristic", False)
    if s.get("lang") not in LANGS:  # first run: pre-select the Windows display language in the welcome dialog
        s["lang"] = os_language()
    if s.get("theme") not in ("light", "dark"):
        s["theme"] = "light"  # day mode by default
    s.setdefault("setup_done", bool(s.get("vam")))
    vam = s.get("vam")
    if vam and s["archives"] and not any(os.path.isdir(a) for a in s["archives"]):
        # every saved archive folder is gone (deleted/moved): re-detect instead of silently losing repairs
        s["archives"] = [a["path"] for a in detect.find_archives(vam, detect.default_state(vam)) if a["suggested"]]
    return s


def save_settings(s):
    tmp = SETTINGS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(s, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, SETTINGS)


class Job:
    """Runs fn(ctl) on a worker thread; the window polls status()."""

    def __init__(self, kind, fn, meta=None):
        self.kind, self.meta = kind, meta or {}
        self.ctl = Control()
        self.done, self.ok, self.error, self.result = False, None, None, None
        self.cancelled, self.cancel_phase = False, None
        threading.Thread(target=self._run, args=(fn,), daemon=True).start()

    def _run(self, fn):
        try:
            self.result = fn(self.ctl)
            self.ok = True
        except Cancelled:
            self.cancelled, self.ok = True, False
            self.cancel_phase = self.ctl.phase
            self.ctl.log("멈춤")
        except Exception as e:
            self.ok, self.error = False, f"{type(e).__name__}: {e}"
            self.ctl.log(traceback.format_exc())
        finally:
            self.done = True


def plan_summary(state):
    rep = ops.latest_report(state) if state else None
    if not rep:
        return None
    d = rep["details"]
    r = dict(d.get("report") or {})
    if not r.get("live_var_files"):
        r["live_var_files"] = len(glob.glob(os.path.join(os.path.dirname(state), "AddonPackages", "**", "*.var"),
                                            recursive=True))
    groups = [g for g in d.get("missing_groups", []) if not g[0].startswith("SELF")]  # package-internal: not downloadable
    name = os.path.basename(rep["report_path"])
    return dict(name=name, ts=name[len("report-"):-len(".json")], report=r, threshold=d.get("threshold"),
                missing=groups, plan_path=rep["plan_path"], plan_exists=os.path.exists(rep["plan_path"]))


_creator_cache = {}


def creators_for(state, plan):
    """Missing packages grouped by creator (cached per plan: it reads every package's meta.json)."""
    if not plan:
        return []
    key = (state, plan["ts"])
    if key not in _creator_cache:
        try:
            found = ops.creator_sources(state, plan["missing"])
        except sqlite3.OperationalError:  # index.db busy (an analysis is writing it): retry on the next refresh
            return []
        _creator_cache.clear()
        _creator_cache[key] = found
    return _creator_cache[key]


def snapshot(settings):
    vam = settings.get("vam") or ""
    state = detect.default_state(vam) if vam else ""
    archives = list(settings.get("archives") or [])
    arch_info = []
    for a in archives:
        if os.path.isdir(a):
            n, size = detect._count_vars(a)
            arch_info.append(dict(path=a, exists=True, vars=n, size=size))
        else:
            arch_info.append(dict(path=a, exists=False, vars=0, size=0))
    plan = plan_summary(state)
    return dict(vam=vam, state=state, archives=archives, vam_ok=detect.is_vam_dir(vam),
                plan=plan, creators=creators_for(state, plan), backups=ops.list_backups(state) if state else [],
                archive_info=arch_info, vam_running=vam_running(), at=time.time())
