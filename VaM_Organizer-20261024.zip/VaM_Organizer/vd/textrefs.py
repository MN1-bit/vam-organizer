"""Scan and rewrite JSON-ish text at the string-literal level.

VaM's SimpleJSON output is not always strict JSON, so files are never parsed and re-dumped:
only the exact string literals that change are re-encoded; every other byte is preserved.
"""
import json
import re

STR_RE = re.compile(r'"((?:[^"\\\r\n]|\\.)*)"')
CS_STR_RE = re.compile(r'(?<!@)"((?:[^"\\\r\n]|\\.)*)"')
MORPH_RE = re.compile(r'"uid"\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"name"\s*:\s*"((?:[^"\\]|\\.)*)"')
BOM = b"\xef\xbb\xbf"


def decode_bytes(b):
    bom = b.startswith(BOM)
    return (b[3:] if bom else b).decode("utf-8", "surrogateescape"), bom


def encode_bytes(text, bom):
    return (BOM if bom else b"") + text.encode("utf-8", "surrogateescape")


def decode_str(raw):
    if "\\" not in raw:
        return raw
    try:
        return json.loads('"' + raw + '"')
    except ValueError:
        return None


def encode_str(value):
    return json.dumps(value, ensure_ascii=False)[1:-1]


def iter_strings(text, pattern=STR_RE):
    for m in pattern.finditer(text):
        v = decode_str(m.group(1))
        if v is not None:
            yield v


def iter_morph_refs(text):
    for m in MORPH_RE.finditer(text):
        uid, name = decode_str(m.group(1)), decode_str(m.group(2))
        if uid is not None:
            yield uid, name


def rewrite_text(text, mapping):
    """Replace string literals whose decoded value is a key of mapping. Returns (text, n)."""
    out, last, n = [], 0, 0
    for m in STR_RE.finditer(text):
        v = decode_str(m.group(1))
        if v is None:
            continue
        nv = mapping.get(v)
        if nv is None or nv == v:
            continue
        out.append(text[last:m.start(1)])
        out.append(encode_str(nv))
        last = m.end(1)
        n += 1
    if not n:
        return text, 0
    out.append(text[last:])
    return "".join(out), n


def rewrite_bytes(data, mapping):
    text, bom = decode_bytes(data)
    new, n = rewrite_text(text, mapping)
    return (encode_bytes(new, bom) if n else data), n
