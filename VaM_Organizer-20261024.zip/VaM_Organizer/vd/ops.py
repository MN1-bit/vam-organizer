"""Operations shared by the CLI and the GUI. `ctl` (jobctl.Control) adds pause/stop, phases and a log."""
import glob
import json
import os
import shutil
import time
from collections import Counter

from . import indexer
from .applier import Applier, ApplyError, rollback, xp
from .model import split_ref
from .planner import Planner


def _io(log, progress, ctl):
    if ctl is not None:
        return ctl.log, ctl.progress
    return log, progress


def resolve_folders(vam=None, state=None, archives=None, log=print):
    """Fill unspecified folders by auto-detection (see detect.py)."""
    from . import detect
    if not vam:
        found = detect.find_vam_dirs()
        if not found:
            raise SystemExit("VaM 폴더를 찾지 못했습니다. --vam 으로 지정하세요.")
        vam = found[0][0]
        log(f"VaM 폴더 자동 감지: {vam} ({detect.REASON_KO.get(found[0][1], found[0][1])})" +
            (f", 다른 후보: {[f[0] for f in found[1:]]}" if len(found) > 1 else ""))
    state = state or detect.default_state(vam)
    if archives is None:
        archives = [a["path"] for a in detect.find_archives(vam, state) if a["suggested"]]
        log(f"복구용 원본 폴더 자동 감지: {archives or '없음'}")
    return vam, state, archives


def archive_dirs(state, extra, log=print):
    dirs = []
    for d in extra:
        if not d:
            continue
        if os.path.isdir(d):
            dirs.append(d)
        else:  # a missing archive silently drops thousands of repairs - say so
            log(f"경고: 복구용 원본 백업 폴더가 없습니다: {d} (새 원본은 인덱싱되지 않음. 이미 인덱싱된 원본은 파일이 남아 있는 한 유지)")
    own = os.path.join(state, "backup")
    if os.path.isdir(own):
        dirs.append(own)
    return dirs


def run_index(vam, state, archives, log=print, progress=None, ctl=None):
    log, progress = _io(log, progress, ctl)
    if ctl is not None:
        ctl.set_phase("index")
    os.makedirs(state, exist_ok=True)
    indexer.build(os.path.join(state, "index.db"), vam, archive_dirs(state, archives, log=log), log=log,
                  progress=progress)


def _skip_path(state):
    return os.path.join(state, "skip.json")


def load_skips(state):
    """Files the tool leaves untouched because an earlier apply could not stage them."""
    try:
        with open(_skip_path(state), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return []


def add_skips(state, items):
    have = {(s["source"], s["relpath"]): s for s in load_skips(state)}
    for s in items:
        have[(s["source"], s["relpath"])] = dict(s, at=time.strftime("%Y-%m-%d %H:%M:%S"))
    tmp = _skip_path(state) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(sorted(have.values(), key=lambda s: (s["source"], s["relpath"])), fh, ensure_ascii=False, indent=1)
    os.replace(tmp, _skip_path(state))


def run_plan(vam, state, archives, threshold=0.05, heuristic=False, reindex=True, log=print, progress=None,
             ctl=None):
    if reindex:
        run_index(vam, state, archives, log=log, progress=progress, ctl=ctl)
    log, progress = _io(log, progress, ctl)
    pl = Planner(os.path.join(state, "index.db"), vam, threshold=threshold, heuristic_repair=heuristic, log=log,
                 ctl=ctl, skip=load_skips(state)).run()
    plan = pl.to_plan()
    rep = pl.report(plan)
    ts = time.strftime("%Y%m%d-%H%M%S")
    out = os.path.join(state, "plans")
    os.makedirs(out, exist_ok=True)
    plan_path = os.path.join(out, f"plan-{ts}.json")
    report_path = os.path.join(out, f"report-{ts}.json")
    with open(plan_path, "w", encoding="utf-8") as fh:
        json.dump(plan, fh, ensure_ascii=False, indent=1)
    missing = Counter()
    for _uid, _src, v in pl.unrepaired:
        pre = split_ref(v)[0]
        missing[pre.rsplit(".", 1)[0] if pre != "SELF" else "SELF"] += 1
    details = dict(report=rep, plan=plan_path, threshold=threshold,
                   archives_used=sorted(pl.P[a]["relpath"] for a in pl.archive_used),
                   missing_groups=missing.most_common(),
                   lost=[list(map(str, x[2:])) for x in pl.lost][:2000],
                   unrepaired=[list(x) for x in pl.unrepaired][:5000],
                   regressions=[list(map(str, x[:4])) for x in pl.sim_bad][:2000],
                   samples={k: [list(x) for x in v] for k, v in pl.samples.items()},
                   residual={pl.P[p]["uid"]: sorted(pl.E[p][lp][0] for lp in v if lp in pl.E[p])
                             for p, v in pl.residual.items()})
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(details, fh, ensure_ascii=False, indent=1, default=str)
    log(f"계획 저장: {os.path.basename(plan_path)}")
    return dict(plan_path=plan_path, report_path=report_path, details=details)


def latest_report(state):
    reps = sorted(glob.glob(os.path.join(state, "plans", "report-*.json")))
    if not reps:
        return None
    with open(reps[-1], encoding="utf-8") as fh:
        d = json.load(fh)
    # the plan sits next to its report; never trust a stored absolute path (the work folder can move)
    d["plan"] = os.path.join(os.path.dirname(reps[-1]), os.path.basename(reps[-1]).replace("report-", "plan-"))
    if "missing_groups" not in d:
        c = Counter(split_ref(v)[0].rsplit(".", 1)[0] for _u, _s, v in d.get("unrepaired", []) if split_ref(v))
        d["missing_groups"] = c.most_common()
    return dict(plan_path=d["plan"], report_path=reps[-1], details=d)


def creator_sources(state, missing_groups):
    """Group missing packages by creator, with the creator's own page links found in installed packages' meta.json.

    -> [dict(creator, packages=[(group, refs)], refs, links)] sorted by refs (who unlocks the most first).
    """
    import sqlite3
    links = {}
    db_path = os.path.join(state, "index.db")
    if os.path.exists(db_path):
        db = sqlite3.connect(db_path)
        try:
            for creator, meta in db.execute("SELECT creator, meta FROM pkg WHERE source='live' AND meta IS NOT NULL"):
                try:
                    m = json.loads(meta)
                except ValueError:
                    continue
                for key in ("promotionalLink", "patreonLink"):
                    v = str(m.get(key) or "").strip()
                    if v.startswith(("http://", "https://")):
                        links.setdefault((creator or "").lower(), Counter())[v] += 1
        finally:
            db.close()
    by = {}
    for group, n in missing_groups:
        if group.startswith("SELF"):
            continue
        creator = group.split(".", 1)[0]
        e = by.setdefault(creator.lower(), dict(creator=creator, packages=[], refs=0, links=[]))
        e["packages"].append((group, n))
        e["refs"] += n
    for key, e in by.items():
        e["links"] = [u for u, _ in links.get(key, Counter()).most_common(3)]
    return sorted(by.values(), key=lambda e: (-e["refs"], e["creator"].lower()))


def run_apply(plan_path, state, log=print, progress=None, ctl=None, retries=2):
    """Apply; if some files can't be staged (VaM folder still untouched), leave those files alone, plan again
    around them and apply that plan — only when the new plan still breaks nothing."""
    for attempt in range(retries + 1):
        try:
            return Applier(plan_path, state, log=log, progress=progress, ctl=ctl).run(plan_path=plan_path)
        except ApplyError as e:
            if not e.skip or attempt == retries:
                raise
            lg = ctl.log if ctl is not None else log
            add_skips(state, e.skip)
            for s in e.skip[:20]:
                lg(f"  건너뜀: {s['relpath']}  [{s['reason']}]")
            lg(f"파일 {len(e.skip)}개를 건너뛰고 계획 다시 세우는 중 (VaM 폴더는 아직 그대로)")
            with open(plan_path, encoding="utf-8") as fh:
                old = json.load(fh)
            r = run_plan(old["vam_root"], state, [], threshold=old.get("threshold", 0.05),
                         heuristic=bool(old.get("heuristic")), reindex=False, log=log, progress=progress, ctl=ctl)
            rep = r["details"]["report"]
            if rep.get("simulation_regressions") or rep.get("lost_refs"):
                raise ApplyError(f"계획을 다시 세웠지만 깨지는 참조가 생겨 중단 (변경 없음): "
                                 f"{rep.get('simulation_regressions')} / {rep.get('lost_refs')}")
            plan_path = r["plan_path"]


def run_rollback(backup_dir, log=print, ctl=None):
    if ctl is not None:
        ctl.set_phase("rollback", stoppable=False)  # half a rollback is worse than finishing it
        log = ctl.log
    rollback(backup_dir, log=log)


def run_verify(vam, state, archives, log=print, progress=None, ctl=None):
    run_index(vam, state, archives, log=log, progress=progress, ctl=ctl)
    log, progress = _io(log, progress, ctl)
    if ctl is not None:
        ctl.set_phase("verify")
    pl = Planner(os.path.join(state, "index.db"), vam, log=log)
    pl.load()
    pl.build_registry()
    pl.db.close()
    c = Counter()
    for pid, p in pl.P.items():
        if p["source"] not in ("live", "local") or (p["source"] == "live" and pid not in pl.reg_pids):
            continue
        src_pid = pid if pid in pl.reg_pids else None
        for src, v, kind in pl.refs[pid]:
            if kind != "full":
                continue
            pre, path = split_ref(v)
            if pre == "SELF" and src_pid is None:
                continue
            tp = pl.pre.resolve(pre, src_pid)
            ok = tp is not None and path.lower() in pl.E[tp]
            c[("morph" if path.lower().endswith(".vmi") else "asset") + ("_ok" if ok else "_broken")] += 1
    c["packages"] = len(pl.reg_pids)
    c["duplicate_copies"] = len(pl.dup_removals)
    c["old_versions"] = len(pl.old)
    return dict(c)


def dir_size(path):
    total = files = 0
    for dp, dn, fn in os.walk(xp(path)):  # backups nest deeper than AddonPackages: past MAX_PATH is possible
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
                files += 1
            except OSError:
                pass
    return total, files


def list_backups(state):
    """status: applied (can be reverted) | reverted | incomplete"""
    root = os.path.join(state, "backup")
    out = []
    if not os.path.isdir(root):
        return out
    for name in sorted(os.listdir(root), reverse=True):
        p = os.path.join(root, name)
        if not os.path.isdir(p):
            continue
        size, files = dir_size(p)
        if os.path.exists(os.path.join(p, "journal.jsonl")):
            status = "applied"
        elif os.path.exists(os.path.join(p, "journal.jsonl.rolledback")):
            status = "reverted"
        else:
            status = "incomplete"
        out.append(dict(path=p, name=name, size=size, files=files, status=status))
    return out


def delete_paths(paths, log=print, progress=None, ctl=None):
    """Permanently delete folders (backups). Returns bytes freed. A stop leaves the rest in place."""
    log, progress = _io(log, progress, ctl)
    items = []
    for p in paths:
        for dp, dn, fn in os.walk(xp(p)):
            for f in fn:
                items.append(os.path.join(dp, f))
    if ctl is not None:
        ctl.set_phase("delete", len(items))
    freed = 0
    for n, f in enumerate(items, 1):
        try:
            freed += os.path.getsize(f)
            os.chmod(f, 0o666)
            os.remove(f)
        except OSError as e:
            log(f"삭제 실패: {f.removeprefix(chr(92) * 2 + '?' + chr(92))}: {e}")
        if progress and (n % 20 == 0 or n == len(items)):
            progress(n, len(items))
    for p in paths:
        shutil.rmtree(xp(p), ignore_errors=True)
        log(f"삭제: {p}")
    return freed
