"""Morph shape comparison on .vmb deltas: int32 n, then n x (int32 vertex, float dx, dy, dz)."""
import math
import struct
import zipfile
from collections import OrderedDict


def parse_vmb(b):
    n = struct.unpack_from("<i", b, 0)[0]
    if n < 0 or 4 + 16 * n > len(b):
        raise ValueError("bad vmb")
    return {i: (x, y, z) for i, x, y, z in struct.iter_unpack("<ifff", b[4:4 + 16 * n])}


def shape_diff(a, b):
    """||a-b|| / max(||a||, ||b||); 0 = identical, 1 = completely different."""
    num = 0.0
    for k in a.keys() | b.keys():
        x = a.get(k, (0.0, 0.0, 0.0))
        y = b.get(k, (0.0, 0.0, 0.0))
        num += (x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2 + (x[2] - y[2]) ** 2
    na = math.sqrt(sum(v[0] ** 2 + v[1] ** 2 + v[2] ** 2 for v in a.values()))
    nb = math.sqrt(sum(v[0] ** 2 + v[1] ** 2 + v[2] ** 2 for v in b.values()))
    den = max(na, nb)
    if den == 0:
        return 0.0 if num == 0 else 1.0
    return math.sqrt(num) / den


class VmbStore:
    """Loads .vmb deltas from zips with a small open-file LRU and a content (crc,size) cache."""

    def __init__(self, path_of_pkg, max_open=48):
        self.path_of_pkg = path_of_pkg
        self.zips = OrderedDict()
        self.max_open = max_open
        self.cache = {}

    def _zip(self, pid):
        z = self.zips.pop(pid, None)
        if z is None:
            z = zipfile.ZipFile(self.path_of_pkg(pid))
            if len(self.zips) >= self.max_open:
                _, old = self.zips.popitem(last=False)
                old.close()
        self.zips[pid] = z
        return z

    def get(self, pid, name, key):
        d = self.cache.get(key)
        if d is None:
            d = parse_vmb(self._zip(pid).read(name))
            self.cache[key] = d
        return d

    def close(self):
        for z in self.zips.values():
            z.close()
        self.zips.clear()
