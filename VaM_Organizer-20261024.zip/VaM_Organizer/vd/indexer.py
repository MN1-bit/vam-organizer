"""Incremental index of live packages, archive (backup) packages and local Saves/Custom text files."""
import hashlib
import json
import os
import posixpath
import sqlite3
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed

from .model import (ASSET_EXT_RE, CODE_EXT, EMBED_RE, LIST_EXT, MAX_TEXT_BYTES, REF_RE, TEXT_EXT,
                    parse_uid, rel_candidates)
from .textrefs import CS_STR_RE, decode_bytes, iter_morph_refs, iter_strings

SCHEMA = """
CREATE TABLE IF NOT EXISTS pkg(id INTEGER PRIMARY KEY, source TEXT, relpath TEXT, fname TEXT, uid TEXT, grp TEXT,
    ver INT, creator TEXT, size INT, mtime REAL, ok INT, err TEXT, meta TEXT, nentries INT);
CREATE UNIQUE INDEX IF NOT EXISTS ix_pkg_src ON pkg(source, relpath);
CREATE TABLE IF NOT EXISTS entry(pkg INT, path TEXT, crc INT, usize INT, csize INT);
CREATE INDEX IF NOT EXISTS ix_entry_pkg ON entry(pkg);
CREATE TABLE IF NOT EXISTS ref(pkg INT, src TEXT, value TEXT, kind TEXT);
CREATE INDEX IF NOT EXISTS ix_ref_pkg ON ref(pkg);
CREATE TABLE IF NOT EXISTS mref(pkg INT, src TEXT, uid TEXT, name TEXT);
CREATE INDEX IF NOT EXISTS ix_mref_pkg ON mref(pkg);
CREATE TABLE IF NOT EXISTS vmi(pkg INT, path TEXT, mid TEXT, display TEXT, region TEXT, grp TEXT, pose TEXT,
    vmin TEXT, vmax TEXT, fhash TEXT);
CREATE INDEX IF NOT EXISTS ix_vmi_pkg ON vmi(pkg);
"""


def _load_json(raw):
    text, _ = decode_bytes(raw)
    try:
        return json.loads(text)
    except ValueError:
        return None


def scan_text(src, data, entries_lower):
    """-> refs [(src, value, kind)], mrefs [(src, uid, name)]"""
    refs, mrefs = [], []
    low = src.lower()
    text, _ = decode_bytes(data)
    if low.endswith(LIST_EXT):
        for line in text.splitlines():
            line = line.strip()
            if line:
                for c in rel_candidates(low, line):
                    if c in entries_lower:
                        refs.append((src, c, "rel"))
        return refs, mrefs
    if low.endswith(CODE_EXT):
        for v in iter_strings(text, CS_STR_RE):
            if ":/" in v:
                for m in EMBED_RE.finditer(v):
                    refs.append((src, m.group(0), "embed"))
            elif ASSET_EXT_RE.search(v) and len(v) < 400:
                refs.append((src, v, "code"))
        return refs, mrefs
    seen = set()
    for v in iter_strings(text):
        if v in seen:
            continue
        seen.add(v)
        if ":/" in v:
            if REF_RE.match(v):
                refs.append((src, v, "full"))
            else:
                for m in EMBED_RE.finditer(v):
                    refs.append((src, m.group(0), "embed"))
        elif entries_lower and ASSET_EXT_RE.search(v) and len(v) < 400:
            for c in rel_candidates(low, v):
                if c in entries_lower:
                    refs.append((src, c, "rel"))
    for uid, name in iter_morph_refs(text):
        if ":/" in uid:
            mrefs.append((src, uid, name))
    return refs, mrefs


def index_var(path, relpath, source):
    st = os.stat(path)
    fname = os.path.basename(path)
    u = parse_uid(fname)
    rec = dict(source=source, relpath=relpath, fname=fname, uid=u[0] if u else None, grp=u[1] if u else None,
               ver=u[2] if u else None, creator=u[3] if u else None, size=st.st_size, mtime=st.st_mtime,
               ok=1, err=None, meta=None, entries=[], refs=[], mrefs=[], vmis=[])
    try:
        with zipfile.ZipFile(path) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            rec["entries"] = [(i.filename, i.CRC, i.file_size, i.compress_size) for i in infos]
            lower = {i.filename.lower() for i in infos}
            for i in infos:
                low = i.filename.lower()
                if low == "meta.json":
                    rec["meta"] = _load_json(z.read(i))
                    continue
                if i.file_size > MAX_TEXT_BYTES:
                    continue
                if low.endswith(".vmi"):
                    j = _load_json(z.read(i))
                    if isinstance(j, dict):
                        fh = hashlib.sha1(json.dumps(j.get("formulas") or [], sort_keys=True).encode()).hexdigest()[:16]
                        rec["vmis"].append((i.filename, str(j.get("id")), (j.get("displayName") or "").strip(),
                                            str(j.get("region")), str(j.get("group")), str(j.get("isPoseControl")),
                                            str(j.get("min")), str(j.get("max")), fh))
                    continue
                if source == "archive":
                    continue
                if low.endswith(TEXT_EXT + CODE_EXT + LIST_EXT):
                    r, m = scan_text(i.filename, z.read(i), lower)
                    rec["refs"].extend(r)
                    rec["mrefs"].extend(m)
    except Exception as e:  # unreadable / corrupt var: recorded, never modified
        rec["ok"], rec["err"] = 0, f"{type(e).__name__}: {e}"
    return rec


def index_local(path, relpath):
    st = os.stat(path)
    rec = dict(source="local", relpath=relpath, fname=os.path.basename(path), uid=None, grp=None, ver=None,
               creator=None, size=st.st_size, mtime=st.st_mtime, ok=1, err=None, meta=None,
               entries=[], refs=[], mrefs=[], vmis=[])
    try:
        if st.st_size <= MAX_TEXT_BYTES:
            with open(path, "rb") as fh:
                data = fh.read()
            r, m = scan_text(relpath.replace("\\", "/"), data, set())
            rec["refs"] = [x for x in r if x[2] in ("full", "embed")]
            rec["mrefs"] = m
    except Exception as e:
        rec["ok"], rec["err"] = 0, f"{type(e).__name__}: {e}"
    return rec


def _walk(root, exts):
    for dp, dn, fn in os.walk(root):
        for f in fn:
            if f.lower().endswith(exts):
                yield os.path.join(dp, f)


def build(db_path, vam_root, archive_dirs=(), log=print, workers=8, progress=None):
    db = sqlite3.connect(db_path)
    db.executescript(SCHEMA)
    jobs = []  # (source, abspath, relpath)
    addon = os.path.join(vam_root, "AddonPackages")
    for p in _walk(addon, (".var",)):
        jobs.append(("live", p, os.path.relpath(p, addon)))
    for ad in archive_dirs:
        for p in _walk(ad, (".var",)):
            jobs.append(("archive", p, os.path.abspath(p)))  # archives are addressed by absolute path
    for base in ("Saves", "Custom"):
        root = os.path.join(vam_root, base)
        if os.path.isdir(root):
            for p in _walk(root, TEXT_EXT):
                jobs.append(("local", p, os.path.relpath(p, vam_root)))

    have = {(s, r): (i, sz, mt) for i, s, r, sz, mt in db.execute("SELECT id,source,relpath,size,mtime FROM pkg")}
    todo, keep = [], set()
    for src, p, rel in jobs:
        st = os.stat(p)
        old = have.get((src, rel))
        if old and old[1] == st.st_size and abs(old[2] - st.st_mtime) < 1e-3:
            keep.add(old[0])
        else:
            todo.append((src, p, rel))
    scanned = {(s, r) for s, _, r in jobs}
    stale = []
    for (s, r), (i, sz, mt) in have.items():
        if i in keep:
            continue
        # archive rows are evidence for repairs: drop them only when the file itself is gone,
        # never just because this run was not given that archive folder
        if s == "archive" and (s, r) not in scanned and os.path.isfile(r):
            continue
        stale.append(i)
    for i in stale:
        for t in ("entry", "ref", "mref", "vmi"):
            db.execute(f"DELETE FROM {t} WHERE pkg=?", (i,))
        db.execute("DELETE FROM pkg WHERE id=?", (i,))
    db.commit()
    log(f"index: {len(jobs)} files, {len(keep)} unchanged, {len(todo)} to scan, {len(stale)} dropped")

    def work(job):
        src, p, rel = job
        return index_local(p, rel) if src == "local" else index_var(p, rel, src)

    t0 = time.time()
    ex = ThreadPoolExecutor(workers)
    try:
        # count files as they finish, not in list order: one slow package (e.g. a big motion library) must not
        # freeze the counter while the other workers keep going
        futs = [ex.submit(work, job) for job in todo]
        for n, fut in enumerate(as_completed(futs), 1):
            rec = fut.result()
            cur = db.execute(
                "INSERT INTO pkg(source,relpath,fname,uid,grp,ver,creator,size,mtime,ok,err,meta,nentries)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (rec["source"], rec["relpath"], rec["fname"], rec["uid"], rec["grp"], rec["ver"], rec["creator"],
                 rec["size"], rec["mtime"], rec["ok"], rec["err"],
                 json.dumps(rec["meta"], ensure_ascii=False) if rec["meta"] is not None else None,
                 len(rec["entries"])))
            pid = cur.lastrowid
            db.executemany("INSERT INTO entry VALUES(?,?,?,?,?)", [(pid, *e) for e in rec["entries"]])
            db.executemany("INSERT INTO ref VALUES(?,?,?,?)", [(pid, *r) for r in rec["refs"]])
            db.executemany("INSERT INTO mref VALUES(?,?,?,?)", [(pid, *r) for r in rec["mrefs"]])
            db.executemany("INSERT INTO vmi VALUES(?,?,?,?,?,?,?,?,?,?)", [(pid, *v) for v in rec["vmis"]])
            if progress and (n % 10 == 0 or n == len(todo)):
                progress(n, len(todo))  # may block (pause) or raise (stop)
            if n % 500 == 0:
                db.commit()
                log(f"  {n}/{len(todo)}  {time.time() - t0:.0f}s")
    finally:
        ex.shutdown(wait=True, cancel_futures=True)  # a stop must not wait for every queued file
        db.commit()  # each package row is written whole, so a partial index is consistent
        db.close()
    log(f"index done in {time.time() - t0:.0f}s")
