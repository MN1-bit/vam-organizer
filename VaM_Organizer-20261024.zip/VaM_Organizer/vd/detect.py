"""Find the VaM install, a work folder and original-backup (archive) folders on any PC.

VaM is a portable zip (no installer, no install-path registry key), so evidence is gathered from:
running VaM.exe, Windows' own record of executables that were run (MuiCache / Compatibility Assistant),
the tool's own location, and finally a shallow scan of fixed drives.
"""
import ctypes
import os
import string
import time

SKIP_DIRS = {"windows", "$recycle.bin", "system volume information", "programdata", "recovery", "perflogs",
             "$windows.~bt", "$windows.~ws", "msocache", "config.msi", "node_modules", ".git", "appdata"}
VAM_SUBDIRS = {"addonpackages", "custom", "saves", "cache", "vam_data", "mono", "addonpackagesfileprefs",
               "addonpackagesuserprefs", "keys", "logs", "browserprofile", "assets", "dedup"}
ARCHIVE_HINTS = ("archive", "backup", "백업", "var-manager", "varmanager", "_old", "original")


def is_vam_dir(d):
    return bool(d) and os.path.isfile(os.path.join(d, "VaM.exe")) and os.path.isdir(os.path.join(d, "AddonPackages"))


def _running_vam():
    return _process_dirs("vam.exe")


def is_running(exe_name):
    """True if a process with this image name exists. In-process Toolhelp32 walk: no child process, no console flash."""
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD),
                    ("szExeFile", ctypes.c_wchar * 260)]

    exe_name = exe_name.lower()
    try:
        k32 = ctypes.windll.kernel32
        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        snap = k32.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
        if snap in (None, wintypes.HANDLE(-1).value):
            return False
        try:
            pe = PROCESSENTRY32W()
            pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            ok = k32.Process32FirstW(snap, ctypes.byref(pe))
            while ok:
                if pe.szExeFile.lower() == exe_name:
                    return True
                ok = k32.Process32NextW(snap, ctypes.byref(pe))
        finally:
            k32.CloseHandle(snap)
    except (AttributeError, OSError):
        pass
    return False


def _process_dirs(exe_name):
    """Folders of running processes named exe_name (Toolhelp32 + QueryFullProcessImageNameW; wmic is gone on new Windows 11)."""
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD),
                    ("szExeFile", ctypes.c_wchar * 260)]

    out = []
    try:
        k32 = ctypes.windll.kernel32
        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        k32.OpenProcess.restype = wintypes.HANDLE
        snap = k32.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
        if snap in (None, wintypes.HANDLE(-1).value):
            return out
        pe = PROCESSENTRY32W()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        ok = k32.Process32FirstW(snap, ctypes.byref(pe))
        while ok:
            if pe.szExeFile.lower() == exe_name:
                h = k32.OpenProcess(0x1000, False, pe.th32ProcessID)  # PROCESS_QUERY_LIMITED_INFORMATION
                if h:
                    buf = ctypes.create_unicode_buffer(1024)
                    size = wintypes.DWORD(len(buf))
                    if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                        out.append(os.path.dirname(buf.value))
                    k32.CloseHandle(h)
            ok = k32.Process32NextW(snap, ctypes.byref(pe))
        k32.CloseHandle(snap)
    except (AttributeError, OSError):
        pass
    return out


def _registry_vam():
    try:
        import winreg
    except ImportError:
        return []
    found = []
    for path in (r"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache",
                 r"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Compatibility Assistant\Store"):
        try:
            k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path)
        except OSError:
            continue
        i = 0
        while True:
            try:
                name = winreg.EnumValue(k, i)[0]
            except OSError:
                break
            i += 1
            low = name.lower()
            for suffix in ("\\vam.exe", "\\vam.exe.friendlyappname"):
                if low.endswith(suffix):
                    found.append(name[:len(name) - len(suffix)])
    return found


def _tool_location():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out, d = [], here
    for _ in range(4):
        out.append(d)
        try:
            out.extend(e.path for e in os.scandir(d) if e.is_dir())
        except OSError:
            pass
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return out


def fixed_drives():
    drives = []
    try:
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        for i, letter in enumerate(string.ascii_uppercase):
            if mask >> i & 1:
                root = f"{letter}:\\"
                if ctypes.windll.kernel32.GetDriveTypeW(root) == 3:  # DRIVE_FIXED
                    drives.append(root)
    except (AttributeError, OSError):
        pass
    return drives


def _scan_drives(max_depth=3, budget_s=8.0):
    found, t0 = [], time.time()
    for root in fixed_drives():
        stack = [(root, 0)]
        while stack and time.time() - t0 < budget_s:
            d, depth = stack.pop()
            try:
                entries = list(os.scandir(d))
            except OSError:
                continue
            names = {e.name.lower() for e in entries}
            if "vam.exe" in names and "addonpackages" in names:
                found.append(d)
                continue
            if depth < max_depth:
                for e in entries:
                    try:
                        if e.is_dir(follow_symlinks=False) and e.name.lower() not in SKIP_DIRS and not e.name.startswith("."):
                            stack.append((e.path, depth + 1))
                    except OSError:
                        pass
    return found


REASON_KO = {"running": "실행 중인 VaM", "registry": "Windows 실행 기록", "tool": "정리기 위치 주변", "scan": "드라이브 검색"}


def find_vam_dirs(scan=True):
    """Candidate VaM folders, most likely first. Each is (path, reason code: running|registry|tool|scan)."""
    seen, out = set(), []
    sources = [("running", _running_vam), ("registry", _registry_vam), ("tool", _tool_location)]
    if scan:
        sources.append(("scan", _scan_drives))
    for reason, fn in sources:
        for d in fn():
            d = os.path.normpath(d)
            key = d.lower()
            if key not in seen and is_vam_dir(d):
                seen.add(key)
                out.append((d, reason))
    return out


def default_state(vam):
    """Work folder = <VaM>\\dedup: same drive (instant moves), and VaM only loads vars from AddonPackages,
    so backups kept here are never picked up by VaM."""
    return os.path.join(os.path.normpath(vam), "dedup")


def _count_vars(d, max_depth=4, cap=20000):
    n = size = seen = 0
    stack = [(d, 0)]
    while stack and seen < cap:
        p, depth = stack.pop()
        try:
            entries = list(os.scandir(p))
        except OSError:
            continue
        for e in entries:
            seen += 1
            try:
                if e.is_file() and e.name.lower().endswith(".var"):
                    n += 1
                    size += e.stat().st_size
                elif e.is_dir(follow_symlinks=False) and depth < max_depth:
                    stack.append((e.path, depth + 1))
            except OSError:
                pass
    return n, size


def find_archives(vam, state=None):
    """Folders outside AddonPackages that hold .var files. -> [dict(path, vars, size, suggested)]"""
    vam = os.path.normpath(vam)
    exclude = {os.path.normcase(os.path.join(vam, "AddonPackages"))}
    if state:
        exclude.add(os.path.normcase(os.path.normpath(state)))
    out, seen = [], set()
    for base, is_vam in ((vam, True), (os.path.dirname(vam.rstrip("\\/")) or vam, False)):
        try:
            children = [e for e in os.scandir(base) if e.is_dir(follow_symlinks=False)]
        except OSError:
            continue
        for e in children:
            low = e.name.lower()
            key = os.path.normcase(e.path)
            if key in seen or key in exclude or low in SKIP_DIRS or key == os.path.normcase(vam):
                continue
            if is_vam and low in VAM_SUBDIRS:
                continue
            seen.add(key)
            n, size = _count_vars(e.path)
            if n:
                suggested = low == "addonpackages_archive" or any(h in low for h in ARCHIVE_HINTS)
                out.append(dict(path=e.path, vars=n, size=size, suggested=suggested))
    out.sort(key=lambda a: (not a["suggested"], -a["vars"]))
    return out


def detect_all(scan=True):
    vams = find_vam_dirs(scan=scan)
    if not vams:
        return dict(vam_candidates=[], vam=None, state=None, archives=[])
    vam = vams[0][0]
    state = default_state(vam)
    return dict(vam_candidates=vams, vam=vam, state=state, archives=find_archives(vam, state))
