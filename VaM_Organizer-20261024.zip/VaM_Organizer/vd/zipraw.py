"""Rewrite a zip (.var) by copying untouched entries byte-for-byte (no recompression).

Only the entries that are dropped, replaced or added are touched; everything else keeps its
original local header, compressed bytes and central-directory record (offset patched).
"""
import struct
import time
import zlib
import zipfile

SIG_LOCAL = b"PK\x03\x04"
SIG_CEN = 0x02014B50
SIG_EOCD = b"PK\x05\x06"
CHUNK = 4 * 1024 * 1024


class ZipUnsupported(Exception):
    pass


class _Entry:
    __slots__ = ("name", "raw_name", "flag", "method", "mtime", "mdate", "crc", "csize", "usize", "local_off", "cen",
                 "loff_in_extra", "uname")


def _unicode_path(extra, raw_name):
    """UTF-8 name from an Info-ZIP Unicode Path field (0x7075), or None.

    Packers on non-UTF-8 Windows (e.g. cp949) store a legacy-encoded name plus this field; Python's zipfile
    (which the indexer uses) reports the UTF-8 name, so read_central must too or plan names won't match.
    """
    q = 0
    while q + 4 <= len(extra):
        hid, hsz = struct.unpack_from("<HH", extra, q)
        if hid == 0x7075 and hsz >= 5:
            ver, crc = struct.unpack_from("<BI", extra, q + 4)
            if ver == 1 and crc == zlib.crc32(raw_name) & 0xFFFFFFFF:
                try:
                    return extra[q + 9:q + 4 + hsz].decode("utf-8") or None
                except UnicodeDecodeError:
                    return None
        q += 4 + hsz
    return None


def read_central(f):
    f.seek(0, 2)
    size = f.tell()
    tail_len = min(size, 65536 + 22)
    f.seek(size - tail_len)
    tail = f.read()
    i = tail.rfind(SIG_EOCD)
    if i < 0:
        raise ZipUnsupported("no end-of-central-directory")
    _, disk, cd_disk, n_disk, n_total, cd_size, cd_off, clen = struct.unpack_from("<4sHHHHIIH", tail, i)
    if disk or cd_disk or n_disk != n_total:
        raise ZipUnsupported("multi-disk zip")
    if n_total == 0xFFFF or cd_size == 0xFFFFFFFF or cd_off == 0xFFFFFFFF:
        raise ZipUnsupported("zip64")
    comment = tail[i + 22:i + 22 + clen]
    f.seek(cd_off)
    cd = f.read(cd_size)
    entries, p = [], 0
    for _ in range(n_total):
        (sig, _vm, _vn, flag, method, mt, md, crc, csize, usize, nlen, elen, clen2,
         _ds, _ia, _ea, loff) = struct.unpack_from("<IHHHHHHIIIHHHHHII", cd, p)
        if sig != SIG_CEN:
            raise ZipUnsupported("bad central directory")
        e = _Entry()
        e.loff_in_extra = None
        if 0xFFFFFFFF in (csize, usize, loff):
            # VaM's packer writes zip64 extra fields (id 0x0001) even for small entries
            extra = cd[p + 46 + nlen:p + 46 + nlen + elen]
            q = 0
            while q + 4 <= len(extra):
                hid, hsz = struct.unpack_from("<HH", extra, q)
                if hid == 0x0001:
                    r = q + 4
                    if usize == 0xFFFFFFFF:
                        usize = struct.unpack_from("<Q", extra, r)[0]
                        r += 8
                    if csize == 0xFFFFFFFF:
                        csize = struct.unpack_from("<Q", extra, r)[0]
                        r += 8
                    if loff == 0xFFFFFFFF:
                        loff = struct.unpack_from("<Q", extra, r)[0]
                        e.loff_in_extra = 46 + nlen + r  # position inside the central record
                    break
                q += 4 + hsz
            if 0xFFFFFFFF in (csize, usize, loff):
                raise ZipUnsupported("zip64 entry without zip64 extra")
        e.raw_name = cd[p + 46:p + 46 + nlen]
        e.name = e.raw_name.decode("utf-8") if flag & 0x800 else e.raw_name.decode("cp437")
        uname = None if flag & 0x800 else _unicode_path(cd[p + 46 + nlen:p + 46 + nlen + elen], e.raw_name)
        e.uname = uname is not None
        if uname is not None:
            e.name = uname
        e.flag, e.method, e.mtime, e.mdate = flag, method, mt, md
        e.crc, e.csize, e.usize, e.local_off = crc, csize, usize, loff
        e.cen = cd[p:p + 46 + nlen + elen + clen2]
        entries.append(e)
        p += 46 + nlen + elen + clen2
    return entries, comment


def _local_span(f, e):
    f.seek(e.local_off)
    h = f.read(30)
    if h[:4] != SIG_LOCAL:
        raise ZipUnsupported(f"bad local header for {e.name}")
    nlen, elen = struct.unpack_from("<HH", h, 26)
    end = e.local_off + 30 + nlen + elen + e.csize
    if e.flag & 0x08:
        f.seek(end)
        d = f.read(4)
        big = e.csize >= 0xFFFFFFFF or e.usize >= 0xFFFFFFFF
        end += (24 if big else 16) if d == b"PK\x07\x08" else (20 if big else 12)
    return e.local_off, end


def _copy(fin, fout, start, end):
    fin.seek(start)
    left = end - start
    while left:
        b = fin.read(min(CHUNK, left))
        if not b:
            raise ZipUnsupported("truncated entry data")
        fout.write(b)
        left -= len(b)


def _dos_now():
    t = time.localtime()
    return ((t.tm_hour << 11) | (t.tm_min << 5) | (t.tm_sec // 2),
            ((t.tm_year - 1980) << 9) | (t.tm_mon << 5) | t.tm_mday)


def _write_new(fout, raw_name, flag, mt, md, data):
    crc = zlib.crc32(data) & 0xFFFFFFFF
    co = zlib.compressobj(6, zlib.DEFLATED, -15)
    cdata = co.compress(data) + co.flush()
    method = 8
    if len(cdata) >= len(data):
        method, cdata = 0, data
    flag &= ~0x08
    off = fout.tell()
    fout.write(struct.pack("<4sHHHHHIIIHH", SIG_LOCAL, 20, flag, method, mt, md, crc,
                           len(cdata), len(data), len(raw_name), 0))
    fout.write(raw_name)
    fout.write(cdata)
    cen = struct.pack("<IHHHHHHIIIHHHHHII", SIG_CEN, 20, 20, flag, method, mt, md, crc,
                      len(cdata), len(data), len(raw_name), 0, 0, 0, 0, 0, off) + raw_name
    return cen


def rewrite_zip(src, dst, drop=(), replace=None, add=None):
    """drop: names to remove; replace: {name: bytes}; add: {name: bytes} (appended)."""
    replace = dict(replace or {})
    add = dict(add or {})
    drop = set(drop)
    with open(src, "rb") as fin:
        entries, comment = read_central(fin)
        names = {e.name for e in entries}
        missing = (drop | set(replace)) - names
        if missing:
            raise ZipUnsupported(f"names not in zip: {sorted(missing)[:5]}")
        clash = set(add) & (names - drop)
        if clash:
            raise ZipUnsupported(f"added names already exist: {sorted(clash)[:5]}")
        cens = []
        with open(dst, "wb") as fout:
            for e in entries:
                if e.name in drop:
                    continue
                if e.name in replace:
                    # _write_new drops extra fields, so a 0x7075 name must become the (UTF-8 flagged) main name
                    raw, flag = (e.name.encode("utf-8"), e.flag | 0x800) if e.uname else (e.raw_name, e.flag)
                    cens.append(_write_new(fout, raw, flag, e.mtime, e.mdate, replace[e.name]))
                    continue
                start, end = _local_span(fin, e)
                new_off = fout.tell()
                _copy(fin, fout, start, end)
                if e.loff_in_extra is not None:
                    k = e.loff_in_extra
                    cens.append(e.cen[:k] + struct.pack("<Q", new_off) + e.cen[k + 8:])
                else:
                    cens.append(e.cen[:42] + struct.pack("<I", new_off) + e.cen[46:])
            mt, md = _dos_now()
            for name, data in add.items():
                raw = name.encode("utf-8")
                flag = 0x800 if any(ord(c) > 127 for c in name) else 0
                cens.append(_write_new(fout, raw, flag, mt, md, data))
            cd_off = fout.tell()
            for c in cens:
                fout.write(c)
            cd_size = fout.tell() - cd_off
            if len(cens) >= 0xFFFF or cd_off >= 0xFFFFFFFF:
                raise ZipUnsupported("result would need zip64")
            fout.write(struct.pack("<4sHHHHIIH", SIG_EOCD, 0, 0, len(cens), len(cens), cd_size, cd_off, len(comment)))
            fout.write(comment)
    return len(cens)


def rewrite_problem(path, expected_names):
    """Why rewrite_zip can't be trusted with this file, or None. expected_names = the (non-directory) names
    zipfile reported when the file was indexed; a layout we don't parse or names that read differently here
    (encodings, odd separators) would make the planned strip/rewrite miss or hit the wrong entry."""
    try:
        with open(path, "rb") as fh:
            entries, _ = read_central(fh)
    except (OSError, ZipUnsupported, struct.error, UnicodeDecodeError) as e:
        return f"{type(e).__name__}: {e}"
    names = [e.name for e in entries if not e.name.endswith("/")]
    if len(names) != len(set(names)):
        return "duplicate entry names"
    diff = set(names) ^ set(expected_names)
    if diff:
        return f"entry names read differently: {sorted(diff)[:3]}"
    return None


def verify_zip(path, expected_names, check_names=()):
    """Structure + names check; full CRC read of check_names (the entries we wrote)."""
    with zipfile.ZipFile(path) as z:
        got = [i.filename for i in z.infolist()]
        if sorted(got) != sorted(expected_names):
            extra = set(got) - set(expected_names)
            miss = set(expected_names) - set(got)
            raise ZipUnsupported(f"verify names mismatch: +{sorted(extra)[:3]} -{sorted(miss)[:3]}")
        for n in check_names:
            with z.open(n) as fh:
                while fh.read(CHUNK):
                    pass
    return True
