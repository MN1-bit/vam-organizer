"""Entry point: python vamdedup.py <index|plan|apply|verify|rollback> ..."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vd.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
